package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LibraryMusic
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainViewModel
import com.example.ui.components.rememberSeamlessHaptics
import com.example.ui.screens.EqualizerBottomSheet
import com.example.ui.screens.InfinityBottomSheet
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.ListenScreen
import com.example.ui.screens.MiniPlayerBar
import com.example.ui.screens.NowPlayingScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.LocalSeamlessPalette
import com.example.ui.theme.SeamlessTheme

private enum class MainTab {
  LISTEN,
  LIBRARY,
  STUDIO,
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val viewModel: MainViewModel = viewModel()
      val prefs by viewModel.preferences.collectAsStateWithLifecycle()
      val playback by viewModel.playbackState.collectAsStateWithLifecycle()
      val audioFrame by viewModel.audioFrame.collectAsStateWithLifecycle()
      val infinityState by viewModel.infinityState.collectAsStateWithLifecycle()
      val allTracks by viewModel.allTracks.collectAsStateWithLifecycle()
      val filteredTracks by viewModel.filteredTracks.collectAsStateWithLifecycle()
      val albums by viewModel.albums.collectAsStateWithLifecycle()
      val artists by viewModel.artists.collectAsStateWithLifecycle()
      val folders by viewModel.folders.collectAsStateWithLifecycle()
      val isScanning by viewModel.isScanning.collectAsStateWithLifecycle()
      val hasAudioPermission by viewModel.hasAudioPermission.collectAsStateWithLifecycle()
      val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
      val libraryFilter by viewModel.libraryFilter.collectAsStateWithLifecycle()
      val sortOrder by viewModel.sortOrder.collectAsStateWithLifecycle()

      val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
      ) { uri ->
        if (uri != null) {
          viewModel.importAudioFile(uri)
        }
      }

      SeamlessTheme(
        themePreset = prefs.themePreset,
        customPrimaryArgb = prefs.customPrimaryArgb,
        customAccentArgb = prefs.customAccentArgb,
      ) {
        val haptics = rememberSeamlessHaptics(prefs.hapticsEnabled)
        val palette = LocalSeamlessPalette.current

        if (!prefs.onboardingCompleted) {
          OnboardingScreen(
            hasAudioPermission = hasAudioPermission,
            initialStyle = prefs.reactionStyle,
            audioFrame = audioFrame,
            isPlaying = playback.isPlaying,
            haptics = haptics,
            onPermissionsResult = { viewModel.refreshPermissionAndScan() },
            onComplete = { chosenStyle ->
              viewModel.completeOnboarding(chosenStyle)
              viewModel.refreshPermissionAndScan()
            },
          )
        } else {
          var currentTab by rememberSaveable { mutableStateOf(MainTab.LISTEN) }
          var isPlayerExpanded by rememberSaveable { mutableStateOf(false) }
          var showInfinitySheet by rememberSaveable { mutableStateOf(false) }
          var showEqualizerSheet by rememberSaveable { mutableStateOf(false) }

          val miniPlayerAllowance = if (playback.currentTrack != null) 78.dp else 0.dp

          Box(modifier = Modifier.fillMaxSize()) {
            Scaffold(
              containerColor = palette.background,
              contentWindowInsets = WindowInsets(0, 0, 0, 0),
              bottomBar = {
                Column {
                  AnimatedVisibility(
                    visible = playback.currentTrack != null && !isPlayerExpanded,
                  ) {
                    MiniPlayerBar(
                      playback = playback,
                      audioFrame = audioFrame,
                      infinityState = infinityState,
                      prefs = prefs,
                      haptics = haptics,
                      onExpand = { isPlayerExpanded = true },
                      onTogglePlayPause = { viewModel.togglePlayPause() },
                      onNext = { viewModel.next(false) },
                      modifier = Modifier.padding(bottom = 8.dp),
                    )
                  }

                  NavigationBar(
                    containerColor = palette.surface.copy(alpha = 0.98f),
                    tonalElevation = 4.dp,
                  ) {
                    NavigationBarItem(
                      selected = currentTab == MainTab.LISTEN,
                      onClick = {
                        haptics.tick()
                        currentTab = MainTab.LISTEN
                      },
                      icon = {
                        Icon(
                          imageVector = if (currentTab == MainTab.LISTEN) Icons.Rounded.Home else Icons.Outlined.Home,
                          contentDescription = stringResource(R.string.nav_listen),
                        )
                      },
                      label = { Text(stringResource(R.string.nav_listen)) },
                      colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = palette.primary,
                        selectedTextColor = palette.primary,
                        indicatorColor = palette.primary.copy(alpha = 0.16f),
                        unselectedIconColor = palette.onSurfaceMuted,
                        unselectedTextColor = palette.onSurfaceMuted,
                      ),
                      modifier = Modifier.testTag("nav_listen"),
                    )
                    NavigationBarItem(
                      selected = currentTab == MainTab.LIBRARY,
                      onClick = {
                        haptics.tick()
                        currentTab = MainTab.LIBRARY
                      },
                      icon = {
                        Icon(
                          imageVector = if (currentTab == MainTab.LIBRARY) Icons.Rounded.LibraryMusic else Icons.Outlined.LibraryMusic,
                          contentDescription = stringResource(R.string.nav_library),
                        )
                      },
                      label = { Text(stringResource(R.string.nav_library)) },
                      colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = palette.primary,
                        selectedTextColor = palette.primary,
                        indicatorColor = palette.primary.copy(alpha = 0.16f),
                        unselectedIconColor = palette.onSurfaceMuted,
                        unselectedTextColor = palette.onSurfaceMuted,
                      ),
                      modifier = Modifier.testTag("nav_library"),
                    )
                    NavigationBarItem(
                      selected = currentTab == MainTab.STUDIO,
                      onClick = {
                        haptics.tick()
                        currentTab = MainTab.STUDIO
                      },
                      icon = {
                        Icon(
                          imageVector = if (currentTab == MainTab.STUDIO) Icons.Rounded.Tune else Icons.Outlined.Tune,
                          contentDescription = stringResource(R.string.nav_studio),
                        )
                      },
                      label = { Text(stringResource(R.string.nav_studio)) },
                      colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = palette.primary,
                        selectedTextColor = palette.primary,
                        indicatorColor = palette.primary.copy(alpha = 0.16f),
                        unselectedIconColor = palette.onSurfaceMuted,
                        unselectedTextColor = palette.onSurfaceMuted,
                      ),
                      modifier = Modifier.testTag("nav_studio"),
                    )
                  }
                }
              },
            ) { innerPadding ->
              Box(
                modifier = Modifier
                  .fillMaxSize()
                  .padding(innerPadding),
              ) {
                when (currentTab) {
                  MainTab.LISTEN -> ListenScreen(
                    tracks = allTracks,
                    folders = folders,
                    currentTrack = playback.currentTrack,
                    isPlaying = playback.isPlaying,
                    prefs = prefs,
                    isScanning = isScanning,
                    haptics = haptics,
                    onPlayQueue = { list, idx ->
                      viewModel.playTracks(list, idx)
                      isPlayerExpanded = true
                    },
                    onOpenInfinitySheet = { showInfinitySheet = true },
                    onOpenLibrary = { currentTab = MainTab.LIBRARY },
                    onImportAudioClick = { audioPickerLauncher.launch(arrayOf("audio/*")) },
                    onRescanClick = { viewModel.refreshPermissionAndScan() },
                    onLoadSoundcheckClick = { viewModel.loadStudioSoundcheck() },
                    bottomContentPadding = miniPlayerAllowance,
                  )

                  MainTab.LIBRARY -> LibraryScreen(
                    allTracks = allTracks,
                    filteredTracks = filteredTracks,
                    albums = albums,
                    artists = artists,
                    folders = folders,
                    currentTrack = playback.currentTrack,
                    isPlaying = playback.isPlaying,
                    searchQuery = searchQuery,
                    activeFilter = libraryFilter,
                    sortOrder = sortOrder,
                    prefs = prefs,
                    haptics = haptics,
                    onSearchChange = { viewModel.setSearchQuery(it) },
                    onFilterChange = { viewModel.setLibraryFilter(it) },
                    onSortChange = { viewModel.setSortOrder(it) },
                    onPlayQueue = { list, idx ->
                      viewModel.playTracks(list, idx)
                      isPlayerExpanded = true
                    },
                    onToggleFavorite = { viewModel.toggleFavorite(it) },
                    onCreatePlaylist = { name, id -> viewModel.createPlaylist(name, id) },
                    onAddTrackToPlaylist = { plId, trackId -> viewModel.addTrackToPlaylist(plId, trackId) },
                    onDeletePlaylist = { plId -> viewModel.deletePlaylist(plId) },
                    onImportAudio = { audioPickerLauncher.launch(arrayOf("audio/*")) },
                    bottomContentPadding = miniPlayerAllowance,
                  )

                  MainTab.STUDIO -> SettingsScreen(
                    prefs = prefs,
                    currentTrack = playback.currentTrack,
                    audioFrame = audioFrame,
                    isPlaying = playback.isPlaying,
                    haptics = haptics,
                    onSelectReactionStyle = { viewModel.setReactionStyle(it) },
                    onSelectThemePreset = { viewModel.setThemePreset(it) },
                    onSelectCustomPrimary = { viewModel.setCustomPrimary(it) },
                    onSelectCustomAccent = { viewModel.setCustomAccent(it) },
                    onToggleHaptics = { viewModel.setHapticsEnabled(it) },
                    onOpenInfinitySheet = { showInfinitySheet = true },
                    onSetWidgetShape = { viewModel.setWidgetShapeStyle(it) },
                    onSetWidgetWaveIntensity = { viewModel.setWidgetWaveIntensity(it) },
                    onSetWidgetOpacity = { viewModel.setWidgetMatteOpacity(it) },
                    onRescanLibrary = { viewModel.refreshPermissionAndScan() },
                    onImportAudio = { audioPickerLauncher.launch(arrayOf("audio/*")) },
                    bottomContentPadding = miniPlayerAllowance,
                  )
                }
              }
            }

            AnimatedVisibility(
              visible = isPlayerExpanded,
              enter = slideInVertically { it },
              exit = slideOutVertically { it },
              modifier = Modifier.align(Alignment.BottomCenter),
            ) {
              NowPlayingScreen(
                playback = playback,
                audioFrame = audioFrame,
                infinityState = infinityState,
                prefs = prefs,
                haptics = haptics,
                onCollapse = { isPlayerExpanded = false },
                onTogglePlayPause = { viewModel.togglePlayPause() },
                onNext = { mashup -> viewModel.next(mashup) },
                onPrevious = { viewModel.previous() },
                onSeekTo = { viewModel.seekTo(it) },
                onToggleShuffle = { viewModel.toggleShuffle() },
                onCycleRepeat = { viewModel.cycleRepeatMode() },
                onToggleFavorite = { viewModel.toggleFavorite(it) },
                onSelectReactionStyle = { viewModel.setReactionStyle(it) },
                onOpenInfinitySheet = { showInfinitySheet = true },
                onOpenEqualizerSheet = { showEqualizerSheet = true },
                onSetSleepTimer = { viewModel.setSleepTimerMinutes(it) },
                onJumpQueue = { viewModel.jumpToQueueIndex(it) },
                onRemoveQueue = { viewModel.removeFromQueue(it) },
              )
            }

            if (showInfinitySheet) {
              InfinityBottomSheet(
                prefs = prefs,
                infinityState = infinityState,
                haptics = haptics,
                onToggleInfinity = { viewModel.setInfinityEnabled(it) },
                onSetDuration = { viewModel.setInfinityDurationSec(it) },
                onSetProfile = { viewModel.setInfinityProfile(it) },
                onBlendNow = { viewModel.next(forceInfinityMashup = true) },
                onDismiss = { showInfinitySheet = false },
              )
            }

            if (showEqualizerSheet) {
              EqualizerBottomSheet(
                prefs = prefs,
                haptics = haptics,
                onSelectPreset = { viewModel.setEqPreset(it) },
                onSetBands = { viewModel.setEqBands(it) },
                onSetBassBoost = { viewModel.setBassBoost(it) },
                onSetSpeed = { viewModel.setPlaybackSpeed(it) },
                onDismiss = { showEqualizerSheet = false },
              )
            }
          }
        }
      }
    }
  }
}
