package com.example.model

import android.net.Uri
import androidx.compose.runtime.Immutable

@Immutable
data class Track(
  val id: Long,
  val uri: Uri,
  val title: String,
  val artist: String,
  val album: String,
  val albumId: Long,
  val albumArtUri: Uri?,
  val durationMs: Long,
  val folderName: String,
  val mimeType: String = "audio/mpeg",
  val dateAdded: Long = 0L,
  val sizeBytes: Long = 0L,
  val isImported: Boolean = false,
)

@Immutable
data class AlbumGroup(
  val albumId: Long,
  val name: String,
  val artist: String,
  val artUri: Uri?,
  val tracks: List<Track>,
)

@Immutable
data class ArtistGroup(
  val name: String,
  val tracks: List<Track>,
  val artUri: Uri?,
)

@Immutable
data class FolderGroup(
  val name: String,
  val tracks: List<Track>,
)

@Immutable
data class UserPlaylist(
  val id: String,
  val name: String,
  val trackIds: List<Long>,
)

enum class ReactionStyle(
  val title: String,
  val subtitle: String,
  val badge: String,
) {
  SEAMLESS_PULSE(
    title = "Seamless Pulse",
    subtitle = "Icon-inspired twin gradient halo breathing with bass & vocals",
    badge = "Signature",
  ),
  RADIAL_SPECTRUM(
    title = "Radial Spectrum",
    subtitle = "64 crisp matte-luminous frequency bars blooming outward",
    badge = "Precision",
  ),
  HARMONIC_ORBIT(
    title = "Harmonic Orbit",
    subtitle = "Three phase-locked bezier orbits for bass, mids, and air",
    badge = "Layered",
  ),
  LIQUID_AURA(
    title = "Liquid Aura",
    subtitle = "Organic morphing polar contour driven by sub-bass energy",
    badge = "Fluid",
  ),
  MINIMAL_SONAR(
    title = "Minimal Sonar",
    subtitle = "Subtle concentric acoustic ripples triggered on beat transients",
    badge = "Minimal",
  ),
  EQUALIZER_ARC(
    title = "Equalizer Arc",
    subtitle = "Symmetric stereo arc meters flanking the artwork rim",
    badge = "Studio",
  ),
  WAVEFORM_HALO(
    title = "Waveform Halo",
    subtitle = "Continuous circular oscilloscope tracing raw PCM audio",
    badge = "Live PCM",
  ),
  CONSTELLATION(
    title = "Constellation",
    subtitle = "Orbiting acoustic particles that accelerate on treble peaks",
    badge = "Ambient",
  ),
  VINYL_STROBE(
    title = "Vinyl Strobe",
    subtitle = "Precision tachometer ticks and rotating phase sweep",
    badge = "Analog",
  ),
  HORIZON_ECLIPSE(
    title = "Horizon Eclipse",
    subtitle = "Luminous directional corona shifting with stereo energy",
    badge = "Atmospheric",
  ),
  DUAL_HELIX(
    title = "Dual Helix",
    subtitle = "Interlocking twin Seamless ribbons woven into a closed ring",
    badge = "Dynamic",
  ),
  PRISM_CROWN(
    title = "Prism Crown",
    subtitle = "Faceted geometric envelope sculpted by frequency bands",
    badge = "Geometric",
  ),
}

enum class InfinityBlendProfile(
  val title: String,
  val description: String,
) {
  SMOOTH_CROSSFADE(
    title = "Smooth Crossfade",
    description = "Equal-power S-curve volume glide with zero dead air",
  ),
  HARMONIC_MASHUP(
    title = "Harmonic Mashup",
    description = "Bass handover & vocal overlap with gentle frequency crossover",
  ),
  AMBIENT_DRIFT(
    title = "Ambient Drift",
    description = "Extended atmospheric overlap tailored for seamless flow",
  ),
}

enum class AppThemePreset(
  val title: String,
  val subtitle: String,
  val isLight: Boolean = false,
) {
  MATTE_GREY("Matte Grey", "Icon-matched charcoal & mint-violet", false),
  OBSIDIAN_STUDIO("Obsidian", "Deep studio slate & crisp cyan", false),
  WARM_GRAPHITE("Warm Graphite", "Muted volcanic stone & coral amber", false),
  MIDNIGHT_INDIGO("Midnight Indigo", "Cool slate night & glacial blue", false),
  SAGE_CONCRETE("Sage Concrete", "Architectural mineral & soft sage", false),
  MIST_PAPER("Mist Paper", "Soft daylight matte & emerald", true),
}

enum class WidgetShapeStyle(
  val title: String,
  val cornerDp: Int,
) {
  SOFT_SQUIRCLE("Soft Squircle", 24),
  ORGANIC_CAPSULE("Organic Pill", 36),
  ADAPTIVE_PILL("Sleek Matte", 16),
  SHARP_STUDIO("Studio Frame", 8),
}

enum class EqPreset(
  val title: String,
  val bandsDb: List<Float>, // 5 bands: 60Hz, 230Hz, 910Hz, 3.6kHz, 14kHz (-12f..+12f)
) {
  FLAT("Flat", listOf(0f, 0f, 0f, 0f, 0f)),
  STUDIO_MATTE("Studio Matte", listOf(2.5f, 1f, -0.5f, 1.5f, 3f)),
  DEEP_BASS("Deep Bass", listOf(6f, 3.5f, 0f, 1f, 2f)),
  VOCAL_AIR("Vocal Air", listOf(-1f, 0.5f, 3.5f, 4f, 2.5f)),
  LATE_NIGHT("Late Night", listOf(3f, 1.5f, -1f, 0.5f, -2f)),
  CUSTOM("Custom", listOf(0f, 0f, 0f, 0f, 0f)),
}

enum class RepeatModeOption {
  OFF,
  ALL,
  ONE,
}

enum class LibraryFilter {
  TRACKS,
  ALBUMS,
  ARTISTS,
  FOLDERS,
  FAVORITES,
  PLAYLISTS,
}

enum class SortOrder(val label: String) {
  TITLE("Title A–Z"),
  ARTIST("Artist"),
  RECENT("Recently Added"),
  DURATION("Duration"),
}

@Immutable
data class AudioFrame(
  val spectrum: FloatArray = FloatArray(48),
  val waveform: FloatArray = FloatArray(64),
  val bassEnergy: Float = 0f,
  val midEnergy: Float = 0f,
  val trebleEnergy: Float = 0f,
  val overallRms: Float = 0f,
  val beatPulse: Float = 0f,
  val phase: Float = 0f,
) {
  override fun equals(other: Any?): Boolean {
    if (this === other) return true
    if (other !is AudioFrame) return false
    return bassEnergy == other.bassEnergy &&
      midEnergy == other.midEnergy &&
      trebleEnergy == other.trebleEnergy &&
      overallRms == other.overallRms &&
      beatPulse == other.beatPulse &&
      phase == other.phase &&
      spectrum.contentEquals(other.spectrum) &&
      waveform.contentEquals(other.waveform)
  }

  override fun hashCode(): Int {
    var result = spectrum.contentHashCode()
    result = 31 * result + waveform.contentHashCode()
    result = 31 * result + bassEnergy.hashCode()
    result = 31 * result + midEnergy.hashCode()
    result = 31 * result + trebleEnergy.hashCode()
    result = 31 * result + overallRms.hashCode()
    result = 31 * result + beatPulse.hashCode()
    result = 31 * result + phase.hashCode()
    return result
  }
}

@Immutable
data class InfinityTransitionState(
  val isBlending: Boolean = false,
  val progress: Float = 0f,
  val outgoingTitle: String = "",
  val incomingTitle: String = "",
)

@Immutable
data class UserPreferences(
  val onboardingCompleted: Boolean = false,
  val reactionStyle: ReactionStyle = ReactionStyle.SEAMLESS_PULSE,
  val themePreset: AppThemePreset = AppThemePreset.MATTE_GREY,
  val customPrimaryArgb: Int? = null,
  val customAccentArgb: Int? = null,
  val infinityEnabled: Boolean = true,
  val infinityDurationSec: Int = 8,
  val infinityProfile: InfinityBlendProfile = InfinityBlendProfile.HARMONIC_MASHUP,
  val hapticsEnabled: Boolean = true,
  val eqPreset: EqPreset = EqPreset.STUDIO_MATTE,
  val eqBandsDb: List<Float> = EqPreset.STUDIO_MATTE.bandsDb,
  val bassBoostStrength: Float = 0.2f,
  val playbackSpeed: Float = 1.0f,
  val widgetShapeStyle: WidgetShapeStyle = WidgetShapeStyle.SOFT_SQUIRCLE,
  val widgetWaveIntensity: Float = 0.85f,
  val widgetMatteOpacity: Float = 0.94f,
  val favoriteIds: Set<Long> = emptySet(),
  val recentTrackIds: List<Long> = emptyList(),
  val playlists: List<UserPlaylist> = emptyList(),
)
