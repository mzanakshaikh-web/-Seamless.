package com.example.audio

import com.example.model.AudioFrame
import com.example.model.InfinityTransitionState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object AudioAnalyzerBus {
  private val _audioFrame = MutableStateFlow(AudioFrame())
  val audioFrame: StateFlow<AudioFrame> = _audioFrame.asStateFlow()

  private val _infinityState = MutableStateFlow(InfinityTransitionState())
  val infinityState: StateFlow<InfinityTransitionState> = _infinityState.asStateFlow()

  fun publishFrame(frame: AudioFrame) {
    _audioFrame.value = frame
  }

  fun resetFrame() {
    _audioFrame.value = AudioFrame()
  }

  fun publishInfinityState(state: InfinityTransitionState) {
    _infinityState.value = state
  }
}
