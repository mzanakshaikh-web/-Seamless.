package com.example.audio

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.os.Build
import android.os.PowerManager
import androidx.annotation.OptIn
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.example.MainActivity
import com.example.R
import com.example.data.DeviceAudioRepository
import com.example.data.SettingsRepository
import com.example.model.InfinityBlendProfile
import com.example.model.InfinityTransitionState
import com.example.model.RepeatModeOption
import com.example.model.Track
import com.example.model.UserPreferences
import com.example.widget.SeamlessWidgetUpdater
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
class SeamlessPlaybackService : MediaSessionService() {

  private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

  private lateinit var settingsRepo: SettingsRepository
  private var latestPrefs = UserPreferences()

  private lateinit var processorA: SeamlessDeckAudioProcessor
  private lateinit var processorB: SeamlessDeckAudioProcessor
  private lateinit var deckA: ExoPlayer
  private lateinit var deckB: ExoPlayer
  private var activeIsA: Boolean = true

  private var mediaSession: MediaSession? = null

  private var equalizer: Equalizer? = null
  private var bassBoost: BassBoost? = null

  private var queue: MutableList<Track> = mutableListOf()
  private var currentIndex: Int = -1
  private var shuffleEnabled: Boolean = false
  private var repeatMode: RepeatModeOption = RepeatModeOption.ALL

  private var crossfadeJob: Job? = null
  private var monitorJob: Job? = null
  private var widgetSyncJob: Job? = null
  private var sleepTimerJob: Job? = null
  private var sleepRemainingMs: Long? = null

  private var isTransitioning = false
  private var wavePhase = 0f

  private val activePlayer: ExoPlayer get() = if (activeIsA) deckA else deckB
  private val standbyPlayer: ExoPlayer get() = if (activeIsA) deckB else deckA
  private val activeProcessor: SeamlessDeckAudioProcessor get() = if (activeIsA) processorA else processorB
  private val standbyProcessor: SeamlessDeckAudioProcessor get() = if (activeIsA) processorB else processorA

  override fun onCreate() {
    super.onCreate()
    PlaybackBridge.serviceRef = this
    settingsRepo = SettingsRepository(applicationContext)

    processorA = SeamlessDeckAudioProcessor { activeIsA || isTransitioning }
    processorB = SeamlessDeckAudioProcessor { !activeIsA || isTransitioning }

    deckA = buildDeckPlayer(processorA)
    deckB = buildDeckPlayer(processorB)

    attachDeckListeners(deckA) { activeIsA }
    attachDeckListeners(deckB) { !activeIsA }

    val launchIntent = PendingIntent.getActivity(
      this,
      0,
      Intent(this, MainActivity::class.java),
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    mediaSession = MediaSession.Builder(this, deckA)
      .setSessionActivity(launchIntent)
      .build()

    serviceScope.launch {
      settingsRepo.preferencesFlow.collect { prefs ->
        latestPrefs = prefs
        applyAudioPreferences(prefs)
        pushWidgetNow()
      }
    }

    startPositionAndInfinityMonitor()
    startWidgetWaveLoop()
  }

  private fun buildDeckPlayer(processor: SeamlessDeckAudioProcessor): ExoPlayer {
    val renderersFactory = object : DefaultRenderersFactory(this) {
      override fun buildAudioSink(
        context: Context,
        enableFloatOutput: Boolean,
        enableAudioTrackPlaybackParams: Boolean,
      ): AudioSink {
        return DefaultAudioSink.Builder(context)
          .setEnableFloatOutput(enableFloatOutput)
          .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
          .setAudioProcessors(arrayOf(processor))
          .build()
      }
    }
    val attrs = AudioAttributes.Builder()
      .setUsage(C.USAGE_MEDIA)
      .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
      .build()

    return ExoPlayer.Builder(this, renderersFactory)
      .setAudioAttributes(attrs, true)
      .setHandleAudioBecomingNoisy(true)
      .build()
  }

  private fun attachDeckListeners(player: ExoPlayer, isActiveCheck: () -> Boolean) {
    player.addListener(object : Player.Listener {
      override fun onIsPlayingChanged(isPlaying: Boolean) {
        if (!isActiveCheck()) return
        PlaybackBridge.updateState { it.copy(isPlaying = isPlaying) }
        if (isPlaying) {
          getSystemService(NotificationManager::class.java)?.cancel(BOOT_NOTIFICATION_ID)
        } else if (!isTransitioning) {
          AudioAnalyzerBus.resetFrame()
        }
        serviceScope.launch { pushWidgetNow() }
      }

      override fun onPlaybackStateChanged(playbackState: Int) {
        if (!isActiveCheck()) return
        if (playbackState == Player.STATE_READY) {
          val dur = player.duration.coerceAtLeast(0L)
          PlaybackBridge.updateState { it.copy(durationMs = dur) }
          attachAudioEffects(player.audioSessionId)
        } else if (playbackState == Player.STATE_ENDED && !isTransitioning) {
          handleTrackEndedNaturally()
        }
      }

      override fun onAudioSessionIdChanged(audioSessionId: Int) {
        if (isActiveCheck()) {
          attachAudioEffects(audioSessionId)
        }
      }
    })
  }

  override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    val action = intent?.action
    val startedForeground = intent?.getBooleanExtra(EXTRA_STARTED_FOREGROUND, false) == true
    if (startedForeground || action != null) {
      ensureBootNotificationIfNeeded()
    }
    if (action != null) {
      when (action) {
        ACTION_TOGGLE_PLAY_PAUSE -> handleWidgetPlayPause()
        ACTION_NEXT -> skipToNext(forceInfinityMashup = latestPrefs.infinityEnabled)
        ACTION_PREVIOUS -> skipToPrevious()
        ACTION_TOGGLE_INFINITY -> {
          serviceScope.launch {
            settingsRepo.setInfinityEnabled(!latestPrefs.infinityEnabled)
          }
        }
      }
    }
    return super.onStartCommand(intent, flags, startId)
  }

  private fun ensureBootNotificationIfNeeded() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channelId = "seamless_widget_sync"
      val nm = getSystemService(NotificationManager::class.java)
      if (nm?.getNotificationChannel(channelId) == null) {
        nm?.createNotificationChannel(
          NotificationChannel(channelId, "Seamless Playback", NotificationManager.IMPORTANCE_LOW)
        )
      }
      val notification = NotificationCompat.Builder(this, channelId)
        .setSmallIcon(R.drawable.ic_widget_infinity)
        .setContentTitle("Seamless")
        .setContentText("Preparing audio playback...")
        .setSilent(true)
        .build()
      val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
      } else {
        0
      }
      runCatching {
        ServiceCompat.startForeground(this, BOOT_NOTIFICATION_ID, notification, fgsType)
      }
    }
  }

  private fun handleWidgetPlayPause() {
    if (queue.isEmpty()) {
      serviceScope.launch {
        val tracks = DeviceAudioRepository(applicationContext).loadAllTracks()
        if (tracks.isNotEmpty()) {
          playQueue(tracks, 0)
        } else {
          ServiceCompat.stopForeground(this@SeamlessPlaybackService, ServiceCompat.STOP_FOREGROUND_REMOVE)
        }
      }
    } else {
      togglePlayPause()
    }
  }

  fun playQueue(tracks: List<Track>, startIndex: Int) {
    if (tracks.isEmpty()) return
    cancelCrossfade()
    queue = tracks.toMutableList()
    currentIndex = startIndex.coerceIn(0, queue.lastIndex)
    val track = queue[currentIndex]

    standbyPlayer.stop()
    standbyPlayer.clearMediaItems()
    resetProcessors()

    activePlayer.setMediaItem(track.toMediaItem())
    activePlayer.playbackParameters = PlaybackParameters(latestPrefs.playbackSpeed)
    activePlayer.prepare()
    activePlayer.play()

    updateBridgeTrack(track)
    serviceScope.launch {
      settingsRepo.recordRecentTrack(track.id)
      pushWidgetNow()
    }
  }

  fun togglePlayPause() {
    if (queue.isEmpty()) return
    if (activePlayer.isPlaying) {
      activePlayer.pause()
      if (isTransitioning) standbyPlayer.pause()
    } else {
      activePlayer.play()
      if (isTransitioning) standbyPlayer.play()
    }
  }

  fun seekTo(positionMs: Long) {
    val clamped = positionMs.coerceAtLeast(0L)
    activePlayer.seekTo(clamped)
    PlaybackBridge.updateState { it.copy(positionMs = clamped) }
  }

  fun skipToNext(forceInfinityMashup: Boolean = false) {
    if (queue.isEmpty()) return
    val nextIdx = resolveNextIndex(manual = true) ?: return
    if ((forceInfinityMashup || latestPrefs.infinityEnabled) && activePlayer.isPlaying && queue.size > 1) {
      startInfinityTransition(nextIdx, quickBlend = forceInfinityMashup)
    } else {
      playIndexImmediately(nextIdx)
    }
  }

  fun skipToPrevious() {
    if (queue.isEmpty()) return
    if (activePlayer.currentPosition > 3500L) {
      seekTo(0L)
      return
    }
    val prevIdx = if (currentIndex > 0) currentIndex - 1 else queue.lastIndex
    playIndexImmediately(prevIdx)
  }

  fun jumpToQueueIndex(index: Int) {
    if (index !in queue.indices) return
    if (latestPrefs.infinityEnabled && activePlayer.isPlaying && index != currentIndex) {
      startInfinityTransition(index, quickBlend = true)
    } else {
      playIndexImmediately(index)
    }
  }

  fun toggleShuffle() {
    shuffleEnabled = !shuffleEnabled
    PlaybackBridge.updateState { it.copy(shuffleEnabled = shuffleEnabled) }
  }

  fun cycleRepeatMode() {
    repeatMode = when (repeatMode) {
      RepeatModeOption.OFF -> RepeatModeOption.ALL
      RepeatModeOption.ALL -> RepeatModeOption.ONE
      RepeatModeOption.ONE -> RepeatModeOption.OFF
    }
    PlaybackBridge.updateState { it.copy(repeatMode = repeatMode) }
  }

  fun moveQueueItem(fromIndex: Int, toIndex: Int) {
    if (fromIndex !in queue.indices || toIndex !in queue.indices || fromIndex == toIndex) return
    val item = queue.removeAt(fromIndex)
    queue.add(toIndex, item)
    currentIndex = when {
      currentIndex == fromIndex -> toIndex
      fromIndex < currentIndex && toIndex >= currentIndex -> currentIndex - 1
      fromIndex > currentIndex && toIndex <= currentIndex -> currentIndex + 1
      else -> currentIndex
    }
    PlaybackBridge.updateState { it.copy(queue = queue.toList(), currentIndex = currentIndex) }
  }

  fun removeFromQueue(index: Int) {
    if (index !in queue.indices || queue.size <= 1) return
    if (index == currentIndex) {
      queue.removeAt(index)
      val next = index.coerceAtMost(queue.lastIndex)
      playIndexImmediately(next)
    } else {
      queue.removeAt(index)
      if (index < currentIndex) currentIndex--
      PlaybackBridge.updateState { it.copy(queue = queue.toList(), currentIndex = currentIndex) }
    }
  }

  fun setSleepTimerMinutes(minutes: Int?) {
    sleepTimerJob?.cancel()
    if (minutes == null || minutes <= 0) {
      sleepRemainingMs = null
      PlaybackBridge.updateState { it.copy(sleepTimerRemainingMs = null) }
      return
    }
    var remaining = minutes * 60_000L
    sleepRemainingMs = remaining
    PlaybackBridge.updateState { it.copy(sleepTimerRemainingMs = remaining) }
    sleepTimerJob = serviceScope.launch {
      while (remaining > 0L && isActive) {
        delay(1000L)
        remaining = (remaining - 1000L).coerceAtLeast(0L)
        sleepRemainingMs = remaining
        PlaybackBridge.updateState { it.copy(sleepTimerRemainingMs = remaining) }
      }
      if (remaining <= 0L) {
        activePlayer.pause()
        if (isTransitioning) standbyPlayer.pause()
        sleepRemainingMs = null
        PlaybackBridge.updateState { it.copy(sleepTimerRemainingMs = null) }
      }
    }
  }

  private fun playIndexImmediately(index: Int) {
    cancelCrossfade()
    currentIndex = index.coerceIn(0, queue.lastIndex)
    val track = queue[currentIndex]
    standbyPlayer.stop()
    standbyPlayer.clearMediaItems()
    resetProcessors()

    activePlayer.setMediaItem(track.toMediaItem())
    activePlayer.playbackParameters = PlaybackParameters(latestPrefs.playbackSpeed)
    activePlayer.prepare()
    activePlayer.play()

    updateBridgeTrack(track)
    serviceScope.launch {
      settingsRepo.recordRecentTrack(track.id)
      pushWidgetNow()
    }
  }

  private fun handleTrackEndedNaturally() {
    if (queue.isEmpty()) return
    if (repeatMode == RepeatModeOption.ONE) {
      activePlayer.seekTo(0L)
      activePlayer.play()
      return
    }
    val nextIdx = resolveNextIndex(manual = false)
    if (nextIdx != null) {
      playIndexImmediately(nextIdx)
    } else {
      PlaybackBridge.updateState { it.copy(isPlaying = false, positionMs = 0L) }
      AudioAnalyzerBus.resetFrame()
    }
  }

  private fun resolveNextIndex(manual: Boolean): Int? {
    if (queue.isEmpty()) return null
    if (queue.size == 1) {
      return if (repeatMode != RepeatModeOption.OFF || manual) 0 else null
    }
    if (shuffleEnabled) {
      val candidates = queue.indices.filter { it != currentIndex }
      return candidates.random()
    }
    return if (currentIndex + 1 < queue.size) {
      currentIndex + 1
    } else if (repeatMode == RepeatModeOption.ALL || manual) {
      0
    } else {
      null
    }
  }

  private fun startPositionAndInfinityMonitor() {
    monitorJob?.cancel()
    monitorJob = serviceScope.launch {
      while (isActive) {
        val player = activePlayer
        if (queue.isNotEmpty() && currentIndex in queue.indices) {
          val pos = player.currentPosition.coerceAtLeast(0L)
          val dur = player.duration.coerceAtLeast(queue[currentIndex].durationMs)
          PlaybackBridge.updateState {
            it.copy(
              positionMs = pos,
              durationMs = dur,
              isPlaying = player.isPlaying,
            )
          }

          if (
            latestPrefs.infinityEnabled &&
            !isTransitioning &&
            player.isPlaying &&
            repeatMode != RepeatModeOption.ONE &&
            dur > 10_000L
          ) {
            val triggerWindowMs = (latestPrefs.infinityDurationSec * 1000L).coerceAtMost(dur / 2)
            val remaining = dur - pos
            if (remaining in 300L..triggerWindowMs) {
              val nextIdx = resolveNextIndex(manual = false)
              if (nextIdx != null) {
                startInfinityTransition(nextIdx, quickBlend = false)
              }
            }
          }
        }
        delay(80L)
      }
    }
  }

  private fun startInfinityTransition(targetIndex: Int, quickBlend: Boolean) {
    if (isTransitioning || targetIndex !in queue.indices) return
    val outgoingTrack = queue.getOrNull(currentIndex) ?: return
    val incomingTrack = queue[targetIndex]
    val profile = latestPrefs.infinityProfile
    val blendDurationMs = when {
      quickBlend -> (latestPrefs.infinityDurationSec.coerceIn(3, 6) * 1000L)
      profile == InfinityBlendProfile.AMBIENT_DRIFT -> (latestPrefs.infinityDurationSec.coerceAtLeast(10) * 1000L)
      else -> latestPrefs.infinityDurationSec * 1000L
    }

    isTransitioning = true
    val outgoingPlayer = activePlayer
    val incomingPlayer = standbyPlayer
    val outProc = activeProcessor
    val inProc = standbyProcessor

    inProc.deckGain = 0.0f
    inProc.bassTiltGain = if (profile == InfinityBlendProfile.HARMONIC_MASHUP) 0.15f else 1.0f
    inProc.highTiltGain = 1.0f

    incomingPlayer.setMediaItem(incomingTrack.toMediaItem())
    val baseSpeed = latestPrefs.playbackSpeed
    val startSpeed = if (profile == InfinityBlendProfile.HARMONIC_MASHUP) {
      (baseSpeed * 1.03f).coerceAtMost(1.5f)
    } else {
      baseSpeed
    }
    incomingPlayer.playbackParameters = PlaybackParameters(startSpeed)
    incomingPlayer.prepare()
    incomingPlayer.play()

    crossfadeJob?.cancel()
    crossfadeJob = serviceScope.launch {
      val stepMs = 40L
      val steps = (blendDurationMs / stepMs).toInt().coerceAtLeast(15)
      for (step in 1..steps) {
        while (!outgoingPlayer.isPlaying && !incomingPlayer.isPlaying && isActive) {
          delay(100L)
        }
        val t = (step.toFloat() / steps.toFloat()).coerceIn(0f, 1f)
        // Equal-power smooth S-curve crossfade
        val theta = t * (PI / 2.0)
        outProc.deckGain = cos(theta).toFloat()
        inProc.deckGain = sin(theta).toFloat()

        if (profile == InfinityBlendProfile.HARMONIC_MASHUP) {
          // Smooth bass handover: outgoing sub-bass eases back before incoming beat drops in
          outProc.bassTiltGain = (1f - t * 1.35f).coerceIn(0.1f, 1f)
          inProc.bassTiltGain = ((t - 0.25f) / 0.55f).coerceIn(0.15f, 1f)
          // Gentle pitch/tempo micro-glide settling smoothly to user's base speed
          val glideSpeed = startSpeed + (baseSpeed - startSpeed) * t
          incomingPlayer.playbackParameters = PlaybackParameters(glideSpeed)
        } else {
          outProc.bassTiltGain = 1f
          inProc.bassTiltGain = 1f
        }

        AudioAnalyzerBus.publishInfinityState(
          InfinityTransitionState(
            isBlending = true,
            progress = t,
            outgoingTitle = outgoingTrack.title,
            incomingTitle = incomingTrack.title,
          )
        )
        delay(stepMs)
      }

      // Complete handoff seamlessly
      outProc.deckGain = 1f
      outProc.bassTiltGain = 1f
      outProc.highTiltGain = 1f
      inProc.deckGain = 1f
      inProc.bassTiltGain = 1f
      inProc.highTiltGain = 1f
      incomingPlayer.playbackParameters = PlaybackParameters(baseSpeed)

      outgoingPlayer.stop()
      outgoingPlayer.clearMediaItems()

      activeIsA = !activeIsA
      currentIndex = targetIndex
      mediaSession?.player = activePlayer
      attachAudioEffects(activePlayer.audioSessionId)
      isTransitioning = false

      AudioAnalyzerBus.publishInfinityState(InfinityTransitionState())
      updateBridgeTrack(incomingTrack)
      settingsRepo.recordRecentTrack(incomingTrack.id)
      pushWidgetNow()
    }
  }

  private fun cancelCrossfade() {
    crossfadeJob?.cancel()
    crossfadeJob = null
    isTransitioning = false
    AudioAnalyzerBus.publishInfinityState(InfinityTransitionState())
  }

  private fun resetProcessors() {
    processorA.deckGain = 1f
    processorA.bassTiltGain = 1f
    processorA.highTiltGain = 1f
    processorB.deckGain = 1f
    processorB.bassTiltGain = 1f
    processorB.highTiltGain = 1f
  }

  private fun updateBridgeTrack(track: Track) {
    PlaybackBridge.updateState {
      it.copy(
        queue = queue.toList(),
        currentIndex = currentIndex,
        currentTrack = track,
        isPlaying = true,
        durationMs = track.durationMs,
        positionMs = 0L,
        shuffleEnabled = shuffleEnabled,
        repeatMode = repeatMode,
      )
    }
  }

  private fun attachAudioEffects(audioSessionId: Int) {
    if (audioSessionId == C.AUDIO_SESSION_ID_UNSET || audioSessionId <= 0) return
    releaseAudioEffects()
    runCatching {
      equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
    }
    runCatching {
      bassBoost = BassBoost(0, audioSessionId).apply { enabled = true }
    }
    applyAudioPreferences(latestPrefs)
  }

  private fun applyAudioPreferences(prefs: UserPreferences) {
    if (!isTransitioning) {
      activePlayer.playbackParameters = PlaybackParameters(prefs.playbackSpeed)
    }
    runCatching {
      equalizer?.let { eq ->
        val numBands = eq.numberOfBands.toInt().coerceAtLeast(1)
        val range = eq.bandLevelRange
        val minDb = range[0].toInt()
        val maxDb = range[1].toInt()
        for (b in 0 until numBands) {
          val srcIdx = ((b.toFloat() / numBands) * prefs.eqBandsDb.size).toInt()
            .coerceIn(0, prefs.eqBandsDb.lastIndex)
          val millibels = (prefs.eqBandsDb[srcIdx] * 100f).toInt().coerceIn(minDb, maxDb)
          eq.setBandLevel(b.toShort(), millibels.toShort())
        }
      }
    }
    runCatching {
      bassBoost?.let { bb ->
        if (bb.strengthSupported) {
          bb.setStrength((prefs.bassBoostStrength * 1000f).toInt().coerceIn(0, 1000).toShort())
        }
      }
    }
  }

  private fun releaseAudioEffects() {
    runCatching { equalizer?.release() }
    runCatching { bassBoost?.release() }
    equalizer = null
    bassBoost = null
  }

  private fun startWidgetWaveLoop() {
    widgetSyncJob?.cancel()
    widgetSyncJob = serviceScope.launch {
      val powerManager = getSystemService(PowerManager::class.java)
      while (isActive) {
        val interactive = powerManager?.isInteractive ?: true
        if (activePlayer.isPlaying && interactive) {
          wavePhase = (wavePhase + 0.36f) % (2f * PI.toFloat())
          pushWidgetNow()
          delay(260L)
        } else {
          delay(900L)
        }
      }
    }
  }

  private suspend fun pushWidgetNow() {
    val state = PlaybackBridge.state.value
    val progress = if (state.durationMs > 0L) {
      state.positionMs.toFloat() / state.durationMs.toFloat()
    } else {
      0f
    }
    SeamlessWidgetUpdater.pushUpdate(
      context = applicationContext,
      track = state.currentTrack,
      isPlaying = state.isPlaying,
      progress = progress,
      wavePhase = wavePhase,
      prefs = latestPrefs,
      infinityState = AudioAnalyzerBus.infinityState.value,
    )
  }

  private fun Track.toMediaItem(): MediaItem {
    val meta = MediaMetadata.Builder()
      .setTitle(title)
      .setArtist(artist)
      .setAlbumTitle(album)
      .setArtworkUri(albumArtUri)
      .build()
    return MediaItem.Builder()
      .setMediaId(id.toString())
      .setUri(uri)
      .setMediaMetadata(meta)
      .build()
  }

  override fun onDestroy() {
    PlaybackBridge.serviceRef = null
    cancelCrossfade()
    monitorJob?.cancel()
    widgetSyncJob?.cancel()
    sleepTimerJob?.cancel()
    releaseAudioEffects()
    mediaSession?.release()
    mediaSession = null
    deckA.release()
    deckB.release()
    serviceScope.cancel()
    super.onDestroy()
  }

  companion object {
    private const val BOOT_NOTIFICATION_ID = 9401
    const val EXTRA_STARTED_FOREGROUND = "com.example.seamless.EXTRA_STARTED_FOREGROUND"
    const val ACTION_TOGGLE_PLAY_PAUSE = "com.example.seamless.ACTION_TOGGLE_PLAY_PAUSE"
    const val ACTION_NEXT = "com.example.seamless.ACTION_NEXT"
    const val ACTION_PREVIOUS = "com.example.seamless.ACTION_PREVIOUS"
    const val ACTION_TOGGLE_INFINITY = "com.example.seamless.ACTION_TOGGLE_INFINITY"
  }
}
