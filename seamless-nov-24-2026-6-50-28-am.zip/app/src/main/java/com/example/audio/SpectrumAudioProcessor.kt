package com.example.audio

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import com.example.model.AudioFrame
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Sample-accurate ExoPlayer AudioProcessor that:
 * 1) Applies smooth Infinity gain & harmonic bass-crossover tilt per deck.
 * 2) Feeds a real 256-point Radix-2 FFT + waveform + onset beat detector to AudioAnalyzerBus.
 */
@OptIn(UnstableApi::class)
class SeamlessDeckAudioProcessor(
  private val isPrimaryAnalyzerSource: () -> Boolean,
) : BaseAudioProcessor() {

  @Volatile
  var deckGain: Float = 1.0f

  @Volatile
  var bassTiltGain: Float = 1.0f // < 1.0 gently attenuates low frequencies during Harmonic Mashup

  @Volatile
  var highTiltGain: Float = 1.0f

  private var channelCount = 2
  private var sampleRate = 44100

  // One-pole low-pass filter state per channel for Harmonic Mashup bass handover
  private var lpL = 0f
  private var lpR = 0f

  // FFT ring buffer (256 mono samples)
  private val fftSize = 256
  private val ring = FloatArray(fftSize)
  private var ringPos = 0
  private var samplesSinceEmit = 0

  private val real = FloatArray(fftSize)
  private val imag = FloatArray(fftSize)
  private val hann = FloatArray(fftSize) { i ->
    (0.5 * (1.0 - cos(2.0 * PI * i / (fftSize - 1)))).toFloat()
  }

  private val smoothedBands = FloatArray(48)
  private val smoothedWave = FloatArray(64)
  private var prevBass = 0f
  private var beatPulse = 0f
  private var phase = 0f

  override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
    if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
      throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
    }
    channelCount = max(1, inputAudioFormat.channelCount)
    sampleRate = max(8000, inputAudioFormat.sampleRate)
    lpL = 0f
    lpR = 0f
    return inputAudioFormat
  }

  override fun queueInput(inputBuffer: ByteBuffer) {
    val remaining = inputBuffer.remaining()
    if (remaining == 0) return

    val outputBuffer = replaceOutputBuffer(remaining)
    inputBuffer.order(ByteOrder.LITTLE_ENDIAN)
    outputBuffer.order(ByteOrder.LITTLE_ENDIAN)

    val gain = deckGain
    val bassGain = bassTiltGain
    val highGain = highTiltGain
    val applyFilter = bassGain < 0.99f || highGain < 0.99f
    // ~160 Hz one-pole cutoff coefficient
    val alpha = (2.0 * PI * 160.0 / sampleRate).toFloat().coerceIn(0.005f, 0.25f)

    val frames = remaining / (2 * channelCount)
    val shouldAnalyze = isPrimaryAnalyzerSource() || gain > 0.05f

    for (f in 0 until frames) {
      var monoSum = 0f
      for (c in 0 until channelCount) {
        val sample = inputBuffer.short.toFloat() / 32768f
        val processed = if (applyFilter) {
          val lp = if (c == 0) {
            lpL += alpha * (sample - lpL)
            lpL
          } else {
            lpR += alpha * (sample - lpR)
            lpR
          }
          val hp = sample - lp
          (lp * bassGain + hp * highGain) * gain
        } else {
          sample * gain
        }

        monoSum += processed
        val outShort = (processed * 32767f).toInt().coerceIn(-32768, 32767).toShort()
        outputBuffer.putShort(outShort)
      }

      if (shouldAnalyze) {
        val mono = monoSum / channelCount
        ring[ringPos] = mono
        ringPos = (ringPos + 1) and (fftSize - 1)
        samplesSinceEmit++
        // Emit roughly ~45–60 analysis frames per second
        val emitThreshold = (sampleRate / 50).coerceAtLeast(256)
        if (samplesSinceEmit >= emitThreshold) {
          samplesSinceEmit = 0
          computeAndPublishAnalysis()
        }
      }
    }

    outputBuffer.flip()
  }

  private fun computeAndPublishAnalysis() {
    // Copy ring chronologically into real[] with Hann window, and downsample 64 wave samples
    var rmsAcc = 0f
    for (i in 0 until fftSize) {
      val s = ring[(ringPos + i) and (fftSize - 1)]
      rmsAcc += s * s
      real[i] = s * hann[i]
      imag[i] = 0f
    }
    for (i in 0 until 64) {
      val src = ring[(ringPos + i * 4) and (fftSize - 1)]
      smoothedWave[i] = smoothedWave[i] * 0.45f + src * 0.55f
    }

    fft256(real, imag)

    // Map 128 positive frequency bins logarithmically into 48 perceptual bands
    val halfBins = fftSize / 2
    var bassSum = 0f
    var midSum = 0f
    var trebleSum = 0f

    for (b in 0 until 48) {
      val startBin = (1.0 * halfBins.toDouble().pow(b / 48.0)).toInt().coerceIn(1, halfBins - 1)
      val endBin = (1.0 * halfBins.toDouble().pow((b + 1) / 48.0)).toInt().coerceIn(startBin, halfBins - 1)

      var peak = 0f
      for (k in startBin..endBin) {
        val mag = sqrt(real[k] * real[k] + imag[k] * imag[k]) / (fftSize * 0.25f)
        if (mag > peak) peak = mag
      }
      // Perceptual log compression + gentle high-frequency compensation
      val tilt = 1f + (b / 48f) * 0.85f
      val normalized = (ln(1f + peak * tilt * 14f) / ln(15f)).coerceIn(0f, 1f)
      val prev = smoothedBands[b]
      smoothedBands[b] = if (normalized > prev) {
        prev * 0.25f + normalized * 0.75f // Fast attack
      } else {
        prev * 0.78f + normalized * 0.22f // Smooth musical decay
      }

      when {
        b < 10 -> bassSum += smoothedBands[b]
        b < 28 -> midSum += smoothedBands[b]
        else -> trebleSum += smoothedBands[b]
      }
    }

    val bass = (bassSum / 10f).coerceIn(0f, 1f)
    val mid = (midSum / 18f).coerceIn(0f, 1f)
    val treble = (trebleSum / 20f).coerceIn(0f, 1f)
    val rms = sqrt(rmsAcc / fftSize).times(2.6f).coerceIn(0f, 1f)

    // Spectral flux transient / beat pulse detection
    val bassFlux = max(0f, bass - prevBass)
    prevBass = bass * 0.85f + prevBass * 0.15f
    if (bassFlux > 0.055f && bass > 0.22f) {
      beatPulse = min(1f, beatPulse + bassFlux * 3.8f)
    } else {
      beatPulse = (beatPulse * 0.86f).coerceAtLeast(0f)
    }

    phase = (phase + 0.06f + rms * 0.14f) % (2f * PI.toFloat())

    AudioAnalyzerBus.publishFrame(
      AudioFrame(
        spectrum = smoothedBands.copyOf(),
        waveform = smoothedWave.copyOf(),
        bassEnergy = bass,
        midEnergy = mid,
        trebleEnergy = treble,
        overallRms = rms,
        beatPulse = beatPulse,
        phase = phase,
      )
    )
  }

  private fun fft256(re: FloatArray, im: FloatArray) {
    val n = fftSize
    var j = 0
    for (i in 1 until n) {
      var bit = n shr 1
      while (j and bit != 0) {
        j = j xor bit
        bit = bit shr 1
      }
      j = j xor bit
      if (i < j) {
        val tr = re[i]; re[i] = re[j]; re[j] = tr
        val ti = im[i]; im[i] = im[j]; im[j] = ti
      }
    }
    var len = 2
    while (len <= n) {
      val ang = (-2.0 * PI / len)
      val wLenRe = cos(ang).toFloat()
      val wLenIm = sin(ang).toFloat()
      var i = 0
      while (i < n) {
        var wRe = 1f
        var wIm = 0f
        for (k in 0 until len / 2) {
          val uRe = re[i + k]
          val uIm = im[i + k]
          val idx = i + k + len / 2
          val vRe = re[idx] * wRe - im[idx] * wIm
          val vIm = re[idx] * wIm + im[idx] * wRe
          re[i + k] = uRe + vRe
          im[i + k] = uIm + vIm
          re[idx] = uRe - vRe
          im[idx] = uIm - vIm
          val nextWRe = wRe * wLenRe - wIm * wLenIm
          wIm = wRe * wLenIm + wIm * wLenRe
          wRe = nextWRe
        }
        i += len
      }
      len = len shl 1
    }
  }
}
