package com.example.audio

import com.example.model.RepeatModeOption
import com.example.model.Track
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class PlaybackUiState(
  val queue: List<Track> = emptyList(),
  val currentIndex: Int = -1,
  val currentTrack: Track? = null,
  val isPlaying: Boolean = false,
  val positionMs: Long = 0L,
  val durationMs: Long = 0L,
  val shuffleEnabled: Boolean = false,
  val repeatMode: RepeatModeOption = RepeatModeOption.ALL,
  val sleepTimerRemainingMs: Long? = null,
)

object PlaybackBridge {

  private val _state = MutableStateFlow(PlaybackUiState())
  val state: StateFlow<PlaybackUiState> = _state.asStateFlow()

  internal var serviceRef: SeamlessPlaybackService? = null

  internal fun updateState(transform: (PlaybackUiState) -> PlaybackUiState) {
    _state.value = transform(_state.value)
  }

  fun playQueue(tracks: List<Track>, startIndex: Int) {
    serviceRef?.playQueue(tracks, startIndex)
  }

  fun togglePlayPause() {
    serviceRef?.togglePlayPause()
  }

  fun next(forceInfinityMashup: Boolean = false) {
    serviceRef?.skipToNext(forceInfinityMashup)
  }

  fun previous() {
    serviceRef?.skipToPrevious()
  }

  fun seekTo(positionMs: Long) {
    serviceRef?.seekTo(positionMs)
  }

  fun toggleShuffle() {
    serviceRef?.toggleShuffle()
  }

  fun cycleRepeatMode() {
    serviceRef?.cycleRepeatMode()
  }

  fun setSleepTimerMinutes(minutes: Int?) {
    serviceRef?.setSleepTimerMinutes(minutes)
  }

  fun moveQueueItem(fromIndex: Int, toIndex: Int) {
    serviceRef?.moveQueueItem(fromIndex, toIndex)
  }

  fun removeFromQueue(index: Int) {
    serviceRef?.removeFromQueue(index)
  }

  fun jumpToQueueIndex(index: Int) {
    serviceRef?.jumpToQueueIndex(index)
  }
}
