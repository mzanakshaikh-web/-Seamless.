package com.example.data

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.content.ContextCompat
import com.example.model.Track
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DeviceAudioRepository(private val context: Context) {

  private val prefs by lazy {
    context.getSharedPreferences("seamless_imported_tracks", Context.MODE_PRIVATE)
  }

  fun hasAudioReadPermission(): Boolean {
    val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      Manifest.permission.READ_MEDIA_AUDIO
    } else {
      Manifest.permission.READ_EXTERNAL_STORAGE
    }
    return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
  }

  suspend fun loadAllTracks(): List<Track> = withContext(Dispatchers.IO) {
    val result = mutableListOf<Track>()
    if (hasAudioReadPermission()) {
      result.addAll(queryMediaStore())
    }
    result.addAll(loadImportedTracks())
    result.addAll(loadSoundcheckTracks())
    result.distinctBy { it.uri.toString() }
  }

  private fun queryMediaStore(): List<Track> {
    val tracks = mutableListOf<Track>()
    val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
    } else {
      MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    }

    val projection = arrayOf(
      MediaStore.Audio.Media._ID,
      MediaStore.Audio.Media.TITLE,
      MediaStore.Audio.Media.ARTIST,
      MediaStore.Audio.Media.ALBUM,
      MediaStore.Audio.Media.ALBUM_ID,
      MediaStore.Audio.Media.DURATION,
      MediaStore.Audio.Media.DATA,
      MediaStore.Audio.Media.MIME_TYPE,
      MediaStore.Audio.Media.DATE_ADDED,
      MediaStore.Audio.Media.SIZE,
      MediaStore.Audio.Media.IS_MUSIC,
    )

    val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 3000"
    val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"
    val albumArtBaseUri = Uri.parse("content://media/external/audio/albumart")

    runCatching {
      context.contentResolver.query(collection, projection, selection, null, sortOrder)?.use { cursor ->
        val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
        val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
        val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
        val dataCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
        val mimeCol = cursor.getColumnIndex(MediaStore.Audio.Media.MIME_TYPE)
        val dateCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)
        val sizeCol = cursor.getColumnIndex(MediaStore.Audio.Media.SIZE)

        while (cursor.moveToNext()) {
          val id = cursor.getLong(idCol)
          val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() } ?: "Untitled Track"
          val rawArtist = cursor.getString(artistCol)
          val artist = if (rawArtist.isNullOrBlank() || rawArtist == "<unknown>") "Unknown Artist" else rawArtist
          val rawAlbum = cursor.getString(albumCol)
          val album = if (rawAlbum.isNullOrBlank() || rawAlbum == "<unknown>") "Single" else rawAlbum
          val albumId = cursor.getLong(albumIdCol)
          val duration = cursor.getLong(durationCol).coerceAtLeast(0L)
          val path = if (dataCol >= 0) cursor.getString(dataCol) else null
          val folderName = path?.let { File(it).parentFile?.name } ?: "Music"
          val mimeType = if (mimeCol >= 0) cursor.getString(mimeCol) ?: "audio/mpeg" else "audio/mpeg"
          val dateAdded = if (dateCol >= 0) cursor.getLong(dateCol) else 0L
          val sizeBytes = if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L

          val contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
          val artUri = if (albumId > 0L) ContentUris.withAppendedId(albumArtBaseUri, albumId) else null

          tracks.add(
            Track(
              id = id,
              uri = contentUri,
              title = title,
              artist = artist,
              album = album,
              albumId = albumId,
              albumArtUri = artUri,
              durationMs = duration,
              folderName = folderName,
              mimeType = mimeType,
              dateAdded = dateAdded,
              sizeBytes = sizeBytes,
            )
          )
        }
      }
    }
    return tracks
  }

  suspend fun importAudioUri(uri: Uri): Track? = withContext(Dispatchers.IO) {
    runCatching {
      context.contentResolver.takePersistableUriPermission(
        uri,
        Intent.FLAG_GRANT_READ_URI_PERMISSION,
      )
    }
    val existing = prefs.getStringSet("uris", emptySet())?.toMutableSet() ?: mutableSetOf()
    existing.add(uri.toString())
    prefs.edit().putStringSet("uris", existing).apply()
    extractTrackFromUri(uri, isImported = true)
  }

  private fun loadImportedTracks(): List<Track> {
    val uris = prefs.getStringSet("uris", emptySet()) ?: return emptyList()
    return uris.mapNotNull { uriString ->
      val uri = Uri.parse(uriString)
      extractTrackFromUri(uri, isImported = true)
    }
  }

  private fun extractTrackFromUri(uri: Uri, isImported: Boolean): Track? {
    return runCatching {
      val retriever = MediaMetadataRetriever()
      retriever.setDataSource(context, uri)
      val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
        ?.takeIf { it.isNotBlank() }
        ?: queryDisplayName(uri)
        ?: "Imported Audio"
      val artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
        ?.takeIf { it.isNotBlank() } ?: "Local Audio"
      val album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
        ?.takeIf { it.isNotBlank() } ?: "Imported"
      val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
        ?.toLongOrNull() ?: 0L
      val mime = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: "audio/*"
      retriever.release()

      Track(
        id = uri.toString().hashCode().toLong().let { if (it >= 0) -it - 1000L else it - 1000L },
        uri = uri,
        title = title,
        artist = artist,
        album = album,
        albumId = 0L,
        albumArtUri = null,
        durationMs = duration,
        folderName = "Imported",
        mimeType = mime,
        isImported = isImported,
      )
    }.getOrNull()
  }

  private fun queryDisplayName(uri: Uri): String? {
    return context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
      if (c.moveToFirst()) c.getString(0)?.substringBeforeLast('.') else null
    }
  }

  private fun loadSoundcheckTracks(): List<Track> {
    val dir = File(context.filesDir, "soundcheck")
    if (!dir.exists()) return emptyList()
    val specs = listOf(
      Triple("soundcheck_matte_horizon.wav", "Matte Horizon", 110.0),
      Triple("soundcheck_cobalt_drift.wav", "Cobalt Drift", 146.83),
      Triple("soundcheck_violet_cadence.wav", "Violet Cadence", 130.81),
    )
    return specs.mapIndexedNotNull { idx, (fileName, title, _) ->
      val f = File(dir, fileName)
      if (!f.exists()) return@mapIndexedNotNull null
      Track(
        id = -9000L - idx,
        uri = Uri.fromFile(f),
        title = title,
        artist = "Seamless Studio",
        album = "Acoustic Soundcheck",
        albumId = 0L,
        albumArtUri = null,
        durationMs = 24_000L,
        folderName = "Soundcheck",
        mimeType = "audio/wav",
        sizeBytes = f.length(),
        isImported = true,
      )
    }
  }

  suspend fun generateStudioSoundcheck(): List<Track> = withContext(Dispatchers.IO) {
    val dir = File(context.filesDir, "soundcheck").apply { mkdirs() }
    val specs = listOf(
      Triple("soundcheck_matte_horizon.wav", 110.0, 2.0),
      Triple("soundcheck_cobalt_drift.wav", 146.83, 2.5),
      Triple("soundcheck_violet_cadence.wav", 130.81, 3.0),
    )
    specs.forEach { (filename, rootHz, pulseHz) ->
      val outFile = File(dir, filename)
      if (!outFile.exists()) {
        writeHarmonicWav(outFile, durationSec = 24, rootHz = rootHz, pulseHz = pulseHz)
      }
    }
    loadAllTracks()
  }

  private fun writeHarmonicWav(file: File, durationSec: Int, rootHz: Double, pulseHz: Double) {
    val sampleRate = 22050
    val numSamples = sampleRate * durationSec
    val dataSize = numSamples * 2
    val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
      put("RIFF".toByteArray())
      putInt(36 + dataSize)
      put("WAVE".toByteArray())
      put("fmt ".toByteArray())
      putInt(16)
      putShort(1) // PCM
      putShort(1) // Mono
      putInt(sampleRate)
      putInt(sampleRate * 2)
      putShort(2)
      putShort(16)
      put("data".toByteArray())
      putInt(dataSize)
    }.array()

    FileOutputStream(file).use { fos ->
      fos.write(header)
      val chunk = ByteArray(4096)
      var idx = 0
      val buf = ByteBuffer.wrap(chunk).order(ByteOrder.LITTLE_ENDIAN)
      for (i in 0 until numSamples) {
        val t = i.toDouble() / sampleRate
        val fadeIn = (t / 0.8).coerceIn(0.0, 1.0)
        val fadeOut = ((durationSec - t) / 1.2).coerceIn(0.0, 1.0)
        val s = 0.5 + 0.5 * sin(2.0 * PI * pulseHz * t)
        val beatEnv = 0.45 + 0.55 * (s * s * s)
        val kick = sin(2.0 * PI * (rootHz * 0.5) * t) * beatEnv * 0.42
        val pad = (
          sin(2.0 * PI * rootHz * t) * 0.25 +
            sin(2.0 * PI * (rootHz * 1.5) * t) * 0.16 +
            sin(2.0 * PI * (rootHz * 2.0) * t) * 0.12 +
            sin(2.0 * PI * (rootHz * 2.99) * t) * (0.06 + 0.06 * sin(2.0 * PI * 0.25 * t))
          )
        val sample = ((kick + pad) * fadeIn * fadeOut * 22000.0).toInt().coerceIn(-32767, 32767).toShort()
        buf.putShort(sample)
        idx += 2
        if (idx >= chunk.size) {
          fos.write(chunk, 0, idx)
          buf.clear()
          idx = 0
        }
      }
      if (idx > 0) {
        fos.write(chunk, 0, idx)
      }
    }
  }
}
