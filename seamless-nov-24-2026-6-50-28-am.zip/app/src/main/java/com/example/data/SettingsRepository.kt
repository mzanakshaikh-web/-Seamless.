package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppThemePreset
import com.example.model.EqPreset
import com.example.model.InfinityBlendProfile
import com.example.model.ReactionStyle
import com.example.model.UserPlaylist
import com.example.model.UserPreferences
import com.example.model.WidgetShapeStyle
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.seamlessDataStore: DataStore<Preferences> by preferencesDataStore(
  name = "seamless_preferences"
)

class SettingsRepository(private val context: Context) {

  private object Keys {
    val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
    val REACTION_STYLE = stringPreferencesKey("reaction_style")
    val THEME_PRESET = stringPreferencesKey("theme_preset")
    val CUSTOM_PRIMARY_ARGB = intPreferencesKey("custom_primary_argb")
    val HAS_CUSTOM_PRIMARY = booleanPreferencesKey("has_custom_primary")
    val CUSTOM_ACCENT_ARGB = intPreferencesKey("custom_accent_argb")
    val HAS_CUSTOM_ACCENT = booleanPreferencesKey("has_custom_accent")
    val INFINITY_ENABLED = booleanPreferencesKey("infinity_enabled")
    val INFINITY_DURATION_SEC = intPreferencesKey("infinity_duration_sec")
    val INFINITY_PROFILE = stringPreferencesKey("infinity_profile")
    val HAPTICS_ENABLED = booleanPreferencesKey("haptics_enabled")
    val EQ_PRESET = stringPreferencesKey("eq_preset")
    val EQ_BANDS_CSV = stringPreferencesKey("eq_bands_csv")
    val BASS_BOOST = floatPreferencesKey("bass_boost")
    val PLAYBACK_SPEED = floatPreferencesKey("playback_speed")
    val WIDGET_SHAPE = stringPreferencesKey("widget_shape")
    val WIDGET_WAVE_INTENSITY = floatPreferencesKey("widget_wave_intensity")
    val WIDGET_MATTE_OPACITY = floatPreferencesKey("widget_matte_opacity")
    val FAVORITES_CSV = stringPreferencesKey("favorites_csv")
    val RECENTS_CSV = stringPreferencesKey("recents_csv")
    val PLAYLISTS_ENCODED = stringPreferencesKey("playlists_encoded")
  }

  val preferencesFlow: Flow<UserPreferences> = context.seamlessDataStore.data.map { prefs ->
    val reactionStyle = runCatching {
      ReactionStyle.valueOf(prefs[Keys.REACTION_STYLE] ?: ReactionStyle.SEAMLESS_PULSE.name)
    }.getOrDefault(ReactionStyle.SEAMLESS_PULSE)

    val themePreset = runCatching {
      AppThemePreset.valueOf(prefs[Keys.THEME_PRESET] ?: AppThemePreset.MATTE_GREY.name)
    }.getOrDefault(AppThemePreset.MATTE_GREY)

    val infinityProfile = runCatching {
      InfinityBlendProfile.valueOf(
        prefs[Keys.INFINITY_PROFILE] ?: InfinityBlendProfile.HARMONIC_MASHUP.name
      )
    }.getOrDefault(InfinityBlendProfile.HARMONIC_MASHUP)

    val eqPreset = runCatching {
      EqPreset.valueOf(prefs[Keys.EQ_PRESET] ?: EqPreset.STUDIO_MATTE.name)
    }.getOrDefault(EqPreset.STUDIO_MATTE)

    val eqBands = prefs[Keys.EQ_BANDS_CSV]
      ?.split(",")
      ?.mapNotNull { it.toFloatOrNull() }
      ?.takeIf { it.size == 5 }
      ?: eqPreset.bandsDb

    val widgetShape = runCatching {
      WidgetShapeStyle.valueOf(prefs[Keys.WIDGET_SHAPE] ?: WidgetShapeStyle.SOFT_SQUIRCLE.name)
    }.getOrDefault(WidgetShapeStyle.SOFT_SQUIRCLE)

    val favorites = prefs[Keys.FAVORITES_CSV]
      ?.split(",")
      ?.mapNotNull { it.toLongOrNull() }
      ?.toSet()
      ?: emptySet()

    val recents = prefs[Keys.RECENTS_CSV]
      ?.split(",")
      ?.mapNotNull { it.toLongOrNull() }
      ?: emptyList()

    val playlists = decodePlaylists(prefs[Keys.PLAYLISTS_ENCODED].orEmpty())

    UserPreferences(
      onboardingCompleted = prefs[Keys.ONBOARDING_COMPLETED] ?: false,
      reactionStyle = reactionStyle,
      themePreset = themePreset,
      customPrimaryArgb = if (prefs[Keys.HAS_CUSTOM_PRIMARY] == true) prefs[Keys.CUSTOM_PRIMARY_ARGB] else null,
      customAccentArgb = if (prefs[Keys.HAS_CUSTOM_ACCENT] == true) prefs[Keys.CUSTOM_ACCENT_ARGB] else null,
      infinityEnabled = prefs[Keys.INFINITY_ENABLED] ?: true,
      infinityDurationSec = (prefs[Keys.INFINITY_DURATION_SEC] ?: 8).coerceIn(3, 18),
      infinityProfile = infinityProfile,
      hapticsEnabled = prefs[Keys.HAPTICS_ENABLED] ?: true,
      eqPreset = eqPreset,
      eqBandsDb = eqBands,
      bassBoostStrength = (prefs[Keys.BASS_BOOST] ?: 0.2f).coerceIn(0f, 1f),
      playbackSpeed = (prefs[Keys.PLAYBACK_SPEED] ?: 1.0f).coerceIn(0.75f, 1.5f),
      widgetShapeStyle = widgetShape,
      widgetWaveIntensity = (prefs[Keys.WIDGET_WAVE_INTENSITY] ?: 0.85f).coerceIn(0.2f, 1.4f),
      widgetMatteOpacity = (prefs[Keys.WIDGET_MATTE_OPACITY] ?: 0.94f).coerceIn(0.55f, 1f),
      favoriteIds = favorites,
      recentTrackIds = recents,
      playlists = playlists,
    )
  }

  suspend fun completeOnboarding(style: ReactionStyle) {
    context.seamlessDataStore.edit { prefs ->
      prefs[Keys.REACTION_STYLE] = style.name
      prefs[Keys.ONBOARDING_COMPLETED] = true
    }
  }

  suspend fun setReactionStyle(style: ReactionStyle) {
    context.seamlessDataStore.edit { it[Keys.REACTION_STYLE] = style.name }
  }

  suspend fun setThemePreset(preset: AppThemePreset) {
    context.seamlessDataStore.edit { prefs ->
      prefs[Keys.THEME_PRESET] = preset.name
      prefs[Keys.HAS_CUSTOM_PRIMARY] = false
      prefs[Keys.HAS_CUSTOM_ACCENT] = false
    }
  }

  suspend fun setCustomPrimary(argb: Int?) {
    context.seamlessDataStore.edit { prefs ->
      if (argb == null) {
        prefs[Keys.HAS_CUSTOM_PRIMARY] = false
      } else {
        prefs[Keys.HAS_CUSTOM_PRIMARY] = true
        prefs[Keys.CUSTOM_PRIMARY_ARGB] = argb
      }
    }
  }

  suspend fun setCustomAccent(argb: Int?) {
    context.seamlessDataStore.edit { prefs ->
      if (argb == null) {
        prefs[Keys.HAS_CUSTOM_ACCENT] = false
      } else {
        prefs[Keys.HAS_CUSTOM_ACCENT] = true
        prefs[Keys.CUSTOM_ACCENT_ARGB] = argb
      }
    }
  }

  suspend fun setInfinityEnabled(enabled: Boolean) {
    context.seamlessDataStore.edit { it[Keys.INFINITY_ENABLED] = enabled }
  }

  suspend fun setInfinityDurationSec(seconds: Int) {
    context.seamlessDataStore.edit { it[Keys.INFINITY_DURATION_SEC] = seconds.coerceIn(3, 18) }
  }

  suspend fun setInfinityProfile(profile: InfinityBlendProfile) {
    context.seamlessDataStore.edit { it[Keys.INFINITY_PROFILE] = profile.name }
  }

  suspend fun setHapticsEnabled(enabled: Boolean) {
    context.seamlessDataStore.edit { it[Keys.HAPTICS_ENABLED] = enabled }
  }

  suspend fun setEqPreset(preset: EqPreset) {
    context.seamlessDataStore.edit { prefs ->
      prefs[Keys.EQ_PRESET] = preset.name
      if (preset != EqPreset.CUSTOM) {
        prefs[Keys.EQ_BANDS_CSV] = preset.bandsDb.joinToString(",")
      }
    }
  }

  suspend fun setEqBands(bandsDb: List<Float>) {
    context.seamlessDataStore.edit { prefs ->
      prefs[Keys.EQ_PRESET] = EqPreset.CUSTOM.name
      prefs[Keys.EQ_BANDS_CSV] = bandsDb.joinToString(",")
    }
  }

  suspend fun setBassBoost(strength: Float) {
    context.seamlessDataStore.edit { it[Keys.BASS_BOOST] = strength.coerceIn(0f, 1f) }
  }

  suspend fun setPlaybackSpeed(speed: Float) {
    context.seamlessDataStore.edit { it[Keys.PLAYBACK_SPEED] = speed.coerceIn(0.75f, 1.5f) }
  }

  suspend fun setWidgetShapeStyle(style: WidgetShapeStyle) {
    context.seamlessDataStore.edit { it[Keys.WIDGET_SHAPE] = style.name }
  }

  suspend fun setWidgetWaveIntensity(intensity: Float) {
    context.seamlessDataStore.edit { it[Keys.WIDGET_WAVE_INTENSITY] = intensity.coerceIn(0.2f, 1.4f) }
  }

  suspend fun setWidgetMatteOpacity(opacity: Float) {
    context.seamlessDataStore.edit { it[Keys.WIDGET_MATTE_OPACITY] = opacity.coerceIn(0.55f, 1f) }
  }

  suspend fun toggleFavorite(trackId: Long) {
    context.seamlessDataStore.edit { prefs ->
      val current = prefs[Keys.FAVORITES_CSV]
        ?.split(",")
        ?.mapNotNull { it.toLongOrNull() }
        ?.toMutableSet()
        ?: mutableSetOf()
      if (!current.add(trackId)) {
        current.remove(trackId)
      }
      prefs[Keys.FAVORITES_CSV] = current.joinToString(",")
    }
  }

  suspend fun recordRecentTrack(trackId: Long) {
    context.seamlessDataStore.edit { prefs ->
      val current = prefs[Keys.RECENTS_CSV]
        ?.split(",")
        ?.mapNotNull { it.toLongOrNull() }
        ?.toMutableList()
        ?: mutableListOf()
      current.remove(trackId)
      current.add(0, trackId)
      prefs[Keys.RECENTS_CSV] = current.take(24).joinToString(",")
    }
  }

  suspend fun createPlaylist(name: String, initialTrackId: Long? = null) {
    val cleanName = name.trim().replace("|", " ").replace(";", " ")
    if (cleanName.isEmpty()) return
    context.seamlessDataStore.edit { prefs ->
      val current = decodePlaylists(prefs[Keys.PLAYLISTS_ENCODED].orEmpty()).toMutableList()
      val id = "pl_${System.currentTimeMillis()}"
      current.add(
        UserPlaylist(
          id = id,
          name = cleanName,
          trackIds = if (initialTrackId != null) listOf(initialTrackId) else emptyList(),
        )
      )
      prefs[Keys.PLAYLISTS_ENCODED] = encodePlaylists(current)
    }
  }

  suspend fun addTrackToPlaylist(playlistId: String, trackId: Long) {
    context.seamlessDataStore.edit { prefs ->
      val current = decodePlaylists(prefs[Keys.PLAYLISTS_ENCODED].orEmpty()).map { pl ->
        if (pl.id == playlistId && trackId !in pl.trackIds) {
          pl.copy(trackIds = pl.trackIds + trackId)
        } else {
          pl
        }
      }
      prefs[Keys.PLAYLISTS_ENCODED] = encodePlaylists(current)
    }
  }

  suspend fun deletePlaylist(playlistId: String) {
    context.seamlessDataStore.edit { prefs ->
      val current = decodePlaylists(prefs[Keys.PLAYLISTS_ENCODED].orEmpty()).filterNot { it.id == playlistId }
      prefs[Keys.PLAYLISTS_ENCODED] = encodePlaylists(current)
    }
  }

  private fun encodePlaylists(list: List<UserPlaylist>): String =
    list.joinToString(";") { pl ->
      "${pl.id}|${pl.name}|${pl.trackIds.joinToString(",")}"
    }

  private fun decodePlaylists(raw: String): List<UserPlaylist> {
    if (raw.isBlank()) return emptyList()
    return raw.split(";").mapNotNull { entry ->
      val parts = entry.split("|")
      if (parts.size < 2) return@mapNotNull null
      val ids = parts.getOrNull(2)
        ?.split(",")
        ?.mapNotNull { it.toLongOrNull() }
        ?: emptyList()
      UserPlaylist(id = parts[0], name = parts[1], trackIds = ids)
    }
  }
}
