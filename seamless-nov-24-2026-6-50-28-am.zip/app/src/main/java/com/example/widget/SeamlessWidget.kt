package com.example.widget

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.glance.ColorFilter
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.LocalSize
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.currentState
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.ContentScale
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.state.GlanceStateDefinition
import androidx.glance.state.PreferencesGlanceStateDefinition
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.example.MainActivity
import com.example.R
import com.example.audio.AudioAnalyzerBus
import com.example.audio.SeamlessPlaybackService

class SeamlessWidgetReceiver : GlanceAppWidgetReceiver() {
  override val glanceAppWidget: GlanceAppWidget = SeamlessWidget()
}

class SeamlessWidget : GlanceAppWidget() {

  override val stateDefinition: GlanceStateDefinition<*> = PreferencesGlanceStateDefinition
  override val sizeMode: SizeMode = SizeMode.Exact

  override suspend fun provideGlance(context: Context, id: GlanceId) {
    var cachedArtUri: String? = null
    var cachedArtBitmap: android.graphics.Bitmap? = null

    provideContent {
      val prefs = currentState<Preferences>()
      val size = LocalSize.current

      val title = prefs[KEY_TITLE] ?: "Seamless"
      val artist = prefs[KEY_ARTIST] ?: "Tap to play device audio"
      val album = prefs[KEY_ALBUM] ?: ""
      val isPlaying = prefs[KEY_IS_PLAYING] ?: false
      val infinityOn = prefs[KEY_INFINITY_ON] ?: true
      val isBlending = prefs[KEY_IS_BLENDING] ?: false
      val progress = (prefs[KEY_PROGRESS] ?: 0f).coerceIn(0f, 1f)
      val artUri = prefs[KEY_ART_URI]

      val bgArgb = prefs[KEY_BG_ARGB] ?: 0xFF212428.toInt()
      val surfaceArgb = prefs[KEY_SURFACE_ARGB] ?: 0xFF2D3137.toInt()
      val primaryArgb = prefs[KEY_PRIMARY_ARGB] ?: 0xFF3EE6B5.toInt()
      val secondaryArgb = prefs[KEY_SECONDARY_ARGB] ?: 0xFF4D8EFF.toInt()
      val tertiaryArgb = prefs[KEY_TERTIARY_ARGB] ?: 0xFF9A5BFF.toInt()
      val textArgb = prefs[KEY_TEXT_ARGB] ?: 0xFFF0F2F5.toInt()
      val mutedArgb = prefs[KEY_MUTED_ARGB] ?: 0xFF9AA1AB.toInt()
      val cornerDp = (prefs[KEY_CORNER_DP] ?: 24).coerceIn(6, 40)
      val waveIntensity = prefs[KEY_WAVE_INTENSITY] ?: 0.85f
      val matteOpacity = (prefs[KEY_MATTE_OPACITY] ?: 0.94f).coerceIn(0.55f, 1f)
      val phase = prefs[KEY_WAVE_PHASE] ?: 0f

      if (artUri != cachedArtUri) {
        cachedArtUri = artUri
        cachedArtBitmap = WidgetWaveRenderer.decodeDownsampledArtwork(context, artUri, targetPx = 96)
      }

      val liveFrame = AudioAnalyzerBus.audioFrame.value
      val waveWidth = (size.width.value.toInt().coerceIn(120, 380))
      val waveHeight = when {
        size.height < 80.dp -> 52
        size.height < 140.dp -> 68
        else -> 96
      }
      val waveBitmap = WidgetWaveRenderer.renderWaveBitmap(
        widthPx = waveWidth,
        heightPx = waveHeight,
        frame = liveFrame,
        isPlaying = isPlaying,
        primaryArgb = primaryArgb,
        secondaryArgb = secondaryArgb,
        tertiaryArgb = tertiaryArgb,
        waveIntensity = waveIntensity,
        phaseOffset = phase,
      )

      val bgColor = Color(bgArgb).copy(alpha = matteOpacity)
      val surfaceColor = Color(surfaceArgb)
      val primaryColor = Color(primaryArgb)
      val textColor = Color(textArgb)
      val mutedColor = Color(mutedArgb)

      GlanceTheme {
        Box(
          modifier = GlanceModifier
            .fillMaxSize()
            .cornerRadius(cornerDp.dp)
            .background(ColorProvider(bgColor))
            .clickable(actionStartActivity<MainActivity>()),
        ) {
          when {
            size.width < 145.dp || size.height < 76.dp -> {
              MicroWidgetLayout(
                title = title,
                isPlaying = isPlaying,
                artBitmap = cachedArtBitmap,
                waveBitmap = waveBitmap,
                primaryColor = primaryColor,
                surfaceColor = surfaceColor,
                textColor = textColor,
                cornerDp = cornerDp.dp,
              )
            }
            size.height < 126.dp -> {
              CompactWideWidgetLayout(
                title = title,
                artist = artist,
                isPlaying = isPlaying,
                artBitmap = cachedArtBitmap,
                waveBitmap = waveBitmap,
                primaryColor = primaryColor,
                surfaceColor = surfaceColor,
                textColor = textColor,
                mutedColor = mutedColor,
                cornerDp = (cornerDp - 6).coerceAtLeast(8).dp,
              )
            }
            size.height < 210.dp -> {
              StandardCardWidgetLayout(
                title = title,
                artist = artist,
                isPlaying = isPlaying,
                infinityOn = infinityOn,
                isBlending = isBlending,
                progress = progress,
                artBitmap = cachedArtBitmap,
                waveBitmap = waveBitmap,
                primaryColor = primaryColor,
                surfaceColor = surfaceColor,
                textColor = textColor,
                mutedColor = mutedColor,
                cornerDp = (cornerDp - 6).coerceAtLeast(8).dp,
              )
            }
            else -> {
              ExpandedStudioWidgetLayout(
                title = title,
                artist = artist,
                album = album,
                isPlaying = isPlaying,
                infinityOn = infinityOn,
                isBlending = isBlending,
                progress = progress,
                artBitmap = cachedArtBitmap,
                waveBitmap = waveBitmap,
                primaryColor = primaryColor,
                surfaceColor = surfaceColor,
                textColor = textColor,
                mutedColor = mutedColor,
                cornerDp = (cornerDp - 4).coerceAtLeast(10).dp,
              )
            }
          }
        }
      }
    }
  }

  companion object {
    val KEY_REVISION = intPreferencesKey("revision")
    val KEY_TITLE = stringPreferencesKey("title")
    val KEY_ARTIST = stringPreferencesKey("artist")
    val KEY_ALBUM = stringPreferencesKey("album")
    val KEY_ART_URI = stringPreferencesKey("art_uri")
    val KEY_IS_PLAYING = booleanPreferencesKey("is_playing")
    val KEY_INFINITY_ON = booleanPreferencesKey("infinity_on")
    val KEY_IS_BLENDING = booleanPreferencesKey("is_blending")
    val KEY_PROGRESS = floatPreferencesKey("progress")
    val KEY_WAVE_PHASE = floatPreferencesKey("wave_phase")
    val KEY_BG_ARGB = intPreferencesKey("bg_argb")
    val KEY_SURFACE_ARGB = intPreferencesKey("surface_argb")
    val KEY_PRIMARY_ARGB = intPreferencesKey("primary_argb")
    val KEY_SECONDARY_ARGB = intPreferencesKey("secondary_argb")
    val KEY_TERTIARY_ARGB = intPreferencesKey("tertiary_argb")
    val KEY_TEXT_ARGB = intPreferencesKey("text_argb")
    val KEY_MUTED_ARGB = intPreferencesKey("muted_argb")
    val KEY_CORNER_DP = intPreferencesKey("corner_dp")
    val KEY_WAVE_INTENSITY = floatPreferencesKey("wave_intensity")
    val KEY_MATTE_OPACITY = floatPreferencesKey("matte_opacity")
  }
}

@Composable
private fun MicroWidgetLayout(
  title: String,
  isPlaying: Boolean,
  artBitmap: android.graphics.Bitmap?,
  waveBitmap: android.graphics.Bitmap,
  primaryColor: Color,
  surfaceColor: Color,
  textColor: Color,
  cornerDp: Dp,
) {
  Box(modifier = GlanceModifier.fillMaxSize()) {
    Image(
      provider = ImageProvider(waveBitmap),
      contentDescription = null,
      contentScale = ContentScale.FillBounds,
      modifier = GlanceModifier.fillMaxSize(),
    )
    Row(
      modifier = GlanceModifier
        .fillMaxSize()
        .padding(horizontal = 10.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      ArtworkThumb(artBitmap = artBitmap, sizeDp = 34.dp, cornerDp = cornerDp)
      Spacer(modifier = GlanceModifier.width(8.dp))
      Text(
        text = title,
        maxLines = 1,
        style = TextStyle(color = ColorProvider(textColor), fontSize = 12.sp, fontWeight = FontWeight.Medium),
        modifier = GlanceModifier.defaultWeight(),
      )
      Spacer(modifier = GlanceModifier.width(6.dp))
      PlayPauseOrb(isPlaying = isPlaying, primaryColor = primaryColor, surfaceColor = surfaceColor, sizeDp = 34.dp)
    }
  }
}

@Composable
private fun CompactWideWidgetLayout(
  title: String,
  artist: String,
  isPlaying: Boolean,
  artBitmap: android.graphics.Bitmap?,
  waveBitmap: android.graphics.Bitmap,
  primaryColor: Color,
  surfaceColor: Color,
  textColor: Color,
  mutedColor: Color,
  cornerDp: Dp,
) {
  Box(modifier = GlanceModifier.fillMaxSize()) {
    Image(
      provider = ImageProvider(waveBitmap),
      contentDescription = null,
      contentScale = ContentScale.FillBounds,
      modifier = GlanceModifier.fillMaxWidth().height(52.dp).padding(top = 18.dp),
    )
    Row(
      modifier = GlanceModifier
        .fillMaxSize()
        .padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      ArtworkThumb(artBitmap = artBitmap, sizeDp = 46.dp, cornerDp = cornerDp)
      Spacer(modifier = GlanceModifier.width(10.dp))
      Column(modifier = GlanceModifier.defaultWeight()) {
        Text(
          text = title,
          maxLines = 1,
          style = TextStyle(color = ColorProvider(textColor), fontSize = 14.sp, fontWeight = FontWeight.Bold),
        )
        Text(
          text = artist,
          maxLines = 1,
          style = TextStyle(color = ColorProvider(mutedColor), fontSize = 11.sp),
        )
      }
      Spacer(modifier = GlanceModifier.width(6.dp))
      IconControl(R.drawable.ic_widget_prev, "Previous", textColor, actionRunCallback<WidgetPrevAction>())
      Spacer(modifier = GlanceModifier.width(4.dp))
      PlayPauseOrb(isPlaying = isPlaying, primaryColor = primaryColor, surfaceColor = surfaceColor, sizeDp = 38.dp)
      Spacer(modifier = GlanceModifier.width(4.dp))
      IconControl(R.drawable.ic_widget_next, "Next", textColor, actionRunCallback<WidgetNextAction>())
    }
  }
}

@Composable
private fun StandardCardWidgetLayout(
  title: String,
  artist: String,
  isPlaying: Boolean,
  infinityOn: Boolean,
  isBlending: Boolean,
  progress: Float,
  artBitmap: android.graphics.Bitmap?,
  waveBitmap: android.graphics.Bitmap,
  primaryColor: Color,
  surfaceColor: Color,
  textColor: Color,
  mutedColor: Color,
  cornerDp: Dp,
) {
  Column(
    modifier = GlanceModifier
      .fillMaxSize()
      .padding(14.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Row(
      modifier = GlanceModifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      ArtworkThumb(artBitmap = artBitmap, sizeDp = 48.dp, cornerDp = cornerDp)
      Spacer(modifier = GlanceModifier.width(12.dp))
      Column(modifier = GlanceModifier.defaultWeight()) {
        Text(
          text = title,
          maxLines = 1,
          style = TextStyle(color = ColorProvider(textColor), fontSize = 15.sp, fontWeight = FontWeight.Bold),
        )
        Text(
          text = if (isBlending) "∞ Blending seamlessly..." else artist,
          maxLines = 1,
          style = TextStyle(
            color = ColorProvider(if (isBlending) primaryColor else mutedColor),
            fontSize = 12.sp,
          ),
        )
      }
      Box(
        modifier = GlanceModifier
          .cornerRadius(14.dp)
          .background(ColorProvider(if (infinityOn) primaryColor.copy(alpha = 0.22f) else surfaceColor))
          .clickable(actionRunCallback<WidgetToggleInfinityAction>())
          .padding(horizontal = 8.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center,
      ) {
        Image(
          provider = ImageProvider(R.drawable.ic_widget_infinity),
          contentDescription = "Infinity Blend",
          colorFilter = ColorFilter.tint(ColorProvider(if (infinityOn) primaryColor else mutedColor)),
          modifier = GlanceModifier.size(16.dp),
        )
      }
    }

    Spacer(modifier = GlanceModifier.height(6.dp))

    Image(
      provider = ImageProvider(waveBitmap),
      contentDescription = "Audio reactive wave",
      contentScale = ContentScale.FillBounds,
      modifier = GlanceModifier.fillMaxWidth().defaultWeight(),
    )

    Spacer(modifier = GlanceModifier.height(6.dp))

    Row(
      modifier = GlanceModifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = "${(progress * 100).toInt()}%",
        style = TextStyle(color = ColorProvider(mutedColor), fontSize = 10.sp),
        modifier = GlanceModifier.defaultWeight(),
      )
      IconControl(R.drawable.ic_widget_prev, "Previous", textColor, actionRunCallback<WidgetPrevAction>())
      Spacer(modifier = GlanceModifier.width(10.dp))
      PlayPauseOrb(isPlaying = isPlaying, primaryColor = primaryColor, surfaceColor = surfaceColor, sizeDp = 40.dp)
      Spacer(modifier = GlanceModifier.width(10.dp))
      IconControl(R.drawable.ic_widget_next, "Next", textColor, actionRunCallback<WidgetNextAction>())
    }
  }
}

@Composable
private fun ExpandedStudioWidgetLayout(
  title: String,
  artist: String,
  album: String,
  isPlaying: Boolean,
  infinityOn: Boolean,
  isBlending: Boolean,
  progress: Float,
  artBitmap: android.graphics.Bitmap?,
  waveBitmap: android.graphics.Bitmap,
  primaryColor: Color,
  surfaceColor: Color,
  textColor: Color,
  mutedColor: Color,
  cornerDp: Dp,
) {
  Column(
    modifier = GlanceModifier
      .fillMaxSize()
      .padding(16.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Row(
      modifier = GlanceModifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      ArtworkThumb(artBitmap = artBitmap, sizeDp = 64.dp, cornerDp = cornerDp)
      Spacer(modifier = GlanceModifier.width(14.dp))
      Column(modifier = GlanceModifier.defaultWeight()) {
        Text(
          text = title,
          maxLines = 1,
          style = TextStyle(color = ColorProvider(textColor), fontSize = 17.sp, fontWeight = FontWeight.Bold),
        )
        Text(
          text = artist,
          maxLines = 1,
          style = TextStyle(color = ColorProvider(mutedColor), fontSize = 13.sp),
        )
        if (album.isNotBlank()) {
          Text(
            text = album,
            maxLines = 1,
            style = TextStyle(color = ColorProvider(mutedColor.copy(alpha = 0.75f)), fontSize = 11.sp),
          )
        }
      }
    }

    Spacer(modifier = GlanceModifier.height(10.dp))

    Image(
      provider = ImageProvider(waveBitmap),
      contentDescription = "Audio reactive wave",
      contentScale = ContentScale.FillBounds,
      modifier = GlanceModifier.fillMaxWidth().defaultWeight(),
    )

    Spacer(modifier = GlanceModifier.height(10.dp))

    Row(
      modifier = GlanceModifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Box(
        modifier = GlanceModifier
          .cornerRadius(16.dp)
          .background(ColorProvider(if (infinityOn) primaryColor.copy(alpha = 0.22f) else surfaceColor))
          .clickable(actionRunCallback<WidgetToggleInfinityAction>())
          .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Image(
            provider = ImageProvider(R.drawable.ic_widget_infinity),
            contentDescription = "Infinity",
            colorFilter = ColorFilter.tint(ColorProvider(if (infinityOn) primaryColor else mutedColor)),
            modifier = GlanceModifier.size(16.dp),
          )
          Spacer(modifier = GlanceModifier.width(4.dp))
          Text(
            text = if (isBlending) "Blending" else if (infinityOn) "Infinity" else "Standard",
            style = TextStyle(
              color = ColorProvider(if (infinityOn) primaryColor else mutedColor),
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium,
            ),
          )
        }
      }

      Spacer(modifier = GlanceModifier.defaultWeight())
      IconControl(R.drawable.ic_widget_prev, "Previous", textColor, actionRunCallback<WidgetPrevAction>())
      Spacer(modifier = GlanceModifier.width(12.dp))
      PlayPauseOrb(isPlaying = isPlaying, primaryColor = primaryColor, surfaceColor = surfaceColor, sizeDp = 46.dp)
      Spacer(modifier = GlanceModifier.width(12.dp))
      IconControl(R.drawable.ic_widget_next, "Next", textColor, actionRunCallback<WidgetNextAction>())
    }

    Spacer(modifier = GlanceModifier.height(6.dp))
    Text(
      text = "SEAMLESS AUDIO • ${(progress * 100).toInt()}%",
      style = TextStyle(color = ColorProvider(mutedColor.copy(alpha = 0.7f)), fontSize = 10.sp),
    )
  }
}

@Composable
private fun ArtworkThumb(
  artBitmap: android.graphics.Bitmap?,
  sizeDp: Dp,
  cornerDp: Dp,
) {
  Box(
    modifier = GlanceModifier
      .size(sizeDp)
      .cornerRadius(cornerDp),
    contentAlignment = Alignment.Center,
  ) {
    if (artBitmap != null) {
      Image(
        provider = ImageProvider(artBitmap),
        contentDescription = "Album artwork",
        contentScale = ContentScale.Crop,
        modifier = GlanceModifier.fillMaxSize().cornerRadius(cornerDp),
      )
    } else {
      Image(
        provider = ImageProvider(R.drawable.seamless_brand_mark),
        contentDescription = "Seamless artwork",
        contentScale = ContentScale.Crop,
        modifier = GlanceModifier.fillMaxSize().cornerRadius(cornerDp),
      )
    }
  }
}

@Composable
private fun PlayPauseOrb(
  isPlaying: Boolean,
  primaryColor: Color,
  surfaceColor: Color,
  sizeDp: Dp,
) {
  Box(
    modifier = GlanceModifier
      .size(sizeDp)
      .cornerRadius(sizeDp / 2)
      .background(ColorProvider(primaryColor))
      .clickable(actionRunCallback<WidgetPlayPauseAction>()),
    contentAlignment = Alignment.Center,
  ) {
    Image(
      provider = ImageProvider(if (isPlaying) R.drawable.ic_widget_pause else R.drawable.ic_widget_play),
      contentDescription = if (isPlaying) "Pause" else "Play",
      colorFilter = ColorFilter.tint(ColorProvider(Color(0xFF101316))),
      modifier = GlanceModifier.size(sizeDp * 0.5f),
    )
  }
}

@Composable
private fun IconControl(
  iconRes: Int,
  desc: String,
  tint: Color,
  action: androidx.glance.action.Action,
) {
  Box(
    modifier = GlanceModifier
      .size(34.dp)
      .cornerRadius(17.dp)
      .clickable(action),
    contentAlignment = Alignment.Center,
  ) {
    Image(
      provider = ImageProvider(iconRes),
      contentDescription = desc,
      colorFilter = ColorFilter.tint(ColorProvider(tint)),
      modifier = GlanceModifier.size(20.dp),
    )
  }
}

class WidgetPlayPauseAction : ActionCallback {
  override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
    dispatchWidgetCommand(context, SeamlessPlaybackService.ACTION_TOGGLE_PLAY_PAUSE)
  }
}

class WidgetNextAction : ActionCallback {
  override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
    dispatchWidgetCommand(context, SeamlessPlaybackService.ACTION_NEXT)
  }
}

class WidgetPrevAction : ActionCallback {
  override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
    dispatchWidgetCommand(context, SeamlessPlaybackService.ACTION_PREVIOUS)
  }
}

class WidgetToggleInfinityAction : ActionCallback {
  override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
    dispatchWidgetCommand(context, SeamlessPlaybackService.ACTION_TOGGLE_INFINITY)
  }
}

private fun dispatchWidgetCommand(context: Context, action: String) {
  val intent = Intent(context, SeamlessPlaybackService::class.java)
    .setAction(action)
    .putExtra(SeamlessPlaybackService.EXTRA_STARTED_FOREGROUND, true)
  runCatching {
    androidx.core.content.ContextCompat.startForegroundService(context, intent)
  }.onFailure {
    runCatching { context.startService(intent) }
  }
}
