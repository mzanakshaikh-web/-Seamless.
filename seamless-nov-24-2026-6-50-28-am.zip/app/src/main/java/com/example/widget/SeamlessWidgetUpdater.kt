package com.example.widget

import android.content.Context
import androidx.compose.ui.graphics.toArgb
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.state.updateAppWidgetState
import com.example.model.InfinityTransitionState
import com.example.model.Track
import com.example.model.UserPreferences
import com.example.ui.theme.paletteForPreset

object SeamlessWidgetUpdater {

  private var revisionCounter = 0

  suspend fun pushUpdate(
    context: Context,
    track: Track?,
    isPlaying: Boolean,
    progress: Float,
    wavePhase: Float,
    prefs: UserPreferences,
    infinityState: InfinityTransitionState,
  ) {
    val manager = GlanceAppWidgetManager(context)
    val glanceIds = runCatching { manager.getGlanceIds(SeamlessWidget::class.java) }.getOrNull().orEmpty()
    if (glanceIds.isEmpty()) return

    val palette = paletteForPreset(
      preset = prefs.themePreset,
      customPrimaryArgb = prefs.customPrimaryArgb,
      customAccentArgb = prefs.customAccentArgb,
    )
    val widget = SeamlessWidget()
    revisionCounter++

    for (glanceId in glanceIds) {
      updateAppWidgetState(context, glanceId) { state ->
        state[SeamlessWidget.KEY_REVISION] = revisionCounter
        state[SeamlessWidget.KEY_TITLE] = track?.title ?: "Seamless"
        state[SeamlessWidget.KEY_ARTIST] = track?.artist ?: "Tap to open library"
        state[SeamlessWidget.KEY_ALBUM] = track?.album ?: ""
        if (track?.albumArtUri != null) {
          state[SeamlessWidget.KEY_ART_URI] = track.albumArtUri.toString()
        } else {
          state.remove(SeamlessWidget.KEY_ART_URI)
        }
        state[SeamlessWidget.KEY_IS_PLAYING] = isPlaying
        state[SeamlessWidget.KEY_INFINITY_ON] = prefs.infinityEnabled
        state[SeamlessWidget.KEY_IS_BLENDING] = infinityState.isBlending
        state[SeamlessWidget.KEY_PROGRESS] = progress.coerceIn(0f, 1f)
        state[SeamlessWidget.KEY_WAVE_PHASE] = wavePhase
        state[SeamlessWidget.KEY_BG_ARGB] = palette.surface.toArgb()
        state[SeamlessWidget.KEY_SURFACE_ARGB] = palette.surfaceElevated.toArgb()
        state[SeamlessWidget.KEY_PRIMARY_ARGB] = palette.primary.toArgb()
        state[SeamlessWidget.KEY_SECONDARY_ARGB] = palette.secondary.toArgb()
        state[SeamlessWidget.KEY_TERTIARY_ARGB] = palette.tertiary.toArgb()
        state[SeamlessWidget.KEY_TEXT_ARGB] = palette.onSurface.toArgb()
        state[SeamlessWidget.KEY_MUTED_ARGB] = palette.onSurfaceMuted.toArgb()
        state[SeamlessWidget.KEY_CORNER_DP] = prefs.widgetShapeStyle.cornerDp
        state[SeamlessWidget.KEY_WAVE_INTENSITY] = prefs.widgetWaveIntensity
        state[SeamlessWidget.KEY_MATTE_OPACITY] = prefs.widgetMatteOpacity
      }
      widget.update(context, glanceId)
    }
  }
}
