package com.example.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.net.Uri
import android.graphics.BitmapFactory
import com.example.model.AudioFrame
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

object WidgetWaveRenderer {

  fun calculateWidgetMemoryCapBytes(context: Context): Int {
    val metrics = context.resources.displayMetrics
    return 6 * metrics.widthPixels * metrics.heightPixels
  }

  /**
   * Renders a subtle, fluid, audio-reactive wave bitmap for the Glance home widget.
   * Uses RGB_565 on opaque backgrounds or compact ARGB_8888 within strict RemoteViews memory bounds.
   */
  fun renderWaveBitmap(
    widthPx: Int = 360,
    heightPx: Int = 110,
    frame: AudioFrame,
    isPlaying: Boolean,
    primaryArgb: Int,
    secondaryArgb: Int,
    tertiaryArgb: Int,
    waveIntensity: Float,
    phaseOffset: Float,
  ): Bitmap {
    val w = widthPx.coerceIn(120, 420)
    val h = heightPx.coerceIn(48, 140)
    val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    val centerY = h * 0.56f
    val energy = if (isPlaying) {
      (0.22f + frame.overallRms * 0.95f + frame.beatPulse * 0.35f) * waveIntensity
    } else {
      0.14f * waveIntensity
    }
    val ampBase = h * 0.30f * energy.coerceIn(0.08f, 1.35f)

    // Layer 1: Soft translucent ambient fill wave (Bass-driven)
    drawWaveRibbon(
      canvas = canvas,
      w = w,
      h = h,
      centerY = centerY + h * 0.04f,
      amplitude = ampBase * (0.75f + frame.bassEnergy * 0.65f),
      frequency = 1.6f,
      phase = phaseOffset * 0.85f,
      spectrum = frame.spectrum,
      bandOffset = 0,
      strokeWidth = 2.5f,
      colorStart = withAlpha(primaryArgb, 0x44),
      colorEnd = withAlpha(tertiaryArgb, 0x33),
      fillUnder = true,
    )

    // Layer 2: Mid-harmonic subtle flowing curve (Signature Seamless curve)
    drawWaveRibbon(
      canvas = canvas,
      w = w,
      h = h,
      centerY = centerY,
      amplitude = ampBase * (0.65f + frame.midEnergy * 0.75f),
      frequency = 2.4f,
      phase = -phaseOffset * 1.15f + 1.1f,
      spectrum = frame.spectrum,
      bandOffset = 12,
      strokeWidth = 3.2f,
      colorStart = withAlpha(primaryArgb, 0xCC),
      colorEnd = withAlpha(secondaryArgb, 0xCC),
      fillUnder = false,
    )

    // Layer 3: Crisp luminous treble crest line
    drawWaveRibbon(
      canvas = canvas,
      w = w,
      h = h,
      centerY = centerY - h * 0.03f,
      amplitude = ampBase * (0.45f + frame.trebleEnergy * 0.85f),
      frequency = 3.3f,
      phase = phaseOffset * 1.5f + 2.3f,
      spectrum = frame.spectrum,
      bandOffset = 26,
      strokeWidth = 2.4f,
      colorStart = withAlpha(secondaryArgb, 0xEE),
      colorEnd = withAlpha(tertiaryArgb, 0xEE),
      fillUnder = false,
    )

    return bitmap
  }

  private fun drawWaveRibbon(
    canvas: Canvas,
    w: Int,
    h: Int,
    centerY: Float,
    amplitude: Float,
    frequency: Float,
    phase: Float,
    spectrum: FloatArray,
    bandOffset: Int,
    strokeWidth: Float,
    colorStart: Int,
    colorEnd: Int,
    fillUnder: Boolean,
  ) {
    val path = Path()
    val steps = 56
    for (i in 0..steps) {
      val t = i.toFloat() / steps
      val x = t * w
      // Taper cleanly at edges so the wave breathes inside the widget boundaries
      val envelope = sin(PI * t).toFloat().let { it * it * 0.85f + 0.15f }
      val specIdx = ((t * 18f).toInt() + bandOffset).coerceIn(0, spectrum.lastIndex)
      val specBoost = 0.65f + spectrum[specIdx] * 0.9f
      val y = centerY + sin(t * 2.0 * PI * frequency + phase).toFloat() * amplitude * envelope * specBoost
      if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }

    val shader = LinearGradient(
      0f,
      0f,
      w.toFloat(),
      0f,
      colorStart,
      colorEnd,
      Shader.TileMode.CLAMP,
    )

    if (fillUnder) {
      val fillPath = Path(path).apply {
        lineTo(w.toFloat(), h.toFloat())
        lineTo(0f, h.toFloat())
        close()
      }
      val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        this.shader = shader
      }
      canvas.drawPath(fillPath, fillPaint)
    }

    val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.STROKE
      this.strokeWidth = strokeWidth
      strokeCap = Paint.Cap.ROUND
      strokeJoin = Paint.Join.ROUND
      this.shader = shader
    }
    canvas.drawPath(path, strokePaint)
  }

  fun decodeDownsampledArtwork(context: Context, uriString: String?, targetPx: Int = 96): Bitmap? {
    if (uriString.isNullOrBlank()) return null
    return runCatching {
      val uri = Uri.parse(uriString)
      val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
      context.contentResolver.openInputStream(uri)?.use { stream ->
        BitmapFactory.decodeStream(stream, null, boundsOpts)
      }
      if (boundsOpts.outWidth <= 0 || boundsOpts.outHeight <= 0) return null

      var inSample = 1
      val maxDim = max(boundsOpts.outWidth, boundsOpts.outHeight)
      while (maxDim / inSample > targetPx * 2) {
        inSample *= 2
      }
      val decodeOpts = BitmapFactory.Options().apply {
        inSampleSize = inSample
        inPreferredConfig = Bitmap.Config.RGB_565
      }
      context.contentResolver.openInputStream(uri)?.use { stream ->
        BitmapFactory.decodeStream(stream, null, decodeOpts)
      }?.let { raw ->
        val size = min(raw.width, raw.height).coerceAtMost(targetPx)
        Bitmap.createScaledBitmap(raw, size, size, true).also {
          if (it !== raw) raw.recycle()
        }
      }
    }.getOrNull()
  }

  private fun withAlpha(argb: Int, alpha: Int): Int =
    (argb and 0x00FFFFFF) or ((alpha and 0xFF) shl 24)
}
