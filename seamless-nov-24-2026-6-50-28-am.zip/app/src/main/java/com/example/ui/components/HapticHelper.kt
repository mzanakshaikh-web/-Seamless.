package com.example.ui.components

import android.view.HapticFeedbackConstants
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalView

class SeamlessHaptics(
  private val enabled: Boolean,
  private val performTick: () -> Unit,
  private val performTap: () -> Unit,
  private val performStrong: () -> Unit,
) {
  fun tick() {
    if (enabled) performTick()
  }

  fun tap() {
    if (enabled) performTap()
  }

  fun strong() {
    if (enabled) performStrong()
  }
}

@Composable
fun rememberSeamlessHaptics(enabled: Boolean): SeamlessHaptics {
  val view = LocalView.current
  return remember(enabled, view) {
    SeamlessHaptics(
      enabled = enabled,
      performTick = { view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) },
      performTap = { view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK) },
      performStrong = { view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS) },
    )
  }
}

fun formatDuration(ms: Long): String {
  if (ms <= 0L) return "0:00"
  val totalSec = ms / 1000L
  val minutes = totalSec / 60L
  val seconds = totalSec % 60L
  return "%d:%02d".format(minutes, seconds)
}
