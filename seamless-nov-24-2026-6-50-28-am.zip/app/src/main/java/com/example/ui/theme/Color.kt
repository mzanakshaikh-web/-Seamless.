package com.example.ui.theme

import androidx.compose.ui.graphics.Color
import com.example.model.AppThemePreset

data class SeamlessPalette(
  val background: Color,
  val surface: Color,
  val surfaceElevated: Color,
  val surfaceHighest: Color,
  val primary: Color,
  val secondary: Color,
  val tertiary: Color,
  val onBackground: Color,
  val onSurface: Color,
  val onSurfaceMuted: Color,
  val outlineSubtle: Color,
  val isLight: Boolean,
)

val PrimaryColorSwatches = listOf(
  0xFF3EE6B5.toInt(), // Seamless Mint (Icon)
  0xFF4DD9FF.toInt(), // Glacial Cyan
  0xFF64B5F6.toInt(), // Studio Sky
  0xFFFF8C69.toInt(), // Warm Coral
  0xFFF5C451.toInt(), // Amber Gold
  0xFF7CE8A5.toInt(), // Soft Sage
  0xFFE879F9.toInt(), // Orchid Neon
  0xFFE2E8F0.toInt(), // Pure Titanium
)

val AccentColorSwatches = listOf(
  0xFF9A5BFF.toInt(), // Seamless Violet (Icon)
  0xFF4D8EFF.toInt(), // Electric Azure (Icon)
  0xFF3EE6B5.toInt(), // Mint Glow
  0xFFFF6B9D.toInt(), // Rose Pulse
  0xFFFFB74D.toInt(), // Solar Peach
  0xFF38BDF8.toInt(), // Ice Blue
  0xFFA3E635.toInt(), // Lime Spark
  0xFFCBD5E1.toInt(), // Matte Silver
)

fun paletteForPreset(
  preset: AppThemePreset,
  customPrimaryArgb: Int? = null,
  customAccentArgb: Int? = null,
): SeamlessPalette {
  val base = when (preset) {
    AppThemePreset.MATTE_GREY -> SeamlessPalette(
      background = Color(0xFF191B1E),
      surface = Color(0xFF212428),
      surfaceElevated = Color(0xFF2B2F34),
      surfaceHighest = Color(0xFF353A40),
      primary = Color(0xFF3EE6B5),
      secondary = Color(0xFF4D8EFF),
      tertiary = Color(0xFF9A5BFF),
      onBackground = Color(0xFFF0F2F5),
      onSurface = Color(0xFFE7EAEE),
      onSurfaceMuted = Color(0xFF969DA7),
      outlineSubtle = Color(0xFF3E444C),
      isLight = false,
    )
    AppThemePreset.OBSIDIAN_STUDIO -> SeamlessPalette(
      background = Color(0xFF0E1013),
      surface = Color(0xFF16191E),
      surfaceElevated = Color(0xFF1F232A),
      surfaceHighest = Color(0xFF292E37),
      primary = Color(0xFF40F2C9),
      secondary = Color(0xFF3B82F6),
      tertiary = Color(0xFFB366FF),
      onBackground = Color(0xFFF4F6FA),
      onSurface = Color(0xFFEBEEF5),
      onSurfaceMuted = Color(0xFF8A93A1),
      outlineSubtle = Color(0xFF2E343E),
      isLight = false,
    )
    AppThemePreset.WARM_GRAPHITE -> SeamlessPalette(
      background = Color(0xFF1D1B1A),
      surface = Color(0xFF262321),
      surfaceElevated = Color(0xFF312D2B),
      surfaceHighest = Color(0xFF3C3734),
      primary = Color(0xFFFF8C69),
      secondary = Color(0xFFF5C451),
      tertiary = Color(0xFFE06C9F),
      onBackground = Color(0xFFF4EFEA),
      onSurface = Color(0xFFEBE4DD),
      onSurfaceMuted = Color(0xFFA69B92),
      outlineSubtle = Color(0xFF47413D),
      isLight = false,
    )
    AppThemePreset.MIDNIGHT_INDIGO -> SeamlessPalette(
      background = Color(0xFF131722),
      surface = Color(0xFF1B2130),
      surfaceElevated = Color(0xFF242B3E),
      surfaceHighest = Color(0xFF2E374F),
      primary = Color(0xFF4DD9FF),
      secondary = Color(0xFF7C8CFF),
      tertiary = Color(0xFFB48CFF),
      onBackground = Color(0xFFEEF2FF),
      onSurface = Color(0xFFE2E8F8),
      onSurfaceMuted = Color(0xFF8E9BB8),
      outlineSubtle = Color(0xFF38425E),
      isLight = false,
    )
    AppThemePreset.SAGE_CONCRETE -> SeamlessPalette(
      background = Color(0xFF1A1F1C),
      surface = Color(0xFF222825),
      surfaceElevated = Color(0xFF2C342F),
      surfaceHighest = Color(0xFF36403A),
      primary = Color(0xFF7CE8A5),
      secondary = Color(0xFF45C4B0),
      tertiary = Color(0xFF70B8FF),
      onBackground = Color(0xFFEDF3EF),
      onSurface = Color(0xFFE3ECE6),
      onSurfaceMuted = Color(0xFF92A197),
      outlineSubtle = Color(0xFF404B44),
      isLight = false,
    )
    AppThemePreset.MIST_PAPER -> SeamlessPalette(
      background = Color(0xFFE9ECEF),
      surface = Color(0xFFF4F6F8),
      surfaceElevated = Color(0xFFFFFFFF),
      surfaceHighest = Color(0xFFDDE2E7),
      primary = Color(0xFF0E9F77),
      secondary = Color(0xFF2563EB),
      tertiary = Color(0xFF7C3AED),
      onBackground = Color(0xFF181B1F),
      onSurface = Color(0xFF1F2328),
      onSurfaceMuted = Color(0xFF5F6875),
      outlineSubtle = Color(0xFFCFD6DF),
      isLight = true,
    )
  }

  val resolvedPrimary = customPrimaryArgb?.let { Color(it) } ?: base.primary
  val resolvedAccent = customAccentArgb?.let { Color(it) } ?: base.tertiary
  val resolvedSecondary = if (customPrimaryArgb != null || customAccentArgb != null) {
    // Smooth blend midpoint between primary & accent for rich gradient continuity
    Color(
      red = (resolvedPrimary.red * 0.45f + resolvedAccent.red * 0.55f),
      green = (resolvedPrimary.green * 0.45f + resolvedAccent.green * 0.55f),
      blue = (resolvedPrimary.blue * 0.45f + resolvedAccent.blue * 0.55f),
      alpha = 1f,
    )
  } else {
    base.secondary
  }

  return base.copy(
    primary = resolvedPrimary,
    secondary = resolvedSecondary,
    tertiary = resolvedAccent,
  )
}
