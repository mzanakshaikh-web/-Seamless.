package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.example.model.AppThemePreset

val LocalSeamlessPalette = staticCompositionLocalOf {
  paletteForPreset(AppThemePreset.MATTE_GREY)
}

val SeamlessShapes = Shapes(
  extraSmall = RoundedCornerShape(8.dp),
  small = RoundedCornerShape(12.dp),
  medium = RoundedCornerShape(18.dp),
  large = RoundedCornerShape(24.dp),
  extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun SeamlessTheme(
  themePreset: AppThemePreset = AppThemePreset.MATTE_GREY,
  customPrimaryArgb: Int? = null,
  customAccentArgb: Int? = null,
  content: @Composable () -> Unit,
) {
  val palette = paletteForPreset(
    preset = themePreset,
    customPrimaryArgb = customPrimaryArgb,
    customAccentArgb = customAccentArgb,
  )

  val onPrimaryColor = if (palette.primary.luminance() > 0.45f) Color(0xFF101316) else Color(0xFFF8FAFC)
  val onSecondaryColor = if (palette.secondary.luminance() > 0.45f) Color(0xFF101316) else Color(0xFFF8FAFC)
  val onTertiaryColor = if (palette.tertiary.luminance() > 0.45f) Color(0xFF101316) else Color(0xFFF8FAFC)

  val colorScheme = if (palette.isLight) {
    lightColorScheme(
      primary = palette.primary,
      onPrimary = onPrimaryColor,
      primaryContainer = palette.primary.copy(alpha = 0.14f),
      onPrimaryContainer = palette.onBackground,
      secondary = palette.secondary,
      onSecondary = onSecondaryColor,
      secondaryContainer = palette.secondary.copy(alpha = 0.14f),
      onSecondaryContainer = palette.onBackground,
      tertiary = palette.tertiary,
      onTertiary = onTertiaryColor,
      background = palette.background,
      onBackground = palette.onBackground,
      surface = palette.surface,
      onSurface = palette.onSurface,
      surfaceVariant = palette.surfaceElevated,
      onSurfaceVariant = palette.onSurfaceMuted,
      surfaceContainerLow = palette.surface,
      surfaceContainer = palette.surfaceElevated,
      surfaceContainerHigh = palette.surfaceHighest,
      outline = palette.outlineSubtle,
      outlineVariant = palette.outlineSubtle.copy(alpha = 0.55f),
    )
  } else {
    darkColorScheme(
      primary = palette.primary,
      onPrimary = onPrimaryColor,
      primaryContainer = palette.primary.copy(alpha = 0.16f),
      onPrimaryContainer = palette.primary,
      secondary = palette.secondary,
      onSecondary = onSecondaryColor,
      secondaryContainer = palette.secondary.copy(alpha = 0.16f),
      onSecondaryContainer = palette.onBackground,
      tertiary = palette.tertiary,
      onTertiary = onTertiaryColor,
      background = palette.background,
      onBackground = palette.onBackground,
      surface = palette.surface,
      onSurface = palette.onSurface,
      surfaceVariant = palette.surfaceElevated,
      onSurfaceVariant = palette.onSurfaceMuted,
      surfaceContainerLow = palette.surface,
      surfaceContainer = palette.surfaceElevated,
      surfaceContainerHigh = palette.surfaceHighest,
      outline = palette.outlineSubtle,
      outlineVariant = palette.outlineSubtle.copy(alpha = 0.55f),
    )
  }

  val view = LocalView.current
  if (!view.isInEditMode) {
    SideEffect {
      val window = (view.context as? Activity)?.window
      if (window != null) {
        val controller = WindowCompat.getInsetsController(window, view)
        controller.isAppearanceLightStatusBars = palette.isLight
        controller.isAppearanceLightNavigationBars = palette.isLight
      }
    }
  }

  CompositionLocalProvider(LocalSeamlessPalette provides palette) {
    MaterialTheme(
      colorScheme = colorScheme,
      typography = SeamlessTypography,
      shapes = SeamlessShapes,
      content = content,
    )
  }
}
