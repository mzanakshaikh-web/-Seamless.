package com.example.ui.screens

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddToHomeScreen
import androidx.compose.material.icons.rounded.AllInclusive
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AppThemePreset
import com.example.model.AudioFrame
import com.example.model.ReactionStyle
import com.example.model.Track
import com.example.model.UserPreferences
import com.example.model.WidgetShapeStyle
import com.example.ui.components.ReactionCircleContainer
import com.example.ui.components.SeamlessArtwork
import com.example.ui.components.SeamlessHaptics
import com.example.ui.theme.AccentColorSwatches
import com.example.ui.theme.LocalSeamlessPalette
import com.example.ui.theme.PrimaryColorSwatches
import com.example.ui.theme.paletteForPreset
import com.example.widget.SeamlessWidgetReceiver
import kotlin.math.PI
import kotlin.math.sin

@Composable
fun SettingsScreen(
  prefs: UserPreferences,
  currentTrack: Track?,
  audioFrame: AudioFrame,
  isPlaying: Boolean,
  haptics: SeamlessHaptics,
  onSelectReactionStyle: (ReactionStyle) -> Unit,
  onSelectThemePreset: (AppThemePreset) -> Unit,
  onSelectCustomPrimary: (Int?) -> Unit,
  onSelectCustomAccent: (Int?) -> Unit,
  onToggleHaptics: (Boolean) -> Unit,
  onOpenInfinitySheet: () -> Unit,
  onSetWidgetShape: (WidgetShapeStyle) -> Unit,
  onSetWidgetWaveIntensity: (Float) -> Unit,
  onSetWidgetOpacity: (Float) -> Unit,
  onRescanLibrary: () -> Unit,
  onImportAudio: () -> Unit,
  bottomContentPadding: Dp,
) {
  val palette = LocalSeamlessPalette.current
  val context = LocalContext.current

  var previewWidthDp by remember { mutableFloatStateOf(296f) }
  var previewHeightDp by remember { mutableFloatStateOf(132f) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(palette.background),
    contentPadding = PaddingValues(
      start = 20.dp,
      end = 20.dp,
      top = 14.dp,
      bottom = bottomContentPadding + 28.dp,
    ),
    verticalArrangement = Arrangement.spacedBy(20.dp),
  ) {
    item {
      Column {
        Text(
          text = "Studio & Settings",
          style = MaterialTheme.typography.headlineMedium,
          color = palette.onBackground,
        )
        Text(
          text = "Tailor Seamless acoustics, matte surfaces, reaction circle, and home widget.",
          style = MaterialTheme.typography.bodySmall,
          color = palette.onSurfaceMuted,
        )
      }
    }

    // 1. Reaction Circle Studio (12 Styles)
    item {
      SettingsCard(title = "Reaction Circle (${ReactionStyle.entries.size} Styles)") {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Box(modifier = Modifier.size(98.dp), contentAlignment = Alignment.Center) {
            ReactionCircleContainer(
              style = prefs.reactionStyle,
              audioFrame = audioFrame,
              isPlaying = isPlaying,
              demoMode = true,
              modifier = Modifier.fillMaxSize(),
            ) { artMod ->
              SeamlessArtwork(
                albumArtUri = currentTrack?.albumArtUri,
                contentDescription = "Preview",
                circular = true,
                modifier = artMod,
              )
            }
          }
          Spacer(modifier = Modifier.width(14.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(prefs.reactionStyle.title, style = MaterialTheme.typography.titleMedium, color = palette.onSurface)
            Spacer(modifier = Modifier.height(2.dp))
            Text(prefs.reactionStyle.subtitle, style = MaterialTheme.typography.bodySmall, color = palette.onSurfaceMuted)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(ReactionStyle.entries, key = { it.name }) { style ->
            val selected = style == prefs.reactionStyle
            FilterChip(
              selected = selected,
              onClick = {
                haptics.tick()
                onSelectReactionStyle(style)
              },
              label = { Text(style.title) },
              modifier = Modifier.testTag("settings_style_${style.name.lowercase()}"),
            )
          }
        }
      }
    }

    // 2. Theme & Custom Primary / Accent Color Customizer
    item {
      SettingsCard(
        title = "Themes & Custom Colors",
        icon = Icons.Rounded.Palette,
      ) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          items(AppThemePreset.entries, key = { it.name }) { preset ->
            val p = paletteForPreset(preset)
            val selected = prefs.themePreset == preset
            Surface(
              modifier = Modifier
                .width(126.dp)
                .clip(RoundedCornerShape(16.dp))
                .border(
                  width = if (selected) 1.8.dp else 1.dp,
                  color = if (selected) palette.primary else palette.outlineSubtle.copy(alpha = 0.45f),
                  shape = RoundedCornerShape(16.dp),
                )
                .clickable {
                  haptics.tap()
                  onSelectThemePreset(preset)
                }
                .testTag("theme_preset_${preset.name.lowercase()}"),
              color = p.surface,
              shape = RoundedCornerShape(16.dp),
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(p.primary))
                  Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(p.secondary))
                  Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(p.tertiary))
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                  text = preset.title,
                  style = MaterialTheme.typography.titleSmall,
                  color = p.onSurface,
                  maxLines = 1,
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Primary Tone Picker
        ColorSwatchAndHslSection(
          label = "Primary Tone",
          currentColor = palette.primary,
          swatches = PrimaryColorSwatches,
          isCustomized = prefs.customPrimaryArgb != null,
          haptics = haptics,
          onSelectColor = { onSelectCustomPrimary(it) },
          onReset = { onSelectCustomPrimary(null) },
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Accent Tone Picker
        ColorSwatchAndHslSection(
          label = "Accent Tone",
          currentColor = palette.tertiary,
          swatches = AccentColorSwatches,
          isCustomized = prefs.customAccentArgb != null,
          haptics = haptics,
          onSelectColor = { onSelectCustomAccent(it) },
          onReset = { onSelectCustomAccent(null) },
        )
      }
    }

    // 3. Resizable Audio-Reactive Widget Studio
    item {
      SettingsCard(
        title = "Resizable Home Widget Studio",
        icon = Icons.Rounded.Widgets,
      ) {
        Text(
          text = "Drag dimensions to preview how the Seamless widget adapts to any home screen size with subtle audio-reactive waves.",
          style = MaterialTheme.typography.bodySmall,
          color = palette.onSurfaceMuted,
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Live Interactive Resizable Widget Preview
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(210.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(palette.background.copy(alpha = 0.7f)),
          contentAlignment = Alignment.Center,
        ) {
          WidgetLiveInteractivePreview(
            widthDp = previewWidthDp.dp,
            heightDp = previewHeightDp.dp,
            cornerDp = prefs.widgetShapeStyle.cornerDp.dp,
            waveIntensity = prefs.widgetWaveIntensity,
            matteOpacity = prefs.widgetMatteOpacity,
            track = currentTrack,
            audioFrame = audioFrame,
            isPlaying = isPlaying,
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text("Preview Width: ${previewWidthDp.toInt()}dp", style = MaterialTheme.typography.labelMedium, color = palette.onSurfaceMuted)
          Text("Height: ${previewHeightDp.toInt()}dp", style = MaterialTheme.typography.labelMedium, color = palette.onSurfaceMuted)
        }
        Slider(
          value = previewWidthDp,
          onValueChange = { previewWidthDp = it },
          valueRange = 120f..320f,
          colors = SliderDefaults.colors(thumbColor = palette.primary, activeTrackColor = palette.primary),
        )
        Slider(
          value = previewHeightDp,
          onValueChange = { previewHeightDp = it },
          valueRange = 64f..192f,
          colors = SliderDefaults.colors(thumbColor = palette.secondary, activeTrackColor = palette.secondary),
        )

        Text("Widget Corner Shape", style = MaterialTheme.typography.titleSmall, color = palette.onSurface)
        Spacer(modifier = Modifier.height(6.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(WidgetShapeStyle.entries, key = { it.name }) { shapeStyle ->
            FilterChip(
              selected = shapeStyle == prefs.widgetShapeStyle,
              onClick = {
                haptics.tick()
                onSetWidgetShape(shapeStyle)
              },
              label = { Text(shapeStyle.title) },
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Wave Reactivity", style = MaterialTheme.typography.titleSmall, color = palette.onSurface)
          Text("${(prefs.widgetWaveIntensity * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = palette.primary)
        }
        Slider(
          value = prefs.widgetWaveIntensity,
          onValueChange = onSetWidgetWaveIntensity,
          valueRange = 0.25f..1.4f,
          colors = SliderDefaults.colors(thumbColor = palette.primary, activeTrackColor = palette.primary),
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Matte Surface Opacity", style = MaterialTheme.typography.titleSmall, color = palette.onSurface)
          Text("${(prefs.widgetMatteOpacity * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = palette.secondary)
        }
        Slider(
          value = prefs.widgetMatteOpacity,
          onValueChange = onSetWidgetOpacity,
          valueRange = 0.55f..1f,
          colors = SliderDefaults.colors(thumbColor = palette.secondary, activeTrackColor = palette.secondary),
        )

        Spacer(modifier = Modifier.height(8.dp))
        Button(
          onClick = {
            haptics.strong()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
              val awm = context.getSystemService(AppWidgetManager::class.java)
              val provider = ComponentName(context, SeamlessWidgetReceiver::class.java)
              if (awm != null && awm.isRequestPinAppWidgetSupported) {
                awm.requestPinAppWidget(provider, null, null)
              } else {
                Toast.makeText(context, "Long-press your home screen to add the Seamless Wave widget.", Toast.LENGTH_LONG).show()
              }
            } else {
              Toast.makeText(context, "Long-press your home screen to add the Seamless Wave widget.", Toast.LENGTH_LONG).show()
            }
          },
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("pin_widget_button"),
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = palette.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
          ),
        ) {
          Icon(Icons.Rounded.AddToHomeScreen, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("Add Seamless Widget to Home Screen")
        }
      }
    }

    // 4. Infinity & Tactile Feedback
    item {
      SettingsCard(title = "Playback & Tactile Controls") {
        // Haptic Feedback Toggle (Requested explicitly)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(Icons.Rounded.Vibration, contentDescription = null, tint = palette.primary)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text("Haptic Feedback", style = MaterialTheme.typography.titleSmall, color = palette.onSurface)
              Text(
                "Subtle tactile response on buttons, scrubbers, and style switches",
                style = MaterialTheme.typography.bodySmall,
                color = palette.onSurfaceMuted,
              )
            }
          }
          Switch(
            checked = prefs.hapticsEnabled,
            onCheckedChange = { enabled ->
              if (enabled) haptics.tap()
              onToggleHaptics(enabled)
            },
            modifier = Modifier.testTag("haptics_toggle"),
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedButton(
          onClick = {
            haptics.tick()
            onOpenInfinitySheet()
          },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
        ) {
          Icon(Icons.Rounded.AllInclusive, contentDescription = null, tint = palette.primary, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            "Configure Infinity (${prefs.infinityProfile.title} • ${prefs.infinityDurationSec}s)",
            color = palette.onSurface,
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OutlinedButton(
            onClick = {
              haptics.tick()
              onRescanLibrary()
            },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(14.dp),
          ) {
            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Rescan", color = palette.onSurface)
          }
          OutlinedButton(
            onClick = {
              haptics.tick()
              onImportAudio()
            },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(14.dp),
          ) {
            Icon(Icons.Rounded.AudioFile, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Import Audio", color = palette.onSurface)
          }
        }
      }
    }

    // 5. Required Bottom Credit Footer
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 8.dp, bottom = 12.dp)
          .testTag("developer_credit_footer"),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        Text(
          text = stringResource(R.string.developer_credit),
          style = MaterialTheme.typography.labelLarge,
          color = palette.onSurfaceMuted,
          textAlign = TextAlign.Center,
        )
      }
    }
  }
}

@Composable
private fun SettingsCard(
  title: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
  content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit,
) {
  val palette = LocalSeamlessPalette.current
  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .border(1.dp, palette.outlineSubtle.copy(alpha = 0.48f), RoundedCornerShape(22.dp)),
    color = palette.surfaceElevated,
    shape = RoundedCornerShape(22.dp),
  ) {
    Column(modifier = Modifier.padding(18.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) {
          Icon(icon, contentDescription = null, tint = palette.primary, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
        }
        Text(title, style = MaterialTheme.typography.titleMedium, color = palette.onSurface)
      }
      Spacer(modifier = Modifier.height(14.dp))
      content()
    }
  }
}

@Composable
private fun ColorSwatchAndHslSection(
  label: String,
  currentColor: Color,
  swatches: List<Int>,
  isCustomized: Boolean,
  haptics: SeamlessHaptics,
  onSelectColor: (Int) -> Unit,
  onReset: () -> Unit,
) {
  val palette = LocalSeamlessPalette.current
  val hsv = remember(currentColor) {
    FloatArray(3).also { android.graphics.Color.colorToHSV(currentColor.toArgb(), it) }
  }

  Column {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(14.dp)
            .clip(CircleShape)
            .background(currentColor)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(label, style = MaterialTheme.typography.titleSmall, color = palette.onSurface)
      }
      if (isCustomized) {
        Row(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable {
              haptics.tick()
              onReset()
            }
            .padding(horizontal = 6.dp, vertical = 2.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(Icons.Rounded.RestartAlt, contentDescription = null, tint = palette.onSurfaceMuted, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Reset", style = MaterialTheme.typography.labelSmall, color = palette.onSurfaceMuted)
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
      items(swatches) { argb ->
        val selected = currentColor.toArgb() == argb
        Box(
          modifier = Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(Color(argb))
            .border(
              width = if (selected) 2.5.dp else 1.dp,
              color = if (selected) palette.onBackground else palette.outlineSubtle,
              shape = CircleShape,
            )
            .clickable {
              haptics.tick()
              onSelectColor(argb)
            },
          contentAlignment = Alignment.Center,
        ) {
          if (selected) {
            Icon(
              Icons.Rounded.Check,
              contentDescription = "Selected",
              tint = Color(0xFF101316),
              modifier = Modifier.size(16.dp),
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(6.dp))
    // Hue Fine-Tune Slider for full custom primary/accent tones
    Row(verticalAlignment = Alignment.CenterVertically) {
      Text("Hue", style = MaterialTheme.typography.labelSmall, color = palette.onSurfaceMuted, modifier = Modifier.width(34.dp))
      Slider(
        value = hsv[0],
        onValueChange = { newHue ->
          val newArgb = android.graphics.Color.HSVToColor(floatArrayOf(newHue, hsv[1].coerceAtLeast(0.48f), hsv[2].coerceAtLeast(0.75f)))
          onSelectColor(newArgb)
        },
        valueRange = 0f..360f,
        colors = SliderDefaults.colors(thumbColor = currentColor, activeTrackColor = currentColor),
        modifier = Modifier.weight(1f),
      )
    }
  }
}

@Composable
private fun WidgetLiveInteractivePreview(
  widthDp: Dp,
  heightDp: Dp,
  cornerDp: Dp,
  waveIntensity: Float,
  matteOpacity: Float,
  track: Track?,
  audioFrame: AudioFrame,
  isPlaying: Boolean,
) {
  val palette = LocalSeamlessPalette.current
  var phase by remember { mutableFloatStateOf(0f) }

  LaunchedEffect(Unit) {
    var last = 0L
    while (true) {
      withFrameNanos { ns ->
        if (last != 0L) {
          val dt = ((ns - last) / 1_000_000_000f).coerceIn(0f, 0.05f)
          phase = (phase + dt * if (isPlaying) 2.8f else 1.2f) % (2f * PI.toFloat())
        }
        last = ns
      }
    }
  }

  Surface(
    modifier = Modifier
      .size(width = widthDp, height = heightDp)
      .clip(RoundedCornerShape(cornerDp))
      .border(1.dp, palette.outlineSubtle.copy(alpha = 0.6f), RoundedCornerShape(cornerDp)),
    color = palette.surface.copy(alpha = matteOpacity),
    shape = RoundedCornerShape(cornerDp),
  ) {
    Box(modifier = Modifier.fillMaxSize()) {
      // Subtle reactive wave canvas across the widget preview
      Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val amp = h * 0.16f * waveIntensity * (if (isPlaying) 0.45f + audioFrame.overallRms * 0.9f else 0.35f)
        val centerY = h * 0.66f
        val waveBrush = Brush.horizontalGradient(listOf(palette.primary, palette.secondary, palette.tertiary))

        for (layer in 0..1) {
          val path = Path()
          val steps = 48
          for (i in 0..steps) {
            val t = i.toFloat() / steps
            val env = sin(PI * t).toFloat()
            val spec = audioFrame.spectrum[(t * 47).toInt().coerceIn(0, 47)]
            val y = centerY + sin(t * 2f * PI.toFloat() * (2f + layer) + phase * (1f + layer * 0.4f)) *
              amp * (0.6f + spec * 0.8f) * (0.25f + env * 0.75f)
            val x = t * w
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
          }
          drawPath(
            path = path,
            brush = waveBrush,
            alpha = if (layer == 0) 0.85f else 0.45f,
            style = Stroke(width = (if (layer == 0) 2.4f else 1.6f).dp.toPx(), cap = StrokeCap.Round),
          )
        }
      }

      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(12.dp),
        verticalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          SeamlessArtwork(
            albumArtUri = track?.albumArtUri,
            contentDescription = "Widget preview art",
            circular = false,
            cornerRadius = (cornerDp - 6.dp).coerceAtLeast(6.dp),
            modifier = Modifier.size(if (heightDp < 95.dp) 34.dp else 44.dp),
          )
          Spacer(modifier = Modifier.width(10.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = track?.title ?: "Matte Horizon",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.SemiBold,
              color = palette.onSurface,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            if (heightDp >= 84.dp) {
              Text(
                text = track?.artist ?: "Seamless Studio",
                style = MaterialTheme.typography.bodySmall,
                color = palette.onSurfaceMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
        }
      }
    }
  }
}
