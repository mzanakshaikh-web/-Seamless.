package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.AllInclusive
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.audio.PlaybackUiState
import com.example.model.AudioFrame
import com.example.model.EqPreset
import com.example.model.InfinityBlendProfile
import com.example.model.InfinityTransitionState
import com.example.model.ReactionStyle
import com.example.model.RepeatModeOption
import com.example.model.Track
import com.example.model.UserPreferences
import com.example.ui.components.ReactionCircleContainer
import com.example.ui.components.SeamlessArtwork
import com.example.ui.components.SeamlessHaptics
import com.example.ui.components.formatDuration
import com.example.ui.theme.LocalSeamlessPalette

@Composable
fun MiniPlayerBar(
  playback: PlaybackUiState,
  audioFrame: AudioFrame,
  infinityState: InfinityTransitionState,
  prefs: UserPreferences,
  haptics: SeamlessHaptics,
  onExpand: () -> Unit,
  onTogglePlayPause: () -> Unit,
  onNext: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val track = playback.currentTrack ?: return
  val palette = LocalSeamlessPalette.current
  val progress = if (playback.durationMs > 0L) {
    (playback.positionMs.toFloat() / playback.durationMs.toFloat()).coerceIn(0f, 1f)
  } else 0f

  Surface(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 14.dp)
      .clip(RoundedCornerShape(22.dp))
      .border(1.dp, palette.outlineSubtle.copy(alpha = 0.65f), RoundedCornerShape(22.dp))
      .clickable {
        haptics.tap()
        onExpand()
      }
      .testTag("mini_player_bar"),
    color = palette.surfaceElevated.copy(alpha = 0.96f),
    tonalElevation = 8.dp,
    shape = RoundedCornerShape(22.dp),
  ) {
    Column {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Box(modifier = Modifier.size(48.dp), contentAlignment = Alignment.Center) {
          ReactionCircleContainer(
            style = prefs.reactionStyle,
            audioFrame = audioFrame,
            isPlaying = playback.isPlaying,
            isBlending = infinityState.isBlending,
            artworkFraction = 0.72f,
            modifier = Modifier.fillMaxSize(),
          ) { artMod ->
            SeamlessArtwork(
              albumArtUri = track.albumArtUri,
              contentDescription = track.title,
              circular = true,
              subtleBorder = false,
              modifier = artMod,
            )
          }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = if (infinityState.isBlending) "∞ ${infinityState.incomingTitle}" else track.title,
            style = MaterialTheme.typography.titleSmall,
            color = palette.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text = if (infinityState.isBlending) "Blending smoothly..." else track.artist,
            style = MaterialTheme.typography.bodySmall,
            color = if (infinityState.isBlending) palette.primary else palette.onSurfaceMuted,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        IconButton(
          onClick = {
            haptics.tap()
            onTogglePlayPause()
          },
          modifier = Modifier.testTag("mini_play_pause_button"),
        ) {
          Icon(
            imageVector = if (playback.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
            contentDescription = if (playback.isPlaying) "Pause" else "Play",
            tint = palette.primary,
          )
        }

        IconButton(
          onClick = {
            haptics.tick()
            onNext()
          },
          modifier = Modifier.testTag("mini_next_button"),
        ) {
          Icon(
            imageVector = Icons.Rounded.SkipNext,
            contentDescription = "Next track",
            tint = palette.onSurface,
          )
        }
      }

      LinearProgressIndicator(
        progress = { progress },
        modifier = Modifier
          .fillMaxWidth()
          .height(2.5.dp),
        color = palette.primary,
        trackColor = palette.surfaceHighest,
      )
    }
  }
}

@Composable
fun NowPlayingScreen(
  playback: PlaybackUiState,
  audioFrame: AudioFrame,
  infinityState: InfinityTransitionState,
  prefs: UserPreferences,
  haptics: SeamlessHaptics,
  onCollapse: () -> Unit,
  onTogglePlayPause: () -> Unit,
  onNext: (Boolean) -> Unit,
  onPrevious: () -> Unit,
  onSeekTo: (Long) -> Unit,
  onToggleShuffle: () -> Unit,
  onCycleRepeat: () -> Unit,
  onToggleFavorite: (Long) -> Unit,
  onSelectReactionStyle: (ReactionStyle) -> Unit,
  onOpenInfinitySheet: () -> Unit,
  onOpenEqualizerSheet: () -> Unit,
  onSetSleepTimer: (Int?) -> Unit,
  onJumpQueue: (Int) -> Unit,
  onRemoveQueue: (Int) -> Unit,
) {
  BackHandler(onBack = onCollapse)

  val palette = LocalSeamlessPalette.current
  val track = playback.currentTrack
  val isFav = track != null && track.id in prefs.favoriteIds

  var showStylePicker by remember { mutableStateOf(false) }
  var showQueueSheet by remember { mutableStateOf(false) }
  var showSleepDialog by remember { mutableStateOf(false) }

  var isScrubbing by remember { mutableStateOf(false) }
  var scrubFraction by remember { mutableFloatStateOf(0f) }

  val liveFraction = if (playback.durationMs > 0L) {
    (playback.positionMs.toFloat() / playback.durationMs.toFloat()).coerceIn(0f, 1f)
  } else 0f
  val displayFraction = if (isScrubbing) scrubFraction else liveFraction
  val displayPositionMs = if (isScrubbing) (scrubFraction * playback.durationMs).toLong() else playback.positionMs

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          colors = listOf(
            palette.surface,
            palette.background,
            palette.surface.copy(alpha = 0.96f),
          )
        )
      )
      .safeDrawingPadding(),
    contentAlignment = Alignment.TopCenter,
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 560.dp)
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 22.dp, vertical = 12.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      // Top Controls
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        IconButton(
          onClick = {
            haptics.tick()
            onCollapse()
          },
          modifier = Modifier.testTag("now_playing_collapse"),
        ) {
          Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Minimize player", tint = palette.onSurface)
        }

        Surface(
          color = palette.surfaceElevated,
          shape = CircleShape,
          modifier = Modifier
            .clip(CircleShape)
            .border(1.dp, palette.outlineSubtle.copy(alpha = 0.5f), CircleShape)
            .clickable {
              haptics.tick()
              showStylePicker = !showStylePicker
            }
            .testTag("now_playing_style_pill"),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
              Icons.Rounded.AutoAwesome,
              contentDescription = null,
              tint = palette.primary,
              modifier = Modifier.size(15.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = prefs.reactionStyle.title,
              style = MaterialTheme.typography.labelLarge,
              color = palette.onSurface,
            )
          }
        }

        IconButton(
          onClick = {
            haptics.tick()
            showQueueSheet = true
          },
          modifier = Modifier.testTag("now_playing_queue_button"),
        ) {
          Icon(Icons.AutoMirrored.Rounded.QueueMusic, contentDescription = "Open queue", tint = palette.onSurface)
        }
      }

      // Reaction Circle + Artwork Hero
      Box(
        modifier = Modifier
          .padding(vertical = 8.dp)
          .size(300.dp)
          .clickable {
            haptics.tick()
            showStylePicker = !showStylePicker
          },
        contentAlignment = Alignment.Center,
      ) {
        ReactionCircleContainer(
          style = prefs.reactionStyle,
          audioFrame = audioFrame,
          isPlaying = playback.isPlaying,
          isBlending = infinityState.isBlending,
          artworkFraction = 0.64f,
          modifier = Modifier.fillMaxSize(),
        ) { artMod ->
          SeamlessArtwork(
            albumArtUri = track?.albumArtUri,
            contentDescription = track?.title ?: "No track playing",
            circular = true,
            modifier = artMod,
          )
        }
      }

      // Inline Reaction Style Switcher
      AnimatedVisibility(
        visible = showStylePicker,
        enter = fadeIn(),
        exit = fadeOut(),
      ) {
        LazyRow(
          contentPadding = PaddingValues(vertical = 6.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          items(ReactionStyle.entries, key = { it.name }) { style ->
            val selected = style == prefs.reactionStyle
            FilterChip(
              selected = selected,
              onClick = {
                haptics.tick()
                onSelectReactionStyle(style)
              },
              label = { Text(style.title) },
            )
          }
        }
      }

      // Infinity Live Transition Pill
      AnimatedVisibility(visible = infinityState.isBlending) {
        Surface(
          color = palette.primary.copy(alpha = 0.16f),
          shape = CircleShape,
          modifier = Modifier.padding(bottom = 8.dp),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(Icons.Rounded.AllInclusive, contentDescription = null, tint = palette.primary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Blending into ${infinityState.incomingTitle} (${(infinityState.progress * 100).toInt()}%)",
              style = MaterialTheme.typography.labelMedium,
              color = palette.primary,
            )
          }
        }
      }

      // Track Info + Favorite
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = track?.title ?: "Select a Track",
            style = MaterialTheme.typography.headlineSmall,
            color = palette.onBackground,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = if (track != null) "${track.artist} • ${track.album}" else "Tap Library to start listening",
            style = MaterialTheme.typography.bodyMedium,
            color = palette.onSurfaceMuted,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
        if (track != null) {
          IconButton(
            onClick = {
              haptics.tap()
              onToggleFavorite(track.id)
            },
            modifier = Modifier.testTag("now_playing_favorite_button"),
          ) {
            Icon(
              imageVector = if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
              contentDescription = "Favorite",
              tint = if (isFav) palette.primary else palette.onSurfaceMuted,
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Live Reactive Mini Spectrum Scrubber + Slider
      Column(modifier = Modifier.fillMaxWidth()) {
        Slider(
          value = displayFraction,
          onValueChange = {
            if (!isScrubbing) haptics.tick()
            isScrubbing = true
            scrubFraction = it
          },
          onValueChangeFinished = {
            isScrubbing = false
            haptics.tap()
            onSeekTo((scrubFraction * playback.durationMs).toLong())
          },
          colors = SliderDefaults.colors(
            thumbColor = palette.primary,
            activeTrackColor = palette.primary,
            inactiveTrackColor = palette.surfaceHighest,
          ),
          modifier = Modifier.fillMaxWidth().testTag("now_playing_scrubber"),
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = formatDuration(displayPositionMs),
            style = MaterialTheme.typography.labelMedium,
            color = palette.onSurfaceMuted,
          )
          Text(
            text = if (prefs.playbackSpeed != 1f) "${"%.2f".format(prefs.playbackSpeed)}x • ${formatDuration(playback.durationMs)}"
            else formatDuration(playback.durationMs),
            style = MaterialTheme.typography.labelMedium,
            color = palette.onSurfaceMuted,
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Transport Controls
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        IconButton(
          onClick = {
            haptics.tick()
            onToggleShuffle()
          },
          modifier = Modifier.testTag("now_playing_shuffle"),
        ) {
          Icon(
            Icons.Rounded.Shuffle,
            contentDescription = "Shuffle",
            tint = if (playback.shuffleEnabled) palette.primary else palette.onSurfaceMuted,
          )
        }

        IconButton(
          onClick = {
            haptics.tap()
            onPrevious()
          },
          modifier = Modifier.size(54.dp).testTag("now_playing_previous"),
        ) {
          Icon(
            Icons.Rounded.SkipPrevious,
            contentDescription = "Previous",
            tint = palette.onBackground,
            modifier = Modifier.size(34.dp),
          )
        }

        val playScale by animateFloatAsState(
          targetValue = if (playback.isPlaying) 1.04f else 1f,
          animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
          label = "play_orb_scale",
        )
        Surface(
          modifier = Modifier
            .size((72 * playScale).dp)
            .clip(CircleShape)
            .clickable {
              haptics.strong()
              onTogglePlayPause()
            }
            .testTag("now_playing_play_pause"),
          color = palette.primary,
          shape = CircleShape,
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = if (playback.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
              contentDescription = if (playback.isPlaying) "Pause" else "Play",
              tint = MaterialTheme.colorScheme.onPrimary,
              modifier = Modifier.size(36.dp),
            )
          }
        }

        IconButton(
          onClick = {
            haptics.tap()
            onNext(false)
          },
          modifier = Modifier.size(54.dp).testTag("now_playing_next"),
        ) {
          Icon(
            Icons.Rounded.SkipNext,
            contentDescription = "Next",
            tint = palette.onBackground,
            modifier = Modifier.size(34.dp),
          )
        }

        IconButton(
          onClick = {
            haptics.tick()
            onCycleRepeat()
          },
          modifier = Modifier.testTag("now_playing_repeat"),
        ) {
          Icon(
            imageVector = if (playback.repeatMode == RepeatModeOption.ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
            contentDescription = "Repeat mode",
            tint = if (playback.repeatMode != RepeatModeOption.OFF) palette.primary else palette.onSurfaceMuted,
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Bottom Utility Strip (Infinity Blend, EQ, Sleep Timer, Mashup Next)
      Surface(
        color = palette.surfaceElevated,
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, palette.outlineSubtle.copy(alpha = 0.45f), RoundedCornerShape(20.dp)),
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceEvenly,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          UtilityPillButton(
            icon = Icons.Rounded.AllInclusive,
            label = if (prefs.infinityEnabled) "Infinity" else "Standard",
            active = prefs.infinityEnabled,
            onClick = {
              haptics.tick()
              onOpenInfinitySheet()
            },
            modifier = Modifier.testTag("now_playing_infinity_button"),
          )
          UtilityPillButton(
            icon = Icons.Rounded.Equalizer,
            label = prefs.eqPreset.title,
            active = prefs.eqPreset != EqPreset.FLAT,
            onClick = {
              haptics.tick()
              onOpenEqualizerSheet()
            },
            modifier = Modifier.testTag("now_playing_eq_button"),
          )
          UtilityPillButton(
            icon = Icons.Rounded.Bedtime,
            label = playback.sleepTimerRemainingMs?.let { formatDuration(it) } ?: "Timer",
            active = playback.sleepTimerRemainingMs != null,
            onClick = {
              haptics.tick()
              showSleepDialog = true
            },
            modifier = Modifier.testTag("now_playing_sleep_button"),
          )
          UtilityPillButton(
            icon = Icons.Rounded.AutoAwesome,
            label = "Blend Now",
            active = infinityState.isBlending,
            onClick = {
              haptics.strong()
              onNext(true)
            },
            modifier = Modifier.testTag("now_playing_blend_now_button"),
          )
        }
      }
    }
  }

  if (showQueueSheet) {
    QueueBottomSheet(
      queue = playback.queue,
      currentIndex = playback.currentIndex,
      onJump = {
        haptics.tap()
        onJumpQueue(it)
      },
      onRemove = onRemoveQueue,
      onDismiss = { showQueueSheet = false },
    )
  }

  if (showSleepDialog) {
    AlertDialog(
      onDismissRequest = { showSleepDialog = false },
      title = { Text("Sleep Timer") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          listOf(10, 20, 30, 45, 60).forEach { mins ->
            Surface(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .clickable {
                  onSetSleepTimer(mins)
                  showSleepDialog = false
                },
              color = palette.surfaceElevated,
            ) {
              Text("$mins minutes", modifier = Modifier.padding(14.dp))
            }
          }
          if (playback.sleepTimerRemainingMs != null) {
            TextButton(
              onClick = {
                onSetSleepTimer(null)
                showSleepDialog = false
              }
            ) {
              Text("Turn Off Timer", color = palette.primary)
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showSleepDialog = false }) { Text("Done") }
      },
    )
  }
}

@Composable
private fun UtilityPillButton(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  active: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val palette = LocalSeamlessPalette.current
  Column(
    modifier = modifier
      .clip(RoundedCornerShape(14.dp))
      .clickable(onClick = onClick)
      .padding(horizontal = 10.dp, vertical = 8.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Icon(
      imageVector = icon,
      contentDescription = label,
      tint = if (active) palette.primary else palette.onSurfaceMuted,
      modifier = Modifier.size(20.dp),
    )
    Spacer(modifier = Modifier.height(3.dp))
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = if (active) palette.primary else palette.onSurfaceMuted,
      maxLines = 1,
    )
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InfinityBottomSheet(
  prefs: UserPreferences,
  infinityState: InfinityTransitionState,
  haptics: SeamlessHaptics,
  onToggleInfinity: (Boolean) -> Unit,
  onSetDuration: (Int) -> Unit,
  onSetProfile: (InfinityBlendProfile) -> Unit,
  onBlendNow: () -> Unit,
  onDismiss: () -> Unit,
) {
  val palette = LocalSeamlessPalette.current
  ModalBottomSheet(
    onDismissRequest = onDismiss,
    containerColor = palette.surface,
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 22.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Rounded.AllInclusive, contentDescription = null, tint = palette.primary)
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text("Infinity Seamless Engine", style = MaterialTheme.typography.titleLarge, color = palette.onSurface)
            Text("Fluid track blending & harmonic mashup", style = MaterialTheme.typography.bodySmall, color = palette.onSurfaceMuted)
          }
        }
        Switch(
          checked = prefs.infinityEnabled,
          onCheckedChange = {
            haptics.tap()
            onToggleInfinity(it)
          },
          modifier = Modifier.testTag("infinity_sheet_switch"),
        )
      }

      // Blend Profile Selector
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        InfinityBlendProfile.entries.forEach { profile ->
          val selected = profile == prefs.infinityProfile
          Surface(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(16.dp))
              .border(
                width = if (selected) 1.5.dp else 1.dp,
                color = if (selected) palette.primary else palette.outlineSubtle.copy(alpha = 0.45f),
                shape = RoundedCornerShape(16.dp),
              )
              .clickable {
                haptics.tick()
                onSetProfile(profile)
              },
            color = if (selected) palette.surfaceHighest else palette.surfaceElevated,
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text(
                text = profile.title,
                style = MaterialTheme.typography.titleSmall,
                color = if (selected) palette.primary else palette.onSurface,
              )
              Text(
                text = profile.description,
                style = MaterialTheme.typography.bodySmall,
                color = palette.onSurfaceMuted,
              )
            }
          }
        }
      }

      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text("Transition Overlap", style = MaterialTheme.typography.titleSmall, color = palette.onSurface)
          Text("${prefs.infinityDurationSec}s", style = MaterialTheme.typography.labelLarge, color = palette.primary)
        }
        Slider(
          value = prefs.infinityDurationSec.toFloat(),
          onValueChange = { onSetDuration(it.toInt()) },
          valueRange = 3f..16f,
          steps = 12,
          colors = SliderDefaults.colors(thumbColor = palette.primary, activeTrackColor = palette.primary),
        )
      }

      Button(
        onClick = {
          haptics.strong()
          onBlendNow()
          onDismiss()
        },
        modifier = Modifier.fillMaxWidth().height(50.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = palette.primary,
          contentColor = MaterialTheme.colorScheme.onPrimary,
        ),
      ) {
        Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(if (infinityState.isBlending) "Blending In Progress..." else "Mashup Into Next Track Now")
      }

      Spacer(modifier = Modifier.height(14.dp))
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerBottomSheet(
  prefs: UserPreferences,
  haptics: SeamlessHaptics,
  onSelectPreset: (EqPreset) -> Unit,
  onSetBands: (List<Float>) -> Unit,
  onSetBassBoost: (Float) -> Unit,
  onSetSpeed: (Float) -> Unit,
  onDismiss: () -> Unit,
) {
  val palette = LocalSeamlessPalette.current
  val labels = listOf("60Hz", "230Hz", "910Hz", "3.6k", "14k")

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    containerColor = palette.surface,
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 22.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Text("Studio Equalizer & Acoustics", style = MaterialTheme.typography.titleLarge, color = palette.onSurface)

      LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(EqPreset.entries.filter { it != EqPreset.CUSTOM }) { preset ->
          FilterChip(
            selected = preset == prefs.eqPreset,
            onClick = {
              haptics.tick()
              onSelectPreset(preset)
            },
            label = { Text(preset.title) },
          )
        }
      }

      // 5-Band Sliders
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        prefs.eqBandsDb.forEachIndexed { idx, db ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = labels.getOrElse(idx) { "" },
              style = MaterialTheme.typography.labelMedium,
              color = palette.onSurfaceMuted,
              modifier = Modifier.width(48.dp),
            )
            Slider(
              value = db,
              onValueChange = { newVal ->
                val updated = prefs.eqBandsDb.toMutableList()
                updated[idx] = newVal
                onSetBands(updated)
              },
              valueRange = -12f..12f,
              modifier = Modifier.weight(1f),
              colors = SliderDefaults.colors(thumbColor = palette.primary, activeTrackColor = palette.primary),
            )
            Text(
              text = "%+.1fdB".format(db),
              style = MaterialTheme.typography.labelSmall,
              color = palette.primary,
              textAlign = TextAlign.End,
              modifier = Modifier.width(54.dp),
            )
          }
        }
      }

      Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Sub-Bass Resonance", style = MaterialTheme.typography.titleSmall, color = palette.onSurface)
          Text("${(prefs.bassBoostStrength * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = palette.secondary)
        }
        Slider(
          value = prefs.bassBoostStrength,
          onValueChange = onSetBassBoost,
          valueRange = 0f..1f,
          colors = SliderDefaults.colors(thumbColor = palette.secondary, activeTrackColor = palette.secondary),
        )
      }

      Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Playback Speed", style = MaterialTheme.typography.titleSmall, color = palette.onSurface)
          Text("${"%.2f".format(prefs.playbackSpeed)}x", style = MaterialTheme.typography.labelMedium, color = palette.tertiary)
        }
        Slider(
          value = prefs.playbackSpeed,
          onValueChange = onSetSpeed,
          valueRange = 0.75f..1.5f,
          colors = SliderDefaults.colors(thumbColor = palette.tertiary, activeTrackColor = palette.tertiary),
        )
      }

      Spacer(modifier = Modifier.height(14.dp))
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QueueBottomSheet(
  queue: List<Track>,
  currentIndex: Int,
  onJump: (Int) -> Unit,
  onRemove: (Int) -> Unit,
  onDismiss: () -> Unit,
) {
  val palette = LocalSeamlessPalette.current
  ModalBottomSheet(
    onDismissRequest = onDismiss,
    containerColor = palette.surface,
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .height(420.dp)
        .padding(horizontal = 20.dp),
    ) {
      Text("Up Next (${queue.size})", style = MaterialTheme.typography.titleLarge, color = palette.onSurface)
      Spacer(modifier = Modifier.height(10.dp))
      LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed(queue, key = { idx, t -> "${t.id}_$idx" }) { idx, track ->
          val isCurrent = idx == currentIndex
          Surface(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(14.dp))
              .clickable { onJump(idx) },
            color = if (isCurrent) palette.primary.copy(alpha = 0.14f) else palette.surfaceElevated,
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              SeamlessArtwork(
                albumArtUri = track.albumArtUri,
                contentDescription = track.title,
                circular = true,
                modifier = Modifier.size(40.dp),
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = track.title,
                  style = MaterialTheme.typography.titleSmall,
                  color = if (isCurrent) palette.primary else palette.onSurface,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Text(
                  text = track.artist,
                  style = MaterialTheme.typography.bodySmall,
                  color = palette.onSurfaceMuted,
                  maxLines = 1,
                )
              }
              if (!isCurrent && queue.size > 1) {
                IconButton(onClick = { onRemove(idx) }) {
                  Icon(Icons.Rounded.Close, contentDescription = "Remove from queue", tint = palette.onSurfaceMuted)
                }
              }
            }
          }
        }
      }
    }
  }
}
