package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.AudioFrame
import com.example.model.ReactionStyle
import com.example.ui.theme.LocalSeamlessPalette
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Wraps circular album artwork (or Seamless fallback emblem) with 12 audio-reactive circle styles.
 * Reacts accurately to live FFT spectrum, PCM waveform, bass/mid/treble energy, and beat transients.
 */
@Composable
fun ReactionCircleContainer(
  style: ReactionStyle,
  audioFrame: AudioFrame,
  isPlaying: Boolean,
  isBlending: Boolean = false,
  artworkFraction: Float = 0.68f,
  modifier: Modifier = Modifier,
  demoMode: Boolean = false,
  artwork: @Composable (Modifier) -> Unit,
) {
  val palette = LocalSeamlessPalette.current
  var timeSec by remember { mutableFloatStateOf(0f) }

  LaunchedEffect(isPlaying, demoMode) {
    var lastNs = 0L
    while (isPlaying || demoMode) {
      withFrameNanos { ns ->
        if (lastNs != 0L) {
          val dt = ((ns - lastNs) / 1_000_000_000f).coerceIn(0f, 0.05f)
          timeSec += dt
        }
        lastNs = ns
      }
    }
  }

  // Synthesize a gentle musical reference oscillator ONLY in onboarding/style-studio preview when paused
  val effectiveFrame = remember(audioFrame, isPlaying, demoMode, timeSec) {
    if (isPlaying || !demoMode) {
      audioFrame
    } else {
      synthesizeDemoFrame(timeSec)
    }
  }

  val artScale by animateFloatAsState(
    targetValue = if (isPlaying || demoMode) 1f + effectiveFrame.bassEnergy * 0.032f + effectiveFrame.beatPulse * 0.02f else 1f,
    animationSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = 0.65f),
    label = "artwork_breath",
  )

  Box(
    modifier = modifier,
    contentAlignment = Alignment.Center,
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val minDim = size.minDimension
      val baseRadius = (minDim * artworkFraction) * 0.5f
      val maxRingSpan = (minDim * 0.5f) - baseRadius - 6.dp.toPx()

      drawReactionStyle(
        style = style,
        frame = effectiveFrame,
        center = Offset(size.width * 0.5f, size.height * 0.5f),
        baseRadius = baseRadius * artScale,
        ringSpan = max(12.dp.toPx(), maxRingSpan),
        timeSec = timeSec,
        isActive = isPlaying || demoMode,
        isBlending = isBlending,
        primary = palette.primary,
        secondary = palette.secondary,
        tertiary = palette.tertiary,
        muted = palette.outlineSubtle,
      )
    }

    val paddingFrac = (1f - artworkFraction) * 0.5f
    Box(
      modifier = Modifier
        .fillMaxSize(artworkFraction * artScale)
        .padding((paddingFrac * 2f).dp),
      contentAlignment = Alignment.Center,
    ) {
      artwork(Modifier.fillMaxSize())
    }
  }
}

private fun synthesizeDemoFrame(t: Float): AudioFrame {
  val beatCycle = (t * 1.9f) % 1f
  val beat = ((1f - beatCycle) * (1f - beatCycle)).coerceIn(0f, 1f)
  val spec = FloatArray(48) { i ->
    val norm = i / 48f
    val wave = 0.5f + 0.5f * sin(t * 3.2f - norm * 5.2f)
    val bassBoost = if (i < 10) beat * 0.48f else 0f
    (0.18f + wave * 0.38f + bassBoost).coerceIn(0f, 1f)
  }
  val wave = FloatArray(64) { i ->
    val p = i / 64f * 2f * PI.toFloat()
    (sin(p * 3f + t * 4f) * 0.35f + sin(p * 7f - t * 6f) * 0.2f) * (0.4f + beat * 0.5f)
  }
  return AudioFrame(
    spectrum = spec,
    waveform = wave,
    bassEnergy = (0.35f + beat * 0.5f).coerceIn(0f, 1f),
    midEnergy = (0.35f + 0.25f * sin(t * 2.4f)).coerceIn(0f, 1f),
    trebleEnergy = (0.28f + 0.25f * cos(t * 4.1f)).coerceIn(0f, 1f),
    overallRms = (0.38f + beat * 0.32f).coerceIn(0f, 1f),
    beatPulse = beat * 0.85f,
    phase = t * 1.8f,
  )
}

private fun DrawScope.drawReactionStyle(
  style: ReactionStyle,
  frame: AudioFrame,
  center: Offset,
  baseRadius: Float,
  ringSpan: Float,
  timeSec: Float,
  isActive: Boolean,
  isBlending: Boolean,
  primary: Color,
  secondary: Color,
  tertiary: Color,
  muted: Color,
) {
  val sweepBrush = Brush.sweepGradient(
    colors = listOf(primary, secondary, tertiary, secondary, primary),
    center = center,
  )
  val energyScale = if (isActive) 1f else 0.12f

  // Subtle matte anchor rim so the artwork always sits in a crisp circle
  drawCircle(
    color = muted.copy(alpha = if (isActive) 0.35f else 0.25f),
    radius = baseRadius + 2.dp.toPx(),
    center = center,
    style = Stroke(width = 1.2.dp.toPx()),
  )

  when (style) {
    ReactionStyle.SEAMLESS_PULSE -> {
      // Soft atmospheric aura
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(
            primary.copy(alpha = (0.14f + frame.bassEnergy * 0.24f) * energyScale),
            tertiary.copy(alpha = (0.08f + frame.trebleEnergy * 0.14f) * energyScale),
            Color.Transparent,
          ),
          center = center,
          radius = baseRadius + ringSpan * 1.05f,
        ),
        radius = baseRadius + ringSpan * 1.05f,
        center = center,
      )
      // Twin breathing organic loops
      for (layer in 0..1) {
        val path = Path()
        val pts = 96
        val phaseShift = if (layer == 0) timeSec * 1.5f else -timeSec * 1.1f + 1.4f
        val amp = ringSpan * (0.28f + frame.overallRms * 0.52f) * energyScale
        for (i in 0..pts) {
          val a = (i.toFloat() / pts) * 2f * PI.toFloat()
          val idx = (i * frame.spectrum.size / pts).coerceIn(0, frame.spectrum.lastIndex)
          val mod = sin(a * (3 + layer) + phaseShift) * 0.45f + frame.spectrum[idx] * 0.8f
          val r = baseRadius + 5.dp.toPx() + amp * (0.35f + 0.65f * max(0f, mod))
          val x = center.x + cos(a) * r
          val y = center.y + sin(a) * r
          if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(
          path = path,
          brush = sweepBrush,
          alpha = if (layer == 0) 0.92f else 0.5f,
          style = Stroke(width = (if (layer == 0) 3.2f else 2.0f).dp.toPx(), cap = StrokeCap.Round),
        )
      }
    }

    ReactionStyle.RADIAL_SPECTRUM -> {
      val bars = 64
      for (i in 0 until bars) {
        val angle = (i.toFloat() / bars) * 2f * PI.toFloat() - PI.toFloat() / 2f
        val specIdx = ((i % (bars / 2)) * frame.spectrum.size / (bars / 2)).coerceIn(0, frame.spectrum.lastIndex)
        val mag = frame.spectrum[specIdx] * energyScale
        val barLen = 4.dp.toPx() + mag * ringSpan * 0.92f
        val rStart = baseRadius + 4.dp.toPx()
        val rEnd = rStart + barLen
        val cosA = cos(angle)
        val sinA = sin(angle)
        val t = i.toFloat() / bars
        val color = lerpTriColor(primary, secondary, tertiary, t)
        drawLine(
          color = color.copy(alpha = 0.45f + mag * 0.55f),
          start = Offset(center.x + cosA * rStart, center.y + sinA * rStart),
          end = Offset(center.x + cosA * rEnd, center.y + sinA * rEnd),
          strokeWidth = 2.6.dp.toPx(),
          cap = StrokeCap.Round,
        )
      }
    }

    ReactionStyle.HARMONIC_ORBIT -> {
      val bands = listOf(
        Triple(frame.bassEnergy, 1.0f, primary),
        Triple(frame.midEnergy, -1.4f, secondary),
        Triple(frame.trebleEnergy, 2.1f, tertiary),
      )
      bands.forEachIndexed { idx, (energy, speed, color) ->
        val path = Path()
        val pts = 90
        val orbitBase = baseRadius + 6.dp.toPx() + idx * (ringSpan * 0.24f)
        for (i in 0..pts) {
          val a = (i.toFloat() / pts) * 2f * PI.toFloat()
          val wobble = sin(a * (2 + idx * 2) + timeSec * speed) * (ringSpan * 0.26f * energy * energyScale)
          val r = orbitBase + wobble
          val x = center.x + cos(a) * r
          val y = center.y + sin(a) * r
          if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(
          path = path,
          color = color.copy(alpha = 0.55f + energy * 0.45f),
          style = Stroke(width = 2.4.dp.toPx()),
        )
      }
    }

    ReactionStyle.LIQUID_AURA -> {
      val pts = 84
      val path = Path()
      for (i in 0..pts) {
        val a = (i.toFloat() / pts) * 2f * PI.toFloat()
        val n1 = sin(a * 3f + timeSec * 1.9f) * (0.35f + frame.bassEnergy * 0.65f)
        val n2 = cos(a * 5f - timeSec * 2.7f) * (0.25f + frame.midEnergy * 0.55f)
        val n3 = sin(a * 8f + timeSec * 3.8f) * (0.15f + frame.trebleEnergy * 0.45f)
        val disp = ((n1 + n2 + n3) * 0.5f + 0.5f) * ringSpan * 0.72f * energyScale
        val r = baseRadius + 6.dp.toPx() + disp
        val x = center.x + cos(a) * r
        val y = center.y + sin(a) * r
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
      }
      path.close()
      drawPath(
        path = path,
        brush = Brush.radialGradient(
          colors = listOf(primary.copy(alpha = 0.34f * energyScale), tertiary.copy(alpha = 0.14f * energyScale), Color.Transparent),
          center = center,
          radius = baseRadius + ringSpan,
        ),
      )
      drawPath(
        path = path,
        brush = sweepBrush,
        style = Stroke(width = 2.8.dp.toPx()),
      )
    }

    ReactionStyle.MINIMAL_SONAR -> {
      val rings = 4
      for (rIdx in 0 until rings) {
        val progress = ((timeSec * (0.45f + frame.overallRms * 0.35f) + rIdx / rings.toFloat()) % 1f)
        val radius = baseRadius + 4.dp.toPx() + progress * ringSpan * (0.75f + frame.beatPulse * 0.3f)
        val alpha = (1f - progress) * (0.35f + frame.beatPulse * 0.65f) * energyScale
        val color = lerpTriColor(primary, secondary, tertiary, progress)
        drawCircle(
          color = color.copy(alpha = alpha.coerceIn(0f, 1f)),
          radius = radius,
          center = center,
          style = Stroke(width = (2.8f - progress * 1.6f).dp.toPx()),
        )
      }
    }

    ReactionStyle.EQUALIZER_ARC -> {
      val segments = 16
      for (side in listOf(-1f, 1f)) {
        for (i in 0 until segments) {
          val frac = i.toFloat() / segments
          val specIdx = (frac * frame.spectrum.size).toInt().coerceIn(0, frame.spectrum.lastIndex)
          val active = frame.spectrum[specIdx] * energyScale
          val arcRadius = baseRadius + 7.dp.toPx() + (i % 3) * 5.dp.toPx() + active * (ringSpan * 0.55f)
          val startDeg = if (side > 0) -65f + frac * 130f else 115f + frac * 130f
          val sweepDeg = 6.5f
          val color = lerpTriColor(primary, secondary, tertiary, frac)
          drawArc(
            color = color.copy(alpha = 0.35f + active * 0.65f),
            startAngle = startDeg,
            sweepAngle = sweepDeg,
            useCenter = false,
            topLeft = Offset(center.x - arcRadius, center.y - arcRadius),
            size = Size(arcRadius * 2f, arcRadius * 2f),
            style = Stroke(width = 3.2.dp.toPx(), cap = StrokeCap.Round),
          )
        }
      }
    }

    ReactionStyle.WAVEFORM_HALO -> {
      val path = Path()
      val pts = frame.waveform.size
      for (i in 0..pts) {
        val idx = i % pts
        val a = (i.toFloat() / pts) * 2f * PI.toFloat()
        val sample = frame.waveform[idx] * energyScale
        val r = baseRadius + ringSpan * 0.45f + sample * (ringSpan * 0.48f)
        val x = center.x + cos(a) * r
        val y = center.y + sin(a) * r
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
      }
      path.close()
      drawPath(
        path = path,
        brush = sweepBrush,
        style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round),
      )
    }

    ReactionStyle.CONSTELLATION -> {
      val nodes = 28
      val pts = ArrayList<Offset>(nodes)
      for (i in 0 until nodes) {
        val baseAngle = (i.toFloat() / nodes) * 2f * PI.toFloat() + timeSec * (0.35f + frame.trebleEnergy * 0.6f)
        val spec = frame.spectrum[(i * 2) % frame.spectrum.size] * energyScale
        val r = baseRadius + 8.dp.toPx() + spec * ringSpan * 0.85f
        val pt = Offset(center.x + cos(baseAngle) * r, center.y + sin(baseAngle) * r)
        pts.add(pt)
        val color = lerpTriColor(primary, secondary, tertiary, i.toFloat() / nodes)
        drawCircle(
          color = color.copy(alpha = 0.45f + spec * 0.55f),
          radius = (2.2f + spec * 3.8f).dp.toPx(),
          center = pt,
        )
      }
      for (i in 0 until nodes) {
        val next = pts[(i + 1) % nodes]
        drawLine(
          color = secondary.copy(alpha = 0.25f * energyScale),
          start = pts[i],
          end = next,
          strokeWidth = 1.dp.toPx(),
        )
      }
    }

    ReactionStyle.VINYL_STROBE -> {
      val ticks = 48
      val rot = timeSec * (0.4f + frame.overallRms * 0.8f)
      for (i in 0 until ticks) {
        val a = (i.toFloat() / ticks) * 2f * PI.toFloat() + rot
        val isMajor = i % 4 == 0
        val mag = frame.spectrum[i % frame.spectrum.size] * energyScale
        val r0 = baseRadius + 5.dp.toPx()
        val r1 = r0 + (if (isMajor) 10.dp.toPx() else 5.dp.toPx()) + mag * (ringSpan * 0.55f)
        drawLine(
          color = if (isMajor) primary.copy(alpha = 0.9f) else secondary.copy(alpha = 0.45f + mag * 0.4f),
          start = Offset(center.x + cos(a) * r0, center.y + sin(a) * r0),
          end = Offset(center.x + cos(a) * r1, center.y + sin(a) * r1),
          strokeWidth = (if (isMajor) 2.6f else 1.5f).dp.toPx(),
          cap = StrokeCap.Round,
        )
      }
      val sweepRad = baseRadius + ringSpan * 0.3f
      drawArc(
        brush = sweepBrush,
        startAngle = (rot * 180f / PI.toFloat()) % 360f,
        sweepAngle = 70f + frame.bassEnergy * 110f,
        useCenter = false,
        topLeft = Offset(center.x - sweepRad, center.y - sweepRad),
        size = Size(sweepRad * 2f, sweepRad * 2f),
        style = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round),
      )
    }

    ReactionStyle.HORIZON_ECLIPSE -> {
      val shiftAngle = timeSec * 0.9f + frame.midEnergy * 1.2f
      val offset = Offset(
        center.x + cos(shiftAngle) * (4.dp.toPx() + frame.bassEnergy * 12.dp.toPx() * energyScale),
        center.y + sin(shiftAngle) * (4.dp.toPx() + frame.bassEnergy * 12.dp.toPx() * energyScale),
      )
      val haloR = baseRadius + ringSpan * (0.45f + frame.overallRms * 0.55f * energyScale)
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(
            primary.copy(alpha = 0.65f * energyScale),
            tertiary.copy(alpha = 0.35f * energyScale),
            Color.Transparent,
          ),
          center = offset,
          radius = haloR,
        ),
        radius = haloR,
        center = offset,
      )
      drawCircle(
        brush = sweepBrush,
        radius = baseRadius + 4.dp.toPx() + frame.beatPulse * 6.dp.toPx() * energyScale,
        center = center,
        style = Stroke(width = 2.4.dp.toPx()),
      )
    }

    ReactionStyle.DUAL_HELIX -> {
      val pts = 100
      for (strand in 0..1) {
        val path = Path()
        val sign = if (strand == 0) 1f else -1f
        for (i in 0..pts) {
          val a = (i.toFloat() / pts) * 2f * PI.toFloat()
          val spec = frame.spectrum[(i * frame.spectrum.size / pts).coerceIn(0, frame.spectrum.lastIndex)]
          val wave = sin(a * 6f + timeSec * 2.4f * sign) * (ringSpan * 0.25f + spec * ringSpan * 0.35f) * energyScale
          val r = baseRadius + ringSpan * 0.45f + wave
          val x = center.x + cos(a) * r
          val y = center.y + sin(a) * r
          if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(
          path = path,
          color = if (strand == 0) primary.copy(alpha = 0.9f) else tertiary.copy(alpha = 0.85f),
          style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round),
        )
      }
    }

    ReactionStyle.PRISM_CROWN -> {
      val vertices = 16
      val path = Path()
      val rot = timeSec * 0.45f
      for (i in 0 until vertices) {
        val a = (i.toFloat() / vertices) * 2f * PI.toFloat() + rot
        val mag = frame.spectrum[(i * 3) % frame.spectrum.size] * energyScale
        val r = baseRadius + 6.dp.toPx() + mag * ringSpan * 0.88f
        val x = center.x + cos(a) * r
        val y = center.y + sin(a) * r
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
      }
      path.close()
      drawPath(
        path = path,
        brush = sweepBrush,
        style = Stroke(width = 2.8.dp.toPx()),
      )
      drawCircle(
        color = secondary.copy(alpha = 0.22f * energyScale),
        radius = baseRadius + 6.dp.toPx() + frame.bassEnergy * ringSpan * 0.4f * energyScale,
        center = center,
        style = Stroke(width = 1.4.dp.toPx()),
      )
    }
  }

  // Subtle Infinity blend outer shimmer when actively transitioning between two tracks
  if (isBlending) {
    val blendR = baseRadius + ringSpan * 0.92f
    drawArc(
      brush = sweepBrush,
      startAngle = (timeSec * 140f) % 360f,
      sweepAngle = 220f,
      useCenter = false,
      topLeft = Offset(center.x - blendR, center.y - blendR),
      size = Size(blendR * 2f, blendR * 2f),
      style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round),
    )
  }
}

private fun lerpTriColor(c1: Color, c2: Color, c3: Color, t: Float): Color {
  val clamped = t.coerceIn(0f, 1f)
  return if (clamped < 0.5f) {
    val k = clamped * 2f
    Color(
      red = c1.red + (c2.red - c1.red) * k,
      green = c1.green + (c2.green - c1.green) * k,
      blue = c1.blue + (c2.blue - c1.blue) * k,
      alpha = 1f,
    )
  } else {
    val k = (clamped - 0.5f) * 2f
    Color(
      red = c2.red + (c3.red - c2.red) * k,
      green = c2.green + (c3.green - c2.green) * k,
      blue = c2.blue + (c3.blue - c2.blue) * k,
      alpha = 1f,
    )
  }
}
