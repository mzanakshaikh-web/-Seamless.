package com.example.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioAnalyzerBus
import com.example.audio.PlaybackBridge
import com.example.audio.PlaybackUiState
import com.example.audio.SeamlessPlaybackService
import com.example.data.DeviceAudioRepository
import com.example.data.SettingsRepository
import com.example.model.AlbumGroup
import com.example.model.AppThemePreset
import com.example.model.ArtistGroup
import com.example.model.AudioFrame
import com.example.model.EqPreset
import com.example.model.FolderGroup
import com.example.model.InfinityBlendProfile
import com.example.model.InfinityTransitionState
import com.example.model.LibraryFilter
import com.example.model.ReactionStyle
import com.example.model.SortOrder
import com.example.model.Track
import com.example.model.UserPreferences
import com.example.model.WidgetShapeStyle
import com.example.widget.SeamlessWidgetUpdater
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

  private val appContext = application.applicationContext
  private val audioRepo = DeviceAudioRepository(appContext)
  private val settingsRepo = SettingsRepository(appContext)

  val preferences: StateFlow<UserPreferences> = settingsRepo.preferencesFlow.stateIn(
    scope = viewModelScope,
    started = SharingStarted.Eagerly,
    initialValue = UserPreferences(),
  )

  val playbackState: StateFlow<PlaybackUiState> = PlaybackBridge.state
  val audioFrame: StateFlow<AudioFrame> = AudioAnalyzerBus.audioFrame
  val infinityState: StateFlow<InfinityTransitionState> = AudioAnalyzerBus.infinityState

  private val _allTracks = MutableStateFlow<List<Track>>(emptyList())
  val allTracks: StateFlow<List<Track>> = _allTracks.asStateFlow()

  private val _isScanning = MutableStateFlow(false)
  val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

  private val _hasAudioPermission = MutableStateFlow(audioRepo.hasAudioReadPermission())
  val hasAudioPermission: StateFlow<Boolean> = _hasAudioPermission.asStateFlow()

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _libraryFilter = MutableStateFlow(LibraryFilter.TRACKS)
  val libraryFilter: StateFlow<LibraryFilter> = _libraryFilter.asStateFlow()

  private val _sortOrder = MutableStateFlow(SortOrder.RECENT)
  val sortOrder: StateFlow<SortOrder> = _sortOrder.asStateFlow()

  val filteredTracks: StateFlow<List<Track>> = combine(
    _allTracks,
    _searchQuery,
    _sortOrder,
    _libraryFilter,
    preferences,
  ) { tracks, query, sort, filter, prefs ->
    val q = query.trim().lowercase()
    val base = when (filter) {
      LibraryFilter.FAVORITES -> tracks.filter { it.id in prefs.favoriteIds }
      else -> tracks
    }
    val searched = if (q.isEmpty()) {
      base
    } else {
      base.filter {
        it.title.lowercase().contains(q) ||
          it.artist.lowercase().contains(q) ||
          it.album.lowercase().contains(q) ||
          it.folderName.lowercase().contains(q)
      }
    }
    when (sort) {
      SortOrder.TITLE -> searched.sortedBy { it.title.lowercase() }
      SortOrder.ARTIST -> searched.sortedBy { it.artist.lowercase() }
      SortOrder.RECENT -> searched.sortedByDescending { it.dateAdded }
      SortOrder.DURATION -> searched.sortedByDescending { it.durationMs }
    }
  }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  val albums: StateFlow<List<AlbumGroup>> = _allTracks.combine(_searchQuery) { tracks, query ->
    val q = query.trim().lowercase()
    tracks.groupBy { it.albumId to it.album }
      .map { (key, list) ->
        AlbumGroup(
          albumId = key.first,
          name = key.second,
          artist = list.firstOrNull()?.artist ?: "Unknown Artist",
          artUri = list.firstNotNullOfOrNull { it.albumArtUri },
          tracks = list,
        )
      }
      .filter { q.isEmpty() || it.name.lowercase().contains(q) || it.artist.lowercase().contains(q) }
      .sortedBy { it.name.lowercase() }
  }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  val artists: StateFlow<List<ArtistGroup>> = _allTracks.combine(_searchQuery) { tracks, query ->
    val q = query.trim().lowercase()
    tracks.groupBy { it.artist }
      .map { (artist, list) ->
        ArtistGroup(
          name = artist,
          tracks = list,
          artUri = list.firstNotNullOfOrNull { it.albumArtUri },
        )
      }
      .filter { q.isEmpty() || it.name.lowercase().contains(q) }
      .sortedBy { it.name.lowercase() }
  }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  val folders: StateFlow<List<FolderGroup>> = _allTracks.combine(_searchQuery) { tracks, query ->
    val q = query.trim().lowercase()
    tracks.groupBy { it.folderName }
      .map { (folder, list) -> FolderGroup(name = folder, tracks = list) }
      .filter { q.isEmpty() || it.name.lowercase().contains(q) }
      .sortedBy { it.name.lowercase() }
  }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  init {
    refreshPermissionAndScan()
  }

  fun refreshPermissionAndScan() {
    _hasAudioPermission.value = audioRepo.hasAudioReadPermission()
    scanLibrary()
  }

  fun scanLibrary() {
    viewModelScope.launch {
      _isScanning.value = true
      _allTracks.value = audioRepo.loadAllTracks()
      _isScanning.value = false
    }
  }

  fun importAudioFile(uri: Uri) {
    viewModelScope.launch {
      val imported = audioRepo.importAudioUri(uri)
      _allTracks.value = audioRepo.loadAllTracks()
      if (imported != null) {
        val currentList = _allTracks.value
        val idx = currentList.indexOfFirst { it.uri == imported.uri }.coerceAtLeast(0)
        playTracks(currentList, idx)
      }
    }
  }

  fun loadStudioSoundcheck() {
    viewModelScope.launch {
      _isScanning.value = true
      val loaded = audioRepo.generateStudioSoundcheck()
      _allTracks.value = loaded
      _isScanning.value = false
      if (loaded.isNotEmpty()) {
        playTracks(loaded, 0)
      }
    }
  }

  fun playTracks(tracks: List<Track>, startIndex: Int) {
    if (tracks.isEmpty()) return
    ensureServiceRunning()
    viewModelScope.launch {
      // Wait briefly if service is binding on very first tap
      var attempts = 0
      while (PlaybackBridge.serviceRef == null && attempts < 20) {
        kotlinx.coroutines.delay(40L)
        attempts++
      }
      PlaybackBridge.playQueue(tracks, startIndex)
    }
  }

  fun togglePlayPause() {
    if (playbackState.value.currentTrack == null && _allTracks.value.isNotEmpty()) {
      playTracks(_allTracks.value, 0)
    } else {
      PlaybackBridge.togglePlayPause()
    }
  }

  fun next(forceInfinityMashup: Boolean = false) = PlaybackBridge.next(forceInfinityMashup)
  fun previous() = PlaybackBridge.previous()
  fun seekTo(posMs: Long) = PlaybackBridge.seekTo(posMs)
  fun toggleShuffle() = PlaybackBridge.toggleShuffle()
  fun cycleRepeatMode() = PlaybackBridge.cycleRepeatMode()
  fun setSleepTimerMinutes(minutes: Int?) = PlaybackBridge.setSleepTimerMinutes(minutes)
  fun jumpToQueueIndex(index: Int) = PlaybackBridge.jumpToQueueIndex(index)
  fun removeFromQueue(index: Int) = PlaybackBridge.removeFromQueue(index)

  private fun ensureServiceRunning() {
    val intent = Intent(appContext, SeamlessPlaybackService::class.java)
    runCatching {
      appContext.startService(intent)
    }.onFailure {
      intent.putExtra(SeamlessPlaybackService.EXTRA_STARTED_FOREGROUND, true)
      runCatching { ContextCompat.startForegroundService(appContext, intent) }
    }
  }

  fun setSearchQuery(query: String) { _searchQuery.value = query }
  fun setLibraryFilter(filter: LibraryFilter) { _libraryFilter.value = filter }
  fun setSortOrder(order: SortOrder) { _sortOrder.value = order }

  fun completeOnboarding(style: ReactionStyle) {
    viewModelScope.launch { settingsRepo.completeOnboarding(style) }
  }

  fun setReactionStyle(style: ReactionStyle) {
    viewModelScope.launch { settingsRepo.setReactionStyle(style) }
  }

  fun setThemePreset(preset: AppThemePreset) {
    viewModelScope.launch {
      settingsRepo.setThemePreset(preset)
      syncWidgetWithLatestPrefs()
    }
  }

  fun setCustomPrimary(argb: Int?) {
    viewModelScope.launch {
      settingsRepo.setCustomPrimary(argb)
      syncWidgetWithLatestPrefs()
    }
  }

  fun setCustomAccent(argb: Int?) {
    viewModelScope.launch {
      settingsRepo.setCustomAccent(argb)
      syncWidgetWithLatestPrefs()
    }
  }

  fun setInfinityEnabled(enabled: Boolean) {
    viewModelScope.launch { settingsRepo.setInfinityEnabled(enabled) }
  }

  fun setInfinityDurationSec(sec: Int) {
    viewModelScope.launch { settingsRepo.setInfinityDurationSec(sec) }
  }

  fun setInfinityProfile(profile: InfinityBlendProfile) {
    viewModelScope.launch { settingsRepo.setInfinityProfile(profile) }
  }

  fun setHapticsEnabled(enabled: Boolean) {
    viewModelScope.launch { settingsRepo.setHapticsEnabled(enabled) }
  }

  fun setEqPreset(preset: EqPreset) {
    viewModelScope.launch { settingsRepo.setEqPreset(preset) }
  }

  fun setEqBands(bands: List<Float>) {
    viewModelScope.launch { settingsRepo.setEqBands(bands) }
  }

  fun setBassBoost(strength: Float) {
    viewModelScope.launch { settingsRepo.setBassBoost(strength) }
  }

  fun setPlaybackSpeed(speed: Float) {
    viewModelScope.launch { settingsRepo.setPlaybackSpeed(speed) }
  }

  fun setWidgetShapeStyle(style: WidgetShapeStyle) {
    viewModelScope.launch {
      settingsRepo.setWidgetShapeStyle(style)
      syncWidgetWithLatestPrefs()
    }
  }

  fun setWidgetWaveIntensity(intensity: Float) {
    viewModelScope.launch {
      settingsRepo.setWidgetWaveIntensity(intensity)
      syncWidgetWithLatestPrefs()
    }
  }

  fun setWidgetMatteOpacity(opacity: Float) {
    viewModelScope.launch {
      settingsRepo.setWidgetMatteOpacity(opacity)
      syncWidgetWithLatestPrefs()
    }
  }

  fun toggleFavorite(trackId: Long) {
    viewModelScope.launch { settingsRepo.toggleFavorite(trackId) }
  }

  fun createPlaylist(name: String, initialTrackId: Long? = null) {
    viewModelScope.launch { settingsRepo.createPlaylist(name, initialTrackId) }
  }

  fun addTrackToPlaylist(playlistId: String, trackId: Long) {
    viewModelScope.launch { settingsRepo.addTrackToPlaylist(playlistId, trackId) }
  }

  fun deletePlaylist(playlistId: String) {
    viewModelScope.launch { settingsRepo.deletePlaylist(playlistId) }
  }

  private suspend fun syncWidgetWithLatestPrefs() {
    kotlinx.coroutines.delay(50L)
    val state = playbackState.value
    val progress = if (state.durationMs > 0L) {
      state.positionMs.toFloat() / state.durationMs.toFloat()
    } else 0f
    SeamlessWidgetUpdater.pushUpdate(
      context = appContext,
      track = state.currentTrack,
      isPlaying = state.isPlaying,
      progress = progress,
      wavePhase = audioFrame.value.phase,
      prefs = preferences.value,
      infinityState = infinityState.value,
    )
  }
}
