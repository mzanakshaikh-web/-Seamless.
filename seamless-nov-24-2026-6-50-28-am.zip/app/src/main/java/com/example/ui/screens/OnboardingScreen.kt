package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.AllInclusive
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.NotificationsNone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.model.AudioFrame
import com.example.model.ReactionStyle
import com.example.ui.components.ReactionCircleContainer
import com.example.ui.components.SeamlessArtwork
import com.example.ui.components.SeamlessHaptics
import com.example.ui.components.SeamlessLogoMark
import com.example.ui.theme.LocalSeamlessPalette

private enum class OnboardingStep {
  PERMISSIONS,
  REACTION_STYLE,
}

@Composable
fun OnboardingScreen(
  hasAudioPermission: Boolean,
  initialStyle: ReactionStyle,
  audioFrame: AudioFrame,
  isPlaying: Boolean,
  haptics: SeamlessHaptics,
  onPermissionsResult: () -> Unit,
  onComplete: (ReactionStyle) -> Unit,
) {
  val palette = LocalSeamlessPalette.current
  var step by remember(hasAudioPermission) {
    mutableStateOf(if (hasAudioPermission) OnboardingStep.REACTION_STYLE else OnboardingStep.PERMISSIONS)
  }
  var selectedStyle by remember { mutableStateOf(initialStyle) }

  val permissionsToRequest = remember {
    buildList {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        add(Manifest.permission.READ_MEDIA_AUDIO)
        add(Manifest.permission.POST_NOTIFICATIONS)
      } else {
        add(Manifest.permission.READ_EXTERNAL_STORAGE)
      }
    }.toTypedArray()
  }

  val permissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestMultiplePermissions()
  ) {
    onPermissionsResult()
    step = OnboardingStep.REACTION_STYLE
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          colors = listOf(palette.background, palette.surface, palette.background)
        )
      )
      .safeDrawingPadding(),
    contentAlignment = Alignment.Center,
  ) {
    AnimatedContent(
      targetState = step,
      transitionSpec = { fadeIn() togetherWith fadeOut() },
      modifier = Modifier.fillMaxSize(),
      label = "onboarding_step",
    ) { currentStep ->
      when (currentStep) {
        OnboardingStep.PERMISSIONS -> {
          Column(
            modifier = Modifier
              .fillMaxSize()
              .widthIn(max = 560.dp)
              .verticalScroll(rememberScrollState())
              .padding(horizontal = 24.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Spacer(modifier = Modifier.height(16.dp))
              SeamlessLogoMark(size = 76.dp)
              Spacer(modifier = Modifier.height(20.dp))
              Text(
                text = "Welcome to Seamless",
                style = MaterialTheme.typography.displaySmall,
                color = palette.onBackground,
                textAlign = TextAlign.Center,
              )
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "Matte-minimalist device audio crafted for fluid transitions and live visual resonance.",
                style = MaterialTheme.typography.bodyLarge,
                color = palette.onSurfaceMuted,
                textAlign = TextAlign.Center,
              )
            }

            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp),
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              PermissionInfoCard(
                icon = Icons.Rounded.LibraryMusic,
                title = "Device Audio Access",
                description = "Reads your local songs, albums, folders, and embedded artwork directly from your device.",
              )
              PermissionInfoCard(
                icon = Icons.Rounded.NotificationsNone,
                title = "Playback Controls",
                description = "Enables seamless background playback, lockscreen controls, and Infinity transitions.",
              )
              PermissionInfoCard(
                icon = Icons.Rounded.AllInclusive,
                title = "Zero-Latency Audio Analysis",
                description = "Computes accurate live FFT spectrums directly from playback—no microphone needed.",
              )
            }

            Column(
              modifier = Modifier.fillMaxWidth(),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Button(
                onClick = {
                  haptics.tap()
                  permissionLauncher.launch(permissionsToRequest)
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(54.dp)
                  .testTag("grant_permissions_button"),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = palette.primary,
                  contentColor = MaterialTheme.colorScheme.onPrimary,
                ),
              ) {
                Text(
                  text = "Allow Audio Access",
                  style = MaterialTheme.typography.titleMedium,
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null)
              }

              OutlinedButton(
                onClick = {
                  haptics.tick()
                  step = OnboardingStep.REACTION_STYLE
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(48.dp)
                  .testTag("skip_permissions_button"),
                shape = RoundedCornerShape(16.dp),
              ) {
                Text("Continue Without Scanning", color = palette.onSurfaceMuted)
              }
            }
          }
        }

        OnboardingStep.REACTION_STYLE -> {
          Column(
            modifier = Modifier
              .fillMaxSize()
              .widthIn(max = 580.dp)
              .verticalScroll(rememberScrollState())
              .padding(vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier.padding(horizontal = 24.dp),
            ) {
              Surface(
                color = palette.primary.copy(alpha = 0.14f),
                shape = CircleShape,
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(
                    imageVector = Icons.Rounded.GraphicEq,
                    contentDescription = null,
                    tint = palette.primary,
                    modifier = Modifier.size(16.dp),
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = "FIRST STEP • REACTION CIRCLE",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.primary,
                  )
                }
              }
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = "Choose Your Reaction Circle",
                style = MaterialTheme.typography.headlineMedium,
                color = palette.onBackground,
                textAlign = TextAlign.Center,
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Every song—with or without artwork—breathes with your chosen aura. Pick from 12 styles.",
                style = MaterialTheme.typography.bodyMedium,
                color = palette.onSurfaceMuted,
                textAlign = TextAlign.Center,
              )
            }

            Box(
              modifier = Modifier
                .padding(vertical = 16.dp)
                .size(250.dp),
              contentAlignment = Alignment.Center,
            ) {
              ReactionCircleContainer(
                style = selectedStyle,
                audioFrame = audioFrame,
                isPlaying = isPlaying,
                demoMode = true,
                modifier = Modifier.fillMaxSize(),
              ) { artMod ->
                SeamlessArtwork(
                  albumArtUri = null,
                  contentDescription = "Seamless artwork preview",
                  circular = true,
                  modifier = artMod,
                )
              }
            }

            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Text(
                text = selectedStyle.title,
                style = MaterialTheme.typography.titleLarge,
                color = palette.onBackground,
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = selectedStyle.subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = palette.onSurfaceMuted,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 28.dp),
              )

              Spacer(modifier = Modifier.height(16.dp))

              LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                items(ReactionStyle.entries, key = { it.name }) { style ->
                  val isSelected = style == selectedStyle
                  Surface(
                    modifier = Modifier
                      .width(142.dp)
                      .clip(RoundedCornerShape(16.dp))
                      .border(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) palette.primary else palette.outlineSubtle.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(16.dp),
                      )
                      .clickable {
                        haptics.tick()
                        selectedStyle = style
                      }
                      .testTag("onboarding_style_${style.name.lowercase()}"),
                    color = if (isSelected) palette.surfaceHighest else palette.surfaceElevated,
                    shape = RoundedCornerShape(16.dp),
                  ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                      Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                      ) {
                        Text(
                          text = style.badge.uppercase(),
                          style = MaterialTheme.typography.labelSmall,
                          color = if (isSelected) palette.primary else palette.onSurfaceMuted,
                        )
                        if (isSelected) {
                          Icon(
                            imageVector = Icons.Rounded.Check,
                            contentDescription = "Selected",
                            tint = palette.primary,
                            modifier = Modifier.size(16.dp),
                          )
                        }
                      }
                      Spacer(modifier = Modifier.height(6.dp))
                      Text(
                        text = style.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = palette.onSurface,
                        maxLines = 1,
                      )
                    }
                  }
                }
              }

              Spacer(modifier = Modifier.height(22.dp))

              Button(
                onClick = {
                  haptics.strong()
                  onComplete(selectedStyle)
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 24.dp)
                  .height(54.dp)
                  .testTag("finish_onboarding_button"),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = palette.primary,
                  contentColor = MaterialTheme.colorScheme.onPrimary,
                ),
              ) {
                Text(
                  text = "Enter Seamless",
                  style = MaterialTheme.typography.titleMedium,
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PermissionInfoCard(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  title: String,
  description: String,
) {
  val palette = LocalSeamlessPalette.current
  Surface(
    color = palette.surfaceElevated,
    shape = RoundedCornerShape(18.dp),
    modifier = Modifier
      .fillMaxWidth()
      .border(1.dp, palette.outlineSubtle.copy(alpha = 0.45f), RoundedCornerShape(18.dp)),
  ) {
    Row(
      modifier = Modifier.padding(16.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier = Modifier
          .size(42.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(palette.primary.copy(alpha = 0.14f)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(icon, contentDescription = null, tint = palette.primary)
      }
      Spacer(modifier = Modifier.width(14.dp))
      Column {
        Text(
          text = title,
          style = MaterialTheme.typography.titleSmall,
          color = palette.onSurface,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = description,
          style = MaterialTheme.typography.bodySmall,
          color = palette.onSurfaceMuted,
        )
      }
    }
  }
}
