package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.AlbumGroup
import com.example.model.ArtistGroup
import com.example.model.FolderGroup
import com.example.model.LibraryFilter
import com.example.model.SortOrder
import com.example.model.Track
import com.example.model.UserPlaylist
import com.example.model.UserPreferences
import com.example.ui.components.SeamlessArtwork
import com.example.ui.components.SeamlessHaptics
import com.example.ui.theme.LocalSeamlessPalette

@Composable
fun LibraryScreen(
  allTracks: List<Track>,
  filteredTracks: List<Track>,
  albums: List<AlbumGroup>,
  artists: List<ArtistGroup>,
  folders: List<FolderGroup>,
  currentTrack: Track?,
  isPlaying: Boolean,
  searchQuery: String,
  activeFilter: LibraryFilter,
  sortOrder: SortOrder,
  prefs: UserPreferences,
  haptics: SeamlessHaptics,
  onSearchChange: (String) -> Unit,
  onFilterChange: (LibraryFilter) -> Unit,
  onSortChange: (SortOrder) -> Unit,
  onPlayQueue: (List<Track>, Int) -> Unit,
  onToggleFavorite: (Long) -> Unit,
  onCreatePlaylist: (String, Long?) -> Unit,
  onAddTrackToPlaylist: (String, Long) -> Unit,
  onDeletePlaylist: (String) -> Unit,
  onImportAudio: () -> Unit,
  bottomContentPadding: Dp,
) {
  val palette = LocalSeamlessPalette.current
  var showSortMenu by remember { mutableStateOf(false) }
  var showNewPlaylistDialog by remember { mutableStateOf(false) }
  var trackForPlaylistDialog by remember { mutableStateOf<Track?>(null) }
  var selectedPlaylist by remember { mutableStateOf<UserPlaylist?>(null) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(palette.background),
  ) {
    // Top Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(start = 20.dp, end = 12.dp, top = 12.dp, bottom = 8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = "Library",
        style = MaterialTheme.typography.headlineMedium,
        color = palette.onBackground,
      )
      Row {
        IconButton(
          onClick = {
            haptics.tick()
            onImportAudio()
          },
          modifier = Modifier.testTag("library_import_button"),
        ) {
          Icon(Icons.Rounded.AudioFile, contentDescription = "Import audio", tint = palette.onSurface)
        }
        Box {
          IconButton(
            onClick = {
              haptics.tick()
              showSortMenu = true
            },
            modifier = Modifier.testTag("library_sort_button"),
          ) {
            Icon(Icons.Rounded.Sort, contentDescription = "Sort tracks", tint = palette.onSurface)
          }
          DropdownMenu(
            expanded = showSortMenu,
            onDismissRequest = { showSortMenu = false },
          ) {
            SortOrder.entries.forEach { order ->
              DropdownMenuItem(
                text = {
                  Text(
                    text = order.label,
                    color = if (order == sortOrder) palette.primary else palette.onSurface,
                  )
                },
                onClick = {
                  haptics.tick()
                  onSortChange(order)
                  showSortMenu = false
                },
              )
            }
          }
        }
      }
    }

    // Search Field
    OutlinedTextField(
      value = searchQuery,
      onValueChange = onSearchChange,
      placeholder = { Text("Search songs, artists, albums, folders") },
      leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
      trailingIcon = {
        if (searchQuery.isNotEmpty()) {
          IconButton(onClick = { onSearchChange("") }) {
            Icon(Icons.Rounded.Close, contentDescription = "Clear search")
          }
        }
      },
      singleLine = true,
      shape = RoundedCornerShape(16.dp),
      colors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = palette.surfaceElevated,
        unfocusedContainerColor = palette.surfaceElevated,
        focusedBorderColor = palette.primary,
        unfocusedBorderColor = palette.outlineSubtle.copy(alpha = 0.5f),
      ),
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp)
        .testTag("library_search_input"),
    )

    Spacer(modifier = Modifier.height(10.dp))

    // Filter Chips
    LazyRow(
      contentPadding = PaddingValues(horizontal = 20.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      items(LibraryFilter.entries) { filter ->
        val selected = filter == activeFilter
        FilterChip(
          selected = selected,
          onClick = {
            haptics.tick()
            selectedPlaylist = null
            onFilterChange(filter)
          },
          label = {
            Text(
              text = filter.name.lowercase().replaceFirstChar { it.uppercase() },
              style = MaterialTheme.typography.labelLarge,
            )
          },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = palette.primary.copy(alpha = 0.18f),
            selectedLabelColor = palette.primary,
            containerColor = palette.surfaceElevated,
            labelColor = palette.onSurfaceMuted,
          ),
          border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = selected,
            borderColor = palette.outlineSubtle.copy(alpha = 0.45f),
            selectedBorderColor = palette.primary,
          ),
          modifier = Modifier.testTag("filter_${filter.name.lowercase()}"),
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    when (activeFilter) {
      LibraryFilter.TRACKS, LibraryFilter.FAVORITES -> {
        if (filteredTracks.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(32.dp),
            contentAlignment = Alignment.Center,
          ) {
            Text(
              text = if (activeFilter == LibraryFilter.FAVORITES) {
                "Tap the heart icon on any track to add it to Favorites."
              } else {
                "No matching device tracks found."
              },
              style = MaterialTheme.typography.bodyMedium,
              color = palette.onSurfaceMuted,
            )
          }
        } else {
          LazyColumn(
            contentPadding = PaddingValues(
              start = 20.dp,
              end = 20.dp,
              top = 4.dp,
              bottom = bottomContentPadding + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            itemsIndexed(filteredTracks, key = { _, t -> t.id }) { idx, track ->
              val isActive = currentTrack?.id == track.id
              val isFav = track.id in prefs.favoriteIds
              var menuExpanded by remember { mutableStateOf(false) }

              TrackListItemRow(
                track = track,
                isActive = isActive,
                isPlaying = isActive && isPlaying,
                isFavorite = isFav,
                onClick = {
                  haptics.tap()
                  onPlayQueue(filteredTracks, idx)
                },
                onToggleFavorite = { onToggleFavorite(track.id) },
                trailingContent = {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                      onClick = {
                        haptics.tick()
                        onToggleFavorite(track.id)
                      },
                      modifier = Modifier.size(38.dp),
                    ) {
                      Icon(
                        imageVector = if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = "Toggle favorite",
                        tint = if (isFav) palette.primary else palette.onSurfaceMuted,
                        modifier = Modifier.size(18.dp),
                      )
                    }
                    Box {
                      IconButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier.size(36.dp),
                      ) {
                        Icon(
                          Icons.Rounded.MoreVert,
                          contentDescription = "Track options",
                          tint = palette.onSurfaceMuted,
                          modifier = Modifier.size(18.dp),
                        )
                      }
                      DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false },
                      ) {
                        DropdownMenuItem(
                          text = { Text("Add to Playlist") },
                          onClick = {
                            menuExpanded = false
                            trackForPlaylistDialog = track
                          },
                        )
                        DropdownMenuItem(
                          text = { Text("Play Next / Blend") },
                          onClick = {
                            menuExpanded = false
                            onPlayQueue(filteredTracks, idx)
                          },
                        )
                      }
                    }
                  }
                },
              )
            }
          }
        }
      }

      LibraryFilter.ALBUMS -> {
        LazyVerticalGrid(
          columns = GridCells.Adaptive(152.dp),
          contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = 4.dp,
            bottom = bottomContentPadding + 24.dp,
          ),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          items(albums, key = { "${it.albumId}_${it.name}" }) { album ->
            Surface(
              modifier = Modifier
                .clip(RoundedCornerShape(18.dp))
                .clickable {
                  haptics.tap()
                  onPlayQueue(album.tracks, 0)
                },
              color = palette.surfaceElevated,
              shape = RoundedCornerShape(18.dp),
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                SeamlessArtwork(
                  albumArtUri = album.artUri,
                  contentDescription = album.name,
                  circular = false,
                  cornerRadius = 14.dp,
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(132.dp),
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                  text = album.name,
                  style = MaterialTheme.typography.titleSmall,
                  color = palette.onSurface,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Text(
                  text = "${album.artist} • ${album.tracks.size}",
                  style = MaterialTheme.typography.bodySmall,
                  color = palette.onSurfaceMuted,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }
            }
          }
        }
      }

      LibraryFilter.ARTISTS -> {
        LazyColumn(
          contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = 4.dp,
            bottom = bottomContentPadding + 24.dp,
          ),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          items(artists, key = { it.name }) { artist ->
            Surface(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .clickable {
                  haptics.tap()
                  onPlayQueue(artist.tracks, 0)
                },
              color = palette.surfaceElevated,
              shape = RoundedCornerShape(16.dp),
            ) {
              Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Box(
                  modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(palette.primary.copy(alpha = 0.14f)),
                  contentAlignment = Alignment.Center,
                ) {
                  Icon(Icons.Rounded.Person, contentDescription = null, tint = palette.primary)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(artist.name, style = MaterialTheme.typography.titleSmall, color = palette.onSurface)
                  Text(
                    "${artist.tracks.size} tracks",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.onSurfaceMuted,
                  )
                }
              }
            }
          }
        }
      }

      LibraryFilter.FOLDERS -> {
        LazyColumn(
          contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = 4.dp,
            bottom = bottomContentPadding + 24.dp,
          ),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          items(folders, key = { it.name }) { folder ->
            Surface(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .clickable {
                  haptics.tap()
                  onPlayQueue(folder.tracks, 0)
                },
              color = palette.surfaceElevated,
              shape = RoundedCornerShape(16.dp),
            ) {
              Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Box(
                  modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(palette.secondary.copy(alpha = 0.15f)),
                  contentAlignment = Alignment.Center,
                ) {
                  Icon(Icons.Rounded.Folder, contentDescription = null, tint = palette.secondary)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(folder.name, style = MaterialTheme.typography.titleSmall, color = palette.onSurface)
                  Text(
                    "${folder.tracks.size} audio files",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.onSurfaceMuted,
                  )
                }
              }
            }
          }
        }
      }

      LibraryFilter.PLAYLISTS -> {
        val activePlaylist = selectedPlaylist
        if (activePlaylist != null) {
          val plTracks = activePlaylist.trackIds.mapNotNull { id -> allTracks.find { it.id == id } }
          Column(modifier = Modifier.fillMaxSize()) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              TextButton(onClick = { selectedPlaylist = null }) {
                Text("← All Playlists", color = palette.primary)
              }
              Text(activePlaylist.name, style = MaterialTheme.typography.titleMedium, color = palette.onSurface)
            }
            LazyColumn(
              contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              itemsIndexed(plTracks, key = { _, t -> t.id }) { idx, track ->
                TrackListItemRow(
                  track = track,
                  isActive = currentTrack?.id == track.id,
                  isPlaying = currentTrack?.id == track.id && isPlaying,
                  isFavorite = track.id in prefs.favoriteIds,
                  onClick = {
                    haptics.tap()
                    onPlayQueue(plTracks, idx)
                  },
                  onToggleFavorite = null,
                )
              }
            }
          }
        } else {
          LazyColumn(
            contentPadding = PaddingValues(
              start = 20.dp,
              end = 20.dp,
              top = 4.dp,
              bottom = bottomContentPadding + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            item {
              Surface(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(16.dp))
                  .border(1.dp, palette.primary.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
                  .clickable {
                    haptics.tick()
                    showNewPlaylistDialog = true
                  }
                  .testTag("create_playlist_button"),
                color = palette.primary.copy(alpha = 0.1f),
                shape = RoundedCornerShape(16.dp),
              ) {
                Row(
                  modifier = Modifier.padding(14.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(Icons.Rounded.Add, contentDescription = null, tint = palette.primary)
                  Spacer(modifier = Modifier.width(10.dp))
                  Text("Create New Playlist", style = MaterialTheme.typography.titleSmall, color = palette.primary)
                }
              }
            }
            items(prefs.playlists, key = { it.id }) { pl ->
              Surface(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(16.dp))
                  .clickable {
                    haptics.tap()
                    selectedPlaylist = pl
                  },
                color = palette.surfaceElevated,
                shape = RoundedCornerShape(16.dp),
              ) {
                Row(
                  modifier = Modifier.padding(14.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(Icons.Rounded.QueueMusic, contentDescription = null, tint = palette.tertiary)
                  Spacer(modifier = Modifier.width(12.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(pl.name, style = MaterialTheme.typography.titleSmall, color = palette.onSurface)
                    Text("${pl.trackIds.size} tracks", style = MaterialTheme.typography.bodySmall, color = palette.onSurfaceMuted)
                  }
                  IconButton(onClick = { onDeletePlaylist(pl.id) }) {
                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete playlist", tint = palette.onSurfaceMuted)
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (showNewPlaylistDialog) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showNewPlaylistDialog = false },
      title = { Text("New Playlist") },
      text = {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          placeholder = { Text("Playlist name") },
          singleLine = true,
        )
      },
      confirmButton = {
        TextButton(
          onClick = {
            if (name.isNotBlank()) {
              onCreatePlaylist(name, null)
              showNewPlaylistDialog = false
            }
          }
        ) {
          Text("Create")
        }
      },
      dismissButton = {
        TextButton(onClick = { showNewPlaylistDialog = false }) { Text("Cancel") }
      },
    )
  }

  trackForPlaylistDialog?.let { targetTrack ->
    AlertDialog(
      onDismissRequest = { trackForPlaylistDialog = null },
      title = { Text("Add to Playlist") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          if (prefs.playlists.isEmpty()) {
            Text("No playlists yet. Create one directly with this track:", style = MaterialTheme.typography.bodySmall)
          } else {
            prefs.playlists.forEach { pl ->
              Surface(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(12.dp))
                  .clickable {
                    onAddTrackToPlaylist(pl.id, targetTrack.id)
                    trackForPlaylistDialog = null
                  },
                color = palette.surfaceElevated,
              ) {
                Text(pl.name, modifier = Modifier.padding(12.dp))
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(
          onClick = {
            onCreatePlaylist("${targetTrack.artist} Mix", targetTrack.id)
            trackForPlaylistDialog = null
          }
        ) {
          Text("New Mix Playlist")
        }
      },
      dismissButton = {
        TextButton(onClick = { trackForPlaylistDialog = null }) { Text("Close") }
      },
    )
  }
}
