package com.example.ui.components

import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.ui.theme.LocalSeamlessPalette

/**
 * Circular or rounded-square album artwork with a signature matte-slate Seamless emblem fallback
 * whenever an individual song lacks embedded album art.
 */
@Composable
fun SeamlessArtwork(
  albumArtUri: Uri?,
  contentDescription: String,
  modifier: Modifier = Modifier,
  circular: Boolean = true,
  cornerRadius: Dp = 14.dp,
  subtleBorder: Boolean = true,
) {
  val palette = LocalSeamlessPalette.current
  val shape = if (circular) CircleShape else RoundedCornerShape(cornerRadius)
  var imageFailed by remember(albumArtUri) { mutableStateOf(false) }

  Box(
    modifier = modifier
      .clip(shape)
      .background(
        Brush.linearGradient(
          colors = listOf(palette.surfaceElevated, palette.surfaceHighest),
        )
      )
      .then(
        if (subtleBorder) {
          Modifier.border(1.dp, palette.outlineSubtle.copy(alpha = 0.55f), shape)
        } else {
          Modifier
        }
      ),
    contentAlignment = Alignment.Center,
  ) {
    if (albumArtUri != null && !imageFailed) {
      AsyncImage(
        model = ImageRequest.Builder(LocalContext.current)
          .data(albumArtUri)
          .crossfade(250)
          .build(),
        contentDescription = contentDescription,
        contentScale = ContentScale.Crop,
        onError = { imageFailed = true },
        modifier = Modifier.fillMaxSize(),
      )
    } else {
      // Matte slate fallback emblem echoing the Seamless icon wave
      SeamlessFallbackArt(
        primary = palette.primary,
        secondary = palette.secondary,
        tertiary = palette.tertiary,
        surfaceBase = palette.surfaceHighest,
      )
    }
  }
}

@Composable
private fun SeamlessFallbackArt(
  primary: Color,
  secondary: Color,
  tertiary: Color,
  surfaceBase: Color,
) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.radialGradient(
          colors = listOf(
            surfaceBase,
            Color(0xFF23262A),
          )
        )
      ),
    contentAlignment = Alignment.Center,
  ) {
    Canvas(modifier = Modifier.fillMaxSize().padding(18.dp)) {
      val w = size.width
      val h = size.height
      val waveBrush = Brush.linearGradient(
        colors = listOf(primary, secondary, tertiary),
        start = Offset(0f, h),
        end = Offset(w, 0f),
      )
      val pathA = Path().apply {
        moveTo(w * 0.14f, h * 0.68f)
        cubicTo(w * 0.42f, h * 0.68f, w * 0.52f, h * 0.24f, w * 0.86f, h * 0.28f)
      }
      val pathB = Path().apply {
        moveTo(w * 0.14f, h * 0.80f)
        cubicTo(w * 0.48f, h * 0.78f, w * 0.50f, h * 0.34f, w * 0.86f, h * 0.40f)
      }
      drawPath(
        path = pathA,
        brush = waveBrush,
        style = Stroke(width = (w * 0.045f).coerceIn(2f, 8f), cap = StrokeCap.Round),
      )
      drawPath(
        path = pathB,
        brush = waveBrush,
        alpha = 0.75f,
        style = Stroke(width = (w * 0.038f).coerceIn(1.8f, 6.5f), cap = StrokeCap.Round),
      )
    }
  }
}

@Composable
fun SeamlessLogoMark(modifier: Modifier = Modifier, size: Dp = 36.dp) {
  Image(
    painter = painterResource(id = R.drawable.seamless_brand_mark),
    contentDescription = "Seamless logo",
    contentScale = ContentScale.Crop,
    modifier = modifier
      .size(size)
      .clip(RoundedCornerShape(size * 0.28f))
      .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(size * 0.28f)),
  )
}
