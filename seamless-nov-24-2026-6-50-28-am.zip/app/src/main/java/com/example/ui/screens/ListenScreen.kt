package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AllInclusive
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.FolderGroup
import com.example.model.Track
import com.example.model.UserPreferences
import com.example.ui.components.SeamlessArtwork
import com.example.ui.components.SeamlessHaptics
import com.example.ui.components.SeamlessLogoMark
import com.example.ui.components.formatDuration
import com.example.ui.theme.LocalSeamlessPalette

@Composable
fun ListenScreen(
  tracks: List<Track>,
  folders: List<FolderGroup>,
  currentTrack: Track?,
  isPlaying: Boolean,
  prefs: UserPreferences,
  isScanning: Boolean,
  haptics: SeamlessHaptics,
  onPlayQueue: (List<Track>, Int) -> Unit,
  onOpenInfinitySheet: () -> Unit,
  onOpenLibrary: () -> Unit,
  onImportAudioClick: () -> Unit,
  onRescanClick: () -> Unit,
  onLoadSoundcheckClick: () -> Unit,
  bottomContentPadding: androidx.compose.ui.unit.Dp,
) {
  val palette = LocalSeamlessPalette.current
  val recentTracks = prefs.recentTrackIds.mapNotNull { id -> tracks.find { it.id == id } }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(palette.background),
    contentPadding = PaddingValues(top = 12.dp, bottom = bottomContentPadding + 24.dp),
    verticalArrangement = Arrangement.spacedBy(20.dp),
  ) {
    // Header
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 20.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          SeamlessLogoMark(size = 38.dp)
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = "Seamless",
              style = MaterialTheme.typography.headlineSmall,
              color = palette.onBackground,
            )
            Text(
              text = "${tracks.size} local tracks • ${prefs.reactionStyle.title}",
              style = MaterialTheme.typography.labelSmall,
              color = palette.onSurfaceMuted,
            )
          }
        }
        Row {
          IconButton(
            onClick = {
              haptics.tick()
              onImportAudioClick()
            },
            modifier = Modifier.testTag("home_import_button"),
          ) {
            Icon(Icons.Rounded.AudioFile, contentDescription = "Import audio file", tint = palette.onSurface)
          }
          IconButton(
            onClick = {
              haptics.tick()
              onRescanClick()
            },
            modifier = Modifier.testTag("home_rescan_button"),
          ) {
            Icon(Icons.Rounded.Refresh, contentDescription = "Rescan device audio", tint = palette.onSurface)
          }
        }
      }
    }

    // Infinity Mix Hero Card
    item {
      Surface(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 20.dp)
          .clip(RoundedCornerShape(24.dp))
          .border(1.dp, palette.outlineSubtle.copy(alpha = 0.55f), RoundedCornerShape(24.dp)),
        shape = RoundedCornerShape(24.dp),
        color = palette.surfaceElevated,
      ) {
        Box(
          modifier = Modifier
            .background(
              Brush.linearGradient(
                colors = listOf(
                  palette.primary.copy(alpha = 0.16f),
                  palette.surfaceElevated,
                  palette.tertiary.copy(alpha = 0.16f),
                )
              )
            )
            .padding(20.dp),
        ) {
          Column {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Surface(
                color = palette.primary.copy(alpha = 0.16f),
                shape = CircleShape,
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(
                    Icons.Rounded.AllInclusive,
                    contentDescription = null,
                    tint = palette.primary,
                    modifier = Modifier.size(16.dp),
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = if (prefs.infinityEnabled) "INFINITY ON • ${prefs.infinityDurationSec}S" else "INFINITY OFF",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.primary,
                  )
                }
              }

              IconButton(
                onClick = {
                  haptics.tick()
                  onOpenInfinitySheet()
                },
                modifier = Modifier.testTag("home_infinity_tune_button"),
              ) {
                Icon(Icons.Rounded.Tune, contentDescription = "Tune Infinity Blend", tint = palette.onSurface)
              }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "Continuous Audio Flow",
              style = MaterialTheme.typography.headlineSmall,
              color = palette.onBackground,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "${prefs.infinityProfile.title} — ${prefs.infinityProfile.description}",
              style = MaterialTheme.typography.bodyMedium,
              color = palette.onSurfaceMuted,
            )
            Spacer(modifier = Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              Button(
                onClick = {
                  haptics.strong()
                  if (tracks.isNotEmpty()) {
                    onPlayQueue(tracks.shuffled(), 0)
                  } else {
                    onLoadSoundcheckClick()
                  }
                },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = palette.primary,
                  contentColor = MaterialTheme.colorScheme.onPrimary,
                ),
                modifier = Modifier.testTag("start_infinity_mix_button"),
              ) {
                Icon(Icons.Rounded.Shuffle, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (tracks.isNotEmpty()) "Shuffle Infinity" else "Load Soundcheck")
              }

              OutlinedButton(
                onClick = {
                  haptics.tick()
                  onOpenInfinitySheet()
                },
                shape = RoundedCornerShape(16.dp),
              ) {
                Text("Blend Tuner", color = palette.onSurface)
              }
            }
          }
        }
      }
    }

    if (tracks.isEmpty()) {
      item {
        EmptyLibraryCard(
          isScanning = isScanning,
          haptics = haptics,
          onRescan = onRescanClick,
          onImportAudio = onImportAudioClick,
          onLoadSoundcheck = onLoadSoundcheckClick,
        )
      }
    } else {
      // Recently Played Shelf
      if (recentTracks.isNotEmpty()) {
        item {
          Column {
            SectionHeader(title = "Jump Back In", actionLabel = "Library", onAction = onOpenLibrary)
            Spacer(modifier = Modifier.height(10.dp))
            LazyRow(
              contentPadding = PaddingValues(horizontal = 20.dp),
              horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              items(recentTracks.take(10), key = { it.id }) { track ->
                Surface(
                  modifier = Modifier
                    .width(136.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .clickable {
                      haptics.tap()
                      val idx = tracks.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
                      onPlayQueue(tracks, idx)
                    },
                  color = palette.surfaceElevated,
                  shape = RoundedCornerShape(18.dp),
                ) {
                  Column(modifier = Modifier.padding(10.dp)) {
                    SeamlessArtwork(
                      albumArtUri = track.albumArtUri,
                      contentDescription = track.title,
                      circular = false,
                      cornerRadius = 12.dp,
                      modifier = Modifier
                        .fillMaxWidth()
                        .height(112.dp),
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                      text = track.title,
                      style = MaterialTheme.typography.titleSmall,
                      color = palette.onSurface,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                      text = track.artist,
                      style = MaterialTheme.typography.bodySmall,
                      color = palette.onSurfaceMuted,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                  }
                }
              }
            }
          }
        }
      }

      // Folders Quick Mixes (Lark Player flavor)
      if (folders.isNotEmpty()) {
        item {
          Column {
            SectionHeader(title = "Device Folders", actionLabel = "${folders.size} folders", onAction = onOpenLibrary)
            Spacer(modifier = Modifier.height(10.dp))
            LazyRow(
              contentPadding = PaddingValues(horizontal = 20.dp),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              items(folders, key = { it.name }) { folder ->
                Surface(
                  modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, palette.outlineSubtle.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
                    .clickable {
                      haptics.tap()
                      onPlayQueue(folder.tracks, 0)
                    },
                  color = palette.surfaceElevated,
                  shape = RoundedCornerShape(16.dp),
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Icon(
                      Icons.Rounded.FolderOpen,
                      contentDescription = null,
                      tint = palette.secondary,
                      modifier = Modifier.size(20.dp),
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                      Text(
                        text = folder.name,
                        style = MaterialTheme.typography.titleSmall,
                        color = palette.onSurface,
                      )
                      Text(
                        text = "${folder.tracks.size} tracks",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.onSurfaceMuted,
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }

      // Quick Queue Picks
      item {
        SectionHeader(title = "On Your Device", actionLabel = "See all", onAction = onOpenLibrary)
      }

      itemsIndexed(tracks.take(12), key = { _, t -> t.id }) { idx, track ->
        val isActive = currentTrack?.id == track.id
        TrackListItemRow(
          track = track,
          isActive = isActive,
          isPlaying = isActive && isPlaying,
          isFavorite = track.id in prefs.favoriteIds,
          onClick = {
            haptics.tap()
            onPlayQueue(tracks, idx)
          },
          onToggleFavorite = null,
          modifier = Modifier.padding(horizontal = 20.dp),
        )
      }
    }
  }
}

@Composable
private fun EmptyLibraryCard(
  isScanning: Boolean,
  haptics: SeamlessHaptics,
  onRescan: () -> Unit,
  onImportAudio: () -> Unit,
  onLoadSoundcheck: () -> Unit,
) {
  val palette = LocalSeamlessPalette.current
  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp)
      .border(1.dp, palette.outlineSubtle.copy(alpha = 0.45f), RoundedCornerShape(22.dp)),
    color = palette.surfaceElevated,
    shape = RoundedCornerShape(22.dp),
  ) {
    Column(
      modifier = Modifier.padding(22.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Icon(
        imageVector = Icons.Rounded.GraphicEq,
        contentDescription = null,
        tint = palette.primary,
        modifier = Modifier.size(44.dp),
      )
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = if (isScanning) "Scanning device audio..." else "No local audio files found yet",
        style = MaterialTheme.typography.titleMedium,
        color = palette.onSurface,
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "Import any audio file from storage, rescan your device folders, or load 3 built-in ambient Soundcheck tracks to experience the Reaction Circle and Infinity Mashup right away.",
        style = MaterialTheme.typography.bodySmall,
        color = palette.onSurfaceMuted,
      )
      Spacer(modifier = Modifier.height(16.dp))

      Button(
        onClick = {
          haptics.tap()
          onImportAudio()
        },
        modifier = Modifier.fillMaxWidth().testTag("empty_import_audio_button"),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = palette.primary,
          contentColor = MaterialTheme.colorScheme.onPrimary,
        ),
      ) {
        Icon(Icons.Rounded.AudioFile, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text("Pick Audio File from Device")
      }
      Spacer(modifier = Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedButton(
          onClick = {
            haptics.tick()
            onRescan()
          },
          modifier = Modifier.weight(1f).testTag("empty_rescan_button"),
          shape = RoundedCornerShape(14.dp),
        ) {
          Text("Rescan", color = palette.onSurface)
        }
        OutlinedButton(
          onClick = {
            haptics.tap()
            onLoadSoundcheck()
          },
          modifier = Modifier.weight(1.2f).testTag("empty_soundcheck_button"),
          shape = RoundedCornerShape(14.dp),
        ) {
          Text("Studio Soundcheck", color = palette.secondary)
        }
      }
    }
  }
}

@Composable
fun SectionHeader(
  title: String,
  actionLabel: String,
  onAction: () -> Unit,
) {
  val palette = LocalSeamlessPalette.current
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = title,
      style = MaterialTheme.typography.titleLarge,
      color = palette.onBackground,
    )
    Text(
      text = actionLabel,
      style = MaterialTheme.typography.labelLarge,
      color = palette.primary,
      modifier = Modifier
        .clip(RoundedCornerShape(8.dp))
        .clickable(onClick = onAction)
        .padding(horizontal = 8.dp, vertical = 4.dp),
    )
  }
}

@Composable
fun TrackListItemRow(
  track: Track,
  isActive: Boolean,
  isPlaying: Boolean,
  isFavorite: Boolean,
  onClick: () -> Unit,
  onToggleFavorite: (() -> Unit)?,
  trailingContent: (@Composable () -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  val palette = LocalSeamlessPalette.current
  Surface(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .clickable(onClick = onClick)
      .testTag("track_row_${track.id}"),
    color = if (isActive) palette.primary.copy(alpha = 0.12f) else palette.surfaceElevated.copy(alpha = 0.65f),
    shape = RoundedCornerShape(16.dp),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(contentAlignment = Alignment.Center) {
        SeamlessArtwork(
          albumArtUri = track.albumArtUri,
          contentDescription = track.title,
          circular = true,
          modifier = Modifier.size(48.dp),
        )
        if (isActive) {
          Box(
            modifier = Modifier
              .size(48.dp)
              .clip(CircleShape)
              .background(palette.background.copy(alpha = 0.55f)),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = if (isPlaying) Icons.Rounded.GraphicEq else Icons.Rounded.PlayArrow,
              contentDescription = null,
              tint = palette.primary,
              modifier = Modifier.size(22.dp),
            )
          }
        }
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = track.title,
          style = MaterialTheme.typography.titleSmall,
          fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
          color = if (isActive) palette.primary else palette.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "${track.artist} • ${track.album}",
          style = MaterialTheme.typography.bodySmall,
          color = palette.onSurfaceMuted,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }

      Spacer(modifier = Modifier.width(8.dp))

      Text(
        text = formatDuration(track.durationMs),
        style = MaterialTheme.typography.labelMedium,
        color = palette.onSurfaceMuted,
      )

      if (trailingContent != null) {
        trailingContent()
      }
    }
  }
}
