package com.example

import com.example.model.AppThemePreset
import com.example.model.EqPreset
import com.example.model.InfinityBlendProfile
import com.example.model.ReactionStyle
import com.example.model.WidgetShapeStyle
import com.example.ui.components.formatDuration
import com.example.ui.theme.paletteForPreset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SeamlessCoreTest {

  @Test
  fun `at least ten reaction circle styles are available`() {
    assertTrue(ReactionStyle.entries.size >= 10)
    assertEquals(12, ReactionStyle.entries.size)
  }

  @Test
  fun `matte grey default theme supports primary and accent customization`() {
    val defaultPalette = paletteForPreset(AppThemePreset.MATTE_GREY)
    val customPalette = paletteForPreset(
      preset = AppThemePreset.MATTE_GREY,
      customPrimaryArgb = 0xFFFF8C69.toInt(),
      customAccentArgb = 0xFF38BDF8.toInt(),
    )
    assertTrue(defaultPalette.primary != customPalette.primary)
    assertTrue(defaultPalette.tertiary != customPalette.tertiary)
    assertEquals(defaultPalette.background, customPalette.background)
  }

  @Test
  fun `infinity profiles eq presets and widget shapes are complete`() {
    assertEquals(3, InfinityBlendProfile.entries.size)
    assertTrue(EqPreset.entries.all { it.bandsDb.size == 5 })
    assertEquals(4, WidgetShapeStyle.entries.size)
    assertEquals("3:25", formatDuration(205_000L))
  }
}
