# Add project specific ProGuard rules here.
-keep class * implements androidx.glance.appwidget.action.ActionCallback { public <init>(); }
