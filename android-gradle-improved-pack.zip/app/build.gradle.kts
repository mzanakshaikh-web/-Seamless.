plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    // REQUIRED: replace both values with your app's actual package/namespace.
    // Find it in your existing AndroidManifest.xml or source package declarations.
    namespace = "com.example.aistudioapp"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.aistudioapp"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildTypes {
        debug {
            // Debug build for testing.
        }
        release {
            isMinifyEnabled = false
            // Add release signing only when you are ready to publish.
        }
    }
}

// Add the dependencies required by your actual Kotlin/Java source here.
// They cannot be safely inferred from the README and icon XML files alone.
dependencies {
}
